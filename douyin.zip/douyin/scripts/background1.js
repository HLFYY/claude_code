﻿var server=[{
	_server_port:"http://180.97.75.222:9999",
	//_server_port:"https://jkc.ckgjx.cn",
	//_server_port:"http://180.97.75.232:8888",
	mappings:[
	          {index:0,_interface:"/direct/getVersion",desc:""},
	          {index:1,_interface:"/direct/download",desc:""},
	          {index:2,_interface:"/login",desc:""},
	          {index:3,_interface:"/user/checkLogin",desc:""},
	          {index:4,_interface:"/user/checkShop",desc:""},
             ],
	mappingsjd:[
	    
	   ]
}];

function getServer(){
	return server;
}

var TARGETS = [
    {index:0,url: '/mq/overview/overviewTrend.json', desc: '市场-行业大盘-大盘走势'},
    {index:1,url: 'sycm.taobao.com/custom/menu/getPersonalView.json', desc: '获取店铺信息'},
    {index:2,url: '/adm/v2/execute/previewBySchema.json', desc: '生成报表'},
    {index:3,url: '/custom/menu/getPersonalView.json', desc: '获取生意参谋用户信息'},
    {index:4,url: '/adm/v2/item/topItem.json', desc: '推荐商品'},
    {index:5,url: '/adm/v2/item/searchItem.json', desc: '检索商品'},
    {index:6,url: '/mc/common/getShopCate.json', desc: 'addCategory'},
    {index:7,url: '/mq/overview/reportIndex.json', desc: 'add'},
    {index:8,url: '/mq/overview/reportTrend.json', desc: 'add'},
    {index:9,url: '/mc/mq/supply/mkt/trend/cate.json', desc: 'add'},
    {index:10,url: '/mc/common/getShopCate.json', desc: 'add'},
    {index:11,url: '/mc/searchword/propertyTrend.json', desc: 'add'},
    {index:12,url: '/mc/searchword/relatedWord.json', desc: 'add'},
    {index:13,url: '/mc/searchword/getCategory.json', desc: 'add'},
    {index:14,url: '/mc/searchword/relatedBrand.json', desc: 'add'},
    {index:15,url: '/mc/searchword/relatedProperty.json', desc: 'add'},
    {index:16,url: '/mc/searchword/relatedHotWord.json', desc: 'add'},
    {index:17,url: '/cc/cockpit/marcro/core/trend.json', desc: 'add'},
    {index:18,url: '/cc/cockpit/marcro/item/top.json', desc: 'add'},
    {index:19,url: '/mc/industry/searchWord.json', desc: 'add'},
    {index:20,url: '/mc/industry/tailWord.json', desc: 'add'},
    {index:21,url: '/mc/industry/brandWord.json', desc: 'add'},
    {index:22,url: '/mc/industry/coreWord.json', desc: 'add'},
    {index:23,url: '/mc/industry/attrWord.json', desc: 'add'},
    {index:24,url: '/mc/mq/mkt/rank/shop/hotsale.json', desc: 'add'},
    {index:25,url: '/mc/mq/mkt/rank/shop/hotsearch.json', desc: 'add'},
    {index:26,url: '/mc/mq/mkt/rank/item/hotsale.json', desc: 'add'},
    {index:27,url: '/mc/mq/mkt/rank/item/hotsearch.json', desc: 'add'},
    {index:28,url: '/mc/mq/mkt/rank/item/hotpurpose.json', desc: 'add'},
    {index:29,url: '/mc/mq/mkt/rank/brand/hotsale.json', desc: 'add'},
    {index:30,url: '/mc/mq/mkt/rank/brand/hotsearch.json', desc: 'add'},
    {index:31,url: '/bda/visitor/distribution/listPeriods.json', desc: 'add'},
    {index:32,url: '/bda/visitor/distribution/listAreas.json', desc: 'add'},
    {index:33,url: '/bda/visitor/distribution/listFeatures.json', desc: 'add'},
    {index:34,url: '/bda/visitor/distribution/listBehaviors.json', desc: 'add'},
    {index:35,url: '/bda/visitor/visitor/compares.json', desc: 'add'},
    {index:36,url: '/mc/ci/config/rival/item/getMonitoredList.json', desc: 'add'},
    {index:37,url: '/mc/rivalShop/recommend/item.json', desc: 'add'},
    {index:38,url: '/mc/rivalItem/analysis/getCoreTrend.json', desc: 'add'},
    {index:39,url: '/ipoll/live/getFlowAndPay.json', desc: 'add'},
    {index:40,url: '/mc/rivalItem/analysis/getKeywords.json', desc: 'add'},
    {index:41,url: '/mc/rivalItem/analysis/getFlowSource.json', desc: 'add'},
    {index:42,url: '/flow/v5/shop/source/tree.json', desc: 'add'},
    {index:43,url: '/flow/v6/live/item/source.json|/flow/v6/item/crowdtype/source.json', desc: 'add'},
    //{index:44,url: '/bda/toolbox/wordAide/getSearchKeys.json', desc: 'add'},
    {index:44,url: '/flow/v3/shop/wordAide/drainageSearch.json', desc: 'add'},
    {index:45,url: '/bda/flow/flowmap/shopPagePathFlow.json', desc: 'add'},
    {index:46,url: 'sycm.taobao.com/custom/login', desc: 'add'},
    {index:47,url: '/bda/flow/flowmap/shopPageVisitorRank.json', desc: 'add'},
    {index:48,url: '/bda/flow/flowmap/pageLeaveRank.json', desc: 'add'},
    {index:49,url: '/bda/flow/flowmap/pageDestRank.json', desc: 'add'},
    {index:50,url: '/flow/new/item/itemSearch.json', desc: 'add'},
    {index:51,url: '/flow/v2/decorate/wl/getPageDetailData.json', desc: 'add'},
    {index:52,url: '/mc/ci/item/recognition/getCrmDrainList.json', desc: 'add'},
    {index:53,url: '/mc/ci/item/recognition/getSeDrainList.json', desc: 'add'},
    {index:54,url: '/ipoll/live/rank/getCoreItemEffectRank.json', desc: 'add'},
    {index:55,url: '/flow/new/monitor/item/tops/rank.json', desc: 'add'},
    {index:56,url: '/flow/new/item/itemSearch.json', desc: 'add'},
    {index:57,url: '/mc/ci/item/trend.json', desc: 'add'},
    {index:58,url: '/mc/ci/item/recognition/getCrmDrainDetail.json', desc: 'add'},
    {index:59,url: '/mc/ci/item/recognition/getSeDrainDetail.json', desc: 'add'},
    {index:60,url: '/mc/industry/subject/subjectWords.json', desc: 'add'},
    {index:61,url: '/mc/industry/subject/newWords.json', desc: 'add'},
    {index:62,url: '/flow/v3/shop/wordAide/competitionSearch.json', desc: 'add'},
    {index:63,url: '/component/supplier/pageBasicSupplier', desc: 'add'},
    {index:64,url: '/charts/query_data', desc: 'add'},
    {index:65,url: '/webapi/replenish/postListReplenishAdvice', desc: 'add'},
    {index:66,url: '/webapi/oih-merchant/zb/read/queryIndexData', desc: 'add'},
];

var TARGETSJD = [
	{index:0,url: '/brand/common/newGetGlobalInfo.ajax', desc: '自营'},
	{index:1,url: '/brand/realTime/realTop/getTopListData.ajax', desc: ''},
	{index:2,url: '/index/getWhoConcernedMyShop.ajax', desc: '旗舰店'},
	{index:3,url: '/productDetail/getProductList.ajax', desc: ''},
	{index:4,url: 'https://passport.jd.com/uc/login', desc: ''},
	{index:5,url: '/brand/common/getBrandAndCategoryNew.ajax', desc: ''},
	{index:6,url: '/brand/industry/hotSearch/getIndustryKeywordsData.ajax', desc: ''},
	{index:7,url: '/brand/realTime/realSummary/getAreaData.ajax', desc: ''},
	{index:8,url: '/brand/consumerAnalysis/consumerSummary/getSummaryData.ajax', desc: ''},
	{index:9,url: '/brand/productAnalysis/productDetail/getProData.ajax', desc: ''},
	{index:10,url: '/brand/productAnalysis/singleAnalysisDetail/getLossDirectionData.ajax', desc: ''},
	{index:11,url: '/brand/industry/industryFeature/getAllColumnData.ajax', desc: ''},
	{index:12,url: '/brand/industry/industryFeature/getProvinceData.ajax', desc: ''},
	{index:13,url: '/brand/industry/competitorAnalysis/getBrandGridData.ajax', desc: ''},
	{index:14,url: '/brand/viewFlow/viewSource/getSearchGridData.ajax', desc: ''},
];

const _JS = [
             {url: 'ipoll/index', js: 'scripts/js/realTime.js',css:''},
             {url: '/mc/mq/market_monitor', js: 'scripts/js/realTime.js',css:''},
             {url: '/mc/mq/search_analyze', js: 'scripts/js/realTime.js',css:''},
             {url: '/custom/login', js: 'scripts/jquery-1.11.2.min.js|scripts/js/realTime.js',css:''},
             {url: '/member/login.jhtml', js: 'scripts/jquery-1.11.2.min.js|scripts/js/realTime.js',css:''},
             {url: 'h5.m.taobao.com', js: 'scripts/jquery-1.11.2.min.js|scripts/js/parseHtml.js',css:''},
             {url: '/ipoll/itemmonitor.htm', js: 'scripts/jquery-1.11.2.min.js|scripts/js/realTime.js',css:''},
             {url: '/brand/realTime/realTop.html', js: 'scripts/js/realTime.js',css:''},
             {url: '/brand/realTime/realSummary.html', js: 'scripts/js/realTime.js',css:''},
             {url: '/flow/monitor/itemsource', js: 'scripts/jquery-1.11.2.min.js|scripts/js/parseHtml.js|scripts/js/realTime.js',css:''},
             {url: '/flow/monitor/overview', js: 'scripts/jquery-1.11.2.min.js|scripts/js/parseHtml.js|scripts/js/realTime.js',css:''},
             {url: '/flow/new/item/getTops.json', js: 'scripts/jquery-1.11.2.min.js|scripts/js/parseHtml.js|scripts/js/realTime.js',css:''},
            ];
function injectCustomJs(url){
	for (var i in _JS) {
        var target = _JS[i];
        if (url.match(target.url)) {
            return target;
        }
    }
}


var shop_data="";
var token="";
var user={};
var ExtensionInfo={};

$.ajaxSetup({crossDomain: true, xhrFields: {withCredentials: true}});


chrome.management.getAll(function(ExInfo){
	$.each(ExInfo,function(index){
		if(this.id=="jcpikflbogbpifadmhcakdefgdlemjnc"){
			//if(this.id=="omngpalomokicigfegochhkfepgnadmm"){
			ExtensionInfo=ExInfo[index];
		}
	})
})


chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if(request.cmd == "get-time"){
        sendResponse(getTime());
    }
    if(request.cmd == "get-Version"){
        sendResponse(getVersion());
    }
    if(request.cmd == "checkurl"){
        sendResponse(injectCustomJs(request.url));
    }
    if(request.cmd == "getAllSKU"){
        sendResponse(getAllSKU(request.date));
    }
    if(request.cmd == "getAllSKUIntegrity"){
        sendResponse(getAllSKUIntegrity(request.date));
    }
    if(request.cmd == "getService"){
        sendResponse(getService(request));
    }
});

function getService(request){
	if(request.data.servicename=="shuaxinshopinfo"){
		tmall_loginName=request.data.shopInfo.split('-')[0]+','+request.data.shopInfo.split(request.data.shopInfo.split('-')[0]+'-')[1];
		return {"data":"刷新成功","type":"shuaxinshopinfo","status":"1"};
	}
	
	let resultdata;
	$.ajax({
		type:'POST',
		url:server[0]._server_port+'/data/'+(request.data.servicename==undefined?"service":request.data.servicename),
		data:request.data,
		async:false,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==1){
				resultdata = data;
			}
		}
	})
	return resultdata;
}

function getAllSKUIntegrity(date){
	let resultdata;
	$.ajax({
		type:'POST',
		url:server[0]._server_port+'/flagship/getAllSKUIntegrity',
		data:{date:date},
		async:false,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==1){
				resultdata = data.data;
			}
		}
	})
	return resultdata;
}

function getAllSKU(date){
	let resultdata;
	$.ajax({
		type:'POST',
		url:server[0]._server_port+'/flagship/getAllSKU',
		data:{date:date},
		async:false,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==1){
				resultdata = data.data;
			}
		}
	})
	return resultdata;
}

function getCurrentTabId(callback)
{
	chrome.tabs.query({active: true, currentWindow: true}, function(tabs)
	{
		if(callback) callback(tabs.length ? tabs[0].id: null);
	});
}

function getURLParameter(name,url) { 
	var url=url.replace('?', "?a=a&");
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = url.substr(1).match(reg); 
    if (r != null) return decodeURI(r[2]); 
    return null; 
}

var gAttached = false;
var gRequests = [];
var gObjects = [];

var _source=[];
var loginUserName="";
var loginUserNameJD="";
var loginUserNameJD_1="";
var tmall_loginName="";
chrome.debugger.onEvent.addListener(function (source, method, params) {_source=source;
        if (method == "Network.requestWillBeSent") {
            var rUrl = params.request.url;
            if (getTarget(rUrl) >= 0) {
                gRequests.push(rUrl);
            }
            
            if (getTargetJD(rUrl) >= 0) {
                gRequests.push(rUrl);
            }
        }
        if (method == "Network.responseReceived") {
            var eUrl = params.response.url;
            var target = getTarget(eUrl);
            if (target >= 0) {
                gObjects.push({
                    requestId: params.requestId,
                    target: target,
                    url: eUrl
                });
            }
            
            var target = getTargetJD(eUrl);
            if (target >= 0) {
                gObjects.push({
                    requestId: params.requestId,
                    target: target,
                    url: eUrl
                });
            }
            
        }
        if (method == "Network.loadingFinished" && gObjects.length > 0) {
            var requestId = params.requestId;
            var object = null;
            var targetObject= null;
            for (var o in gObjects) {
                if (requestId == gObjects[o].requestId) {
                	targetObject=gObjects[o];
                    object = gObjects.splice(o, 1)[0];
                    break;
                }
            }
            if (object == null) {
                console.log('Failed!!');
                return;
            }
            gRequests.splice(gRequests.indexOf(object.url), 1);
            chrome.debugger.sendCommand(
                source,
                "Network.getResponseBody",
                {"requestId": requestId},
                function (response) {
                    if (response) {
                    	var data=getTargetObj(targetObject.url);
                    	if(data!=undefined){
                    	if(data.index==0){return false;
                    		var dateRange=getURLParameter("dateRange",targetObject.url);//时间
                    		var indexCode=getURLParameter("indexCode",targetObject.url);
                    		var c1=indexCode.split('|')[0];
                    		JSONToExcelConvertor(response.body,data.desc+"(_时间:"+dateRange+"_条件:"+data.parameter+")",["大盘走势数据","数据接口"],targetObject.url);
                    	}
                    	
                    	if(data.index==1){
                    		shop_data=response.body;
                    		chrome.tabs.sendRequest(source.tabId, {data: shop_data,cmd:"set_shop_data",tabId:source.tabId}, function(value) {
                    			localStorage.setItem("tab_loginInfo",JSON.stringify(shop_data))
                    			if(value.status==1){
                    				var jsonTB=JSON.parse(shop_data);
                    				loginUserName=jsonTB.data.loginUserName;
                    			}
              				});
                    	}
                    	if(data.index==63){
                    		tmall_loginName=JSON.parse(response.body).data[0].code+","+JSON.parse(response.body).data[0].name;
                    	}
                    	chrome.tabs.sendRequest(source.tabId, {cmd:"get_shop_data",tabId:source.tabId}, function(val) {
                    		if(data.index==64)set_tmall_flow_daily(response.body,tmall_loginName
                					,getURLParameter("ctoken",targetObject.url));
                    		if(data.index==65)set_postListReplenishAdvice(response.body,tmall_loginName
                					,getURLParameter("computeTimeEnd",targetObject.url));
                    		if(data.index==66)set_queryIndexData(response.body,tmall_loginName
                					,getURLParameter("query",targetObject.url));
                    	})
                    	
                    	if(loginUserName=="")return ;
                    	chrome.tabs.sendRequest(source.tabId, {cmd:"get_shop_data",tabId:source.tabId}, function(val) {
                			//var json=(val==undefined ?JSON.parse(localStorage.getItem("tab_loginInfo").substring(1,localStorage.getItem("tab_loginInfo").length - 1).replace(/[\\]/g,'')):JSON.parse(val.data));
                			//loginUserName=jsonTB.data.loginUserName;
                			if(val==undefined){
                				loginUserName=JSON.parse(localStorage.tab_loginInfo).data.loginUserName;
                			}else{
                				let dataval;
                				if(Object.prototype.toString.call(val)=="[object String]"){
                					dataval=JSON.parse(val);
                				}
                				if(Object.prototype.toString.call(val)=="[object Object]"){
                					dataval=val;
                				}
                				try {
                					loginUserName=JSON.parse(dataval.data).data.loginUserName;
                				} catch (e) {
                					loginUserName=JSON.parse(JSON.parse(localStorage.tab_loginInfo)).data.loginUserName;
                				}
                			}
                			
                			if(data.index==50)flow_new_item_itemSearch(response.body,loginUserName);
                			/*if(getURLParameter("dateType",targetObject.url)!='day'&&getURLParameter("dateType",targetObject.url)!='week'&&getURLParameter("dateType",targetObject.url)!='month'){
                				return ;
                			}*/
                			if(data.index==2)set_QuShu_Shop_whole_Data(response.body,loginUserName);
                			if(data.index==4 || data.index==5)set_QuShu_item_whole_topItem(response.body,loginUserName);
                			if(data.index==6)addcategory(response.body,loginUserName);
                			if(data.index==7)reportIndex(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("seller",targetObject.url));
                			if(data.index==8)reportTrend(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("seller",targetObject.url));
                			if(data.index==9)mkt_trend_cate(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("sellerType",targetObject.url)
                					,getURLParameter("indexCode",targetObject.url));
                			if(data.index==10)addshopCate(response.body,loginUserName);
                			if(data.index==11)Keyword_qushi(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("keyword",targetObject.url));
                			if(data.index==12)searchword_relatedWord(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("keyword",targetObject.url));
                			if(data.index==13)searchword_getCategory(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("keyword",targetObject.url)
                					,getURLParameter("level1Id",targetObject.url));
                			
                			if(data.index==14)searchword_relatedBrand(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("keyword",targetObject.url));
                			
                			if(data.index==15)searchword_relatedProperty(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("keyword",targetObject.url));
                			
                			if(data.index==16)searchword_relatedHotWord(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("keyword",targetObject.url));
                			if(data.index==17)marcro_core_trend(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					);
                			if(data.index==18)marcro_item_top(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					);
                			if(data.index==19)mc_industry_searchWord(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					);
                			if(data.index==20)mc_industry_tailWord(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					);
                			if(data.index==21)mc_industry_brandWord(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					);
                			if(data.index==22)mc_industry_coreWord(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					);
                			if(data.index==23)mc_industry_attrWord(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					);
                			if(data.index==24)mkt_rank_shop_hotsale(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("sellerType",targetObject.url)
                					);
                			if(data.index==25)mkt_rank_shop_hotsearch(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("sellerType",targetObject.url)
                					);
                			if(data.index==26)mkt_rank_item_hotsale(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("sellerType",targetObject.url)
                					);
                			if(data.index==27)mkt_rank_item_hotsearch(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("sellerType",targetObject.url)
                					);
                			if(data.index==28)mkt_rank_item_hotpurpose(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("sellerType",targetObject.url)
                					);
                			if(data.index==29)mkt_rank_brand_hotsale(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("sellerType",targetObject.url)
                					);
                			if(data.index==30)mkt_rank_brand_hotsearch(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("sellerType",targetObject.url)
                					);
                			if(data.index==31)bda_visitor_distribution_listPeriods(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("index",targetObject.url)
                					);
                			if(data.index==32)bda_visitor_distribution_listAreas(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					);
                			if(data.index==33)bda_visitor_distribution_listFeatures(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					);
                			if(data.index==34)bda_visitor_distribution_listBehaviors(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					);
                			if(data.index==35)bda_visitor_visitor_compares(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					);
                			if(data.index==36)mc_ci_config_rival_item_getMonitoredList(response.body,loginUserName
                					,getURLParameter("firstCateId",targetObject.url)
                					,getURLParameter("rivalType",targetObject.url)
                					);
                			if(data.index==37)mc_rivalShop_recommend_item(response.body,loginUserName
                					);
                			if(data.index==38)mc_rivalItem_analysis_getCoreTrend(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("selfItemId",targetObject.url)
                					,getURLParameter("rivalItem1Id",targetObject.url)
                					,getURLParameter("rivalItem2Id",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					);
                			if(data.index==39)ipoll_live_getFlowAndPay(response.body,loginUserName
                					);
                			if(data.index==40)mc_rivalItem_analysis_getKeywords(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("sellerType",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("itemId",targetObject.url)
                					,getURLParameter("topType",targetObject.url)
                					);
                			if(data.index==41)mc_rivalItem_analysis_getFlowSource(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("selfItemId",targetObject.url)
                					,getURLParameter("rivalItem1Id",targetObject.url)
                					,getURLParameter("rivalItem2Id",targetObject.url)
                					);
                			if(data.index==42)flow_v3_shop_source_tree(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("belong",targetObject.url)
                					);
                			if(data.index==43)flow_v3_item_source(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("belong",targetObject.url)
                					,getURLParameter("itemId",targetObject.url)
                					);
                			if(data.index==44)bda_toolbox_wordAide_getSearchKeys(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("kwType",targetObject.url)
                					);
                			if(data.index==45)bda_flow_flowmap_shopPagePathFlow(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("deviceLogicType",targetObject.url)
                					);
                			if(data.index==46)tipUserLogin(response.body,loginUserName,targetObject.url);
                			if(data.index==47)bda_flow_flowmap_shopPageVisitorRank(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("deviceLogicType",targetObject.url)
                					);
                			if(data.index==48)bda_flow_flowmap_pageLeaveRank(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("deviceLogicType",targetObject.url)
                					);
                			if(data.index==49)bda_flow_flowmap_pageDestRank(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("deviceLogicType",targetObject.url)
                					);
                			if(data.index==51)flow_configuration_page(response.body,loginUserName
                					,getURLParameter("appType",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("pageId",targetObject.url)
                					);
                			if(data.index==52)competition_goods_customer(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					);
                			if(data.index==53)competition_goods_search(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,decodeURIComponent(getURLParameter("indexCode",targetObject.url))
                					);
                			if(data.index==54)rank_getCoreItemEffectRank(response.body,loginUserName
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("page",targetObject.url)
                					);
                			if(data.index==55)getFlowProductList(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)	
                					,getURLParameter("device",targetObject.url)
                					);
                			if(data.index==58)competition_goods_customer_whereabouts(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)	
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("itemId",targetObject.url)
                					);
                			if(data.index==59)competition_goods_search_whereabouts(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)	
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					,getURLParameter("itemId",targetObject.url)
                					);
                			if(data.index==60)mc_industry_theme_subject(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					);
                			if(data.index==61)mc_industry_theme_new(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("cateId",targetObject.url)
                					);
                			if(data.index==62)flow_wordAide_competitionSearch(response.body,loginUserName
                					,getURLParameter("dateRange",targetObject.url)
                					,getURLParameter("dateType",targetObject.url)
                					,getURLParameter("device",targetObject.url)
                					,getURLParameter("kwType",targetObject.url)
                					,getURLParameter("rivalSellerId",targetObject.url)
                					);
                			
          				});
                    	}
                    	
                    	var dataJD=getTargetObjJD(targetObject.url);
                    	if(dataJD!=undefined){
                        	if(dataJD.index==0){
                        		shop_data=response.body;
                        		chrome.tabs.sendRequest(source.tabId, {data: JSON.parse(shop_data).content.globalInfo.user.userInfo,cmd:"set_shop_data",tabId:source.tabId}, function(value) {
                        			localStorage.setItem("tab_loginInfo_jd",JSON.stringify(JSON.parse(shop_data).content.globalInfo.user.userInfo))
                        			if(value.status==1){
                        				loginUserNameJD=JSON.parse(shop_data).content.globalInfo.user.userInfo.vendor;
                        			}
                  				});
                        	}
                        	if(loginUserNameJD==""||loginUserNameJD==null||loginUserNameJD==undefined){
                        		if(localStorage.tab_loginInfo_jd!=undefined&&localStorage.tab_loginInfo_jd!=null&&localStorage.tab_loginInfo_jd!=""){
                        			loginUserNameJD=JSON.parse(localStorage.tab_loginInfo_jd).vendor;
                        			console.log("提取店铺");
                        		}else{
                        			console.log("无品牌纵横店铺信息！");
                        		}
                        	}
                        	
                        	if(loginUserNameJD!=""){
                        		chrome.tabs.sendRequest(source.tabId, {cmd:"get_shop_data",tabId:source.tabId}, function(val) {
                        			if(val==undefined){
                        				loginUserNameJD=loginUserNameJD;
                        			}else{
                        				let dataval;
                        				if(Object.prototype.toString.call(val)=="[object String]"){
                        					dataval=JSON.parse(val);
                        				}
                        				if(Object.prototype.toString.call(val)=="[object Object]"){
                        					dataval=val;
                        				}
                        				loginUserNameJD=dataval.data.vendor;
                        			}
                        			
                        			if(dataJD.index==1)topListData(response.body,loginUserNameJD
                        					,getURLParameter("orderBy",targetObject.url));
                        			
                        			if(dataJD.index==4){
                        				if(dataJD.url==targetObject.url.split('?')[0]){
                        					tipUserLogin(response.body,loginUserNameJD,targetObject.url)
                        				}
                        			}
                        			if(dataJD.index==5)setBrandAndCategoryNew(response.body,loginUserNameJD);
                        			if(dataJD.index==6)setIndustryKeywordsData(response.body,loginUserNameJD
                        					,getURLParameter("firstCategoryId",targetObject.url)
                        					,getURLParameter("secondCategoryId",targetObject.url)	
                        					,getURLParameter("thirdCategoryId",targetObject.url)
                        					,getURLParameter("channel",targetObject.url)
                        					,getURLParameter("startDate",targetObject.url)
                        					,getURLParameter("endDate",targetObject.url)
                        					,getURLParameter("orderBy",targetObject.url)
                        					,getURLParameter("date",targetObject.url)
                        					);
                        			if(dataJD.index==7)setAreaData(response.body,loginUserNameJD
                        					,getURLParameter("areaType",targetObject.url)
                        					);
                        			if(dataJD.index==8)setOldAndNewConsumerData(response.body,loginUserNameJD
                        					,getURLParameter("firstCategoryId",targetObject.url)
                        					,getURLParameter("secondCategoryId",targetObject.url)	
                        					,getURLParameter("thirdCategoryId",targetObject.url)
                        					,getURLParameter("channel",targetObject.url)
                        					,getURLParameter("brandId",targetObject.url)
                        					,getURLParameter("shopType",targetObject.url)
                        					,getURLParameter("repurchaseId",targetObject.url)
                        					,getURLParameter("startDate",targetObject.url)
                        					,getURLParameter("endDate",targetObject.url)
                        					,getURLParameter("orderBy",targetObject.url)
                        					,getURLParameter("date",targetObject.url)
                        					);
                        			if(dataJD.index==9)setallproductdetail(response.body,loginUserNameJD
                        					,getURLParameter("firstCategoryId",targetObject.url)
                        					,getURLParameter("secondCategoryId",targetObject.url)	
                        					,getURLParameter("thirdCategoryId",targetObject.url)
                        					,getURLParameter("channel",targetObject.url)
                        					,getURLParameter("brandId",targetObject.url)
                        					,getURLParameter("shopType",targetObject.url)
                        					,getURLParameter("repurchaseId",targetObject.url)
                        					,getURLParameter("startDate",targetObject.url)
                        					,getURLParameter("endDate",targetObject.url)
                        					,getURLParameter("orderBy",targetObject.url)
                        					,getURLParameter("date",targetObject.url)
                        					,getURLParameter("pageNum",targetObject.url)
                        					);
                        			if(dataJD.index==10)setLossDirectionData(response.body,loginUserNameJD
                        					,getURLParameter("startDate",targetObject.url)
                        					,getURLParameter("endDate",targetObject.url)
                        					,getURLParameter("channel",targetObject.url)
                        					,getURLParameter("skuId",targetObject.url)
                        					);
                        			if(dataJD.index==11)setindustryFeature(response.body,loginUserNameJD
                        					,getURLParameter("startDate",targetObject.url)
                        					,getURLParameter("endDate",targetObject.url)
                        					,getURLParameter("channel",targetObject.url)
                        					,getURLParameter("brandId",targetObject.url)
                        					,getURLParameter("shopType",targetObject.url)
                        					,getURLParameter("thirdCategoryId",targetObject.url)
                        					);
                        			if(dataJD.index==12)setindustryFeatureCity(response.body,loginUserNameJD
                        					,getURLParameter("startDate",targetObject.url)
                        					,getURLParameter("endDate",targetObject.url)
                        					,getURLParameter("channel",targetObject.url)
                        					,getURLParameter("brandId",targetObject.url)
                        					,getURLParameter("shopType",targetObject.url)
                        					,getURLParameter("provinceId",targetObject.url)
                        					,getURLParameter("thirdCategoryId",targetObject.url)
                        					);
                        			if(dataJD.index==13)setBrandGridData(response.body,loginUserNameJD
                        					,getURLParameter("startDate",targetObject.url)
                        					,getURLParameter("endDate",targetObject.url)
                        					,getURLParameter("channel",targetObject.url)
                        					,getURLParameter("brandId",targetObject.url)
                        					,getURLParameter("shopType",targetObject.url)
                        					,getURLParameter("thirdCategoryId",targetObject.url)
                        					);
                        			if(dataJD.index==14)setSearchGridData(response.body,loginUserNameJD
                        					,getURLParameter("startDate",targetObject.url)
                        					,getURLParameter("endDate",targetObject.url)
                        					,getURLParameter("channel",targetObject.url)
                        					,getURLParameter("brandId",targetObject.url)
                        					,getURLParameter("shopType",targetObject.url)
                        					,getURLParameter("thirdCategoryId",targetObject.url)
                        					,getURLParameter("pageNum",targetObject.url)
                        					);
                            	});
                        	}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------////                        	
                        	if(dataJD.index==2){
                        		shop_data=response.body;
                        		chrome.tabs.sendRequest(source.tabId, {data: JSON.parse(shop_data),cmd:"set_shop_data",tabId:source.tabId}, function(value) {
                        			localStorage.setItem("tab_loginInfo_jd_1",JSON.stringify(JSON.parse(shop_data)))
                        			if(value.status==1){
                        				loginUserNameJD_1=JSON.parse(shop_data).content.OneShopName;
                        			}
                  				});
                        	}
                        	
                        	if(loginUserNameJD_1==""||loginUserNameJD_1==null||loginUserNameJD_1==undefined){
                        		if(localStorage.tab_loginInfo_jd_1!=undefined&&localStorage.tab_loginInfo_jd_1!=null&&localStorage.tab_loginInfo_jd_1!=""){
                        			loginUserNameJD_1=JSON.parse(localStorage.tab_loginInfo_jd_1).content.OneShopName;
                        			console.log("提取店铺");
                        		}else{
                        			console.log("无京东商智店铺信息！");
                        		}
                        	}
                        	
                        	if(loginUserNameJD_1!=""){
                        		chrome.tabs.sendRequest(source.tabId, {cmd:"get_shop_data",tabId:source.tabId}, function(val) {
//                        			if(val==undefined){
//                        				loginUserNameJD_1=JSON.parse(localStorage.tab_loginInfo).content.OneShopName;
//                        			}else{
//                        				let dataval;
//                        				if(Object.prototype.toString.call(val)=="[object String]"){
//                        					dataval=JSON.parse(val);
//                        				}
//                        				if(Object.prototype.toString.call(val)=="[object Object]"){
//                        					dataval=val;
//                        				}
//                        				loginUserNameJD_1=dataval.data.content.OneShopName;
//                        			}
                        			
                        			if(dataJD.index==3)getProductList(response.body,loginUserNameJD_1
                        					,getURLParameter("type",targetObject.url)
                        					,getURLParameter("startDate",targetObject.url)
                        					,getURLParameter("endDate",targetObject.url)
                        			);
                            	});
                        	}
                    		
                    	
                        	
                    	}
                    	
                    	//_i();
                    } else {
                        console.log("Empty response for " + object.url);
                    }
                    
                    if (gRequests.length == 0) {return false;
                        chrome.debugger.detach({
                            tabId: source.tabId
                        }, function () {
                            chrome.debugger.attach({
                                tabId: source.tabId
                            }, "1.0", function () {
                                chrome.debugger.sendCommand({
                                    tabId: source.tabId
                                }, "Network.enable");
                            });
                        });
                    }
                });
        }
    }
);

var initialListener = function (details) {
    if (gAttached) return;  
    var tabId = details.tabId;
    if (tabId > 0) {
        gAttached = true;
        chrome.debugger.attach({
            tabId: tabId
        }, "1.0", function () {
            chrome.debugger.sendCommand({
                tabId: tabId
            }, "Network.enable");
        });
        chrome.webRequest.onBeforeRequest.removeListener(initialListener);
    }
};

function _i(){
	$.ajax({
		type:'POST',
		url:server[0]._server_port+'/option/datainterface',
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==1){
				server[0].mappings=data.data
			}
		}
	})
}

function _ijd(){
	$.ajax({
		type:'POST',
		url:server[0]._server_port+'/option/datainterfacejd',
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==1){
				server[0].mappingsjd=data.data
			}
		}
	})
}

function _tburl(){
	$.ajax({
		type:'POST',
		url:server[0]._server_port+'/option/filtertburl',
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==1){
				//TARGETS=data.data
			}
		}
	})
}

function _jdurl(){
	$.ajax({
		type:'POST',
		url:server[0]._server_port+'/option/filterjdurl',
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==1){
				//TARGETSJD=data.data
			}
		}
	})
}

function _m(v){
	$.ajax({
		type:'POST',
		url:server[0]._server_port+'/option/getModule',
		async:false,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==1){
				return data.data;
			}
		},
		error:function (data) {
			
		}

	})
}

function startDebugger(){
	chrome.debugger.getTargets(function (e) {
		chrome.tabs.getAllInWindow(null,function(detail){
			$.each(detail,function(){
				var id=this.id;
				var url=this.url;
				var boolean=true;
				if (url.match("sycm.taobao.com") || url.match("jd.com") || url.match("tmall.com")) {
				$.each(e,function(){
						if(id==this.tabId && !this.attached){

							chrome.debugger.attach({
					            tabId: id
					        }, "1.0", function () {
					            chrome.debugger.sendCommand({
					                tabId: id
					            }, "Network.enable");
					        });
						
						}	
				})
				}
			})
		})
	})
	
}



function onAttach(t) {
    chrome.debugger.sendCommand({
        tabId: t
    }, "Network.enable")
}

$("#xianshi1").click(function(){
	debuggerController(true)
})
function debuggerController(t) {
    chrome.debugger.getTargets(function (e) {console.log(JSON.stringify(e))})
}


function getTarget(url) {
    for (var i in TARGETS) {
        var target = TARGETS[i];
        if (url.match(target.url)) {
            return i;
        }
    }
    return -1;
}

function getTargetJD(url) {
    for (var i in TARGETSJD) {
        var targetJD = TARGETSJD[i];
        if (url.match(targetJD.url)) {
            return i;
        }
    }
    return -1;
}

function getTargetObj(url) {
    for (var i in TARGETS) {
        var target = TARGETS[i];
        if (url.match(target.url)) {
            return target;
        }
    }
}

function getTargetObjJD(url) {
    for (var i in TARGETSJD) {
        var targetJD = TARGETSJD[i];
        if (url.match(targetJD.url)) {
            return targetJD;
        }
    }
}

function JSONToExcelConvertor(JSONData, FileName, ShowLabel,url){
	var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData; 
	var excel = '<table>';
	var row = "<tr>"; 
	for (var i = 0; i < ShowLabel.length; i++) { 
		row += "<td>" + ShowLabel[i] + '</td>'; 
	} 
	excel += row + "</tr>";
	excel+='<tr><td>'+JSON.stringify(arrData)+'</td><td>'+url+'</td></tr>';
	excel += "</table>"; 
	console.log(excel); 
	var excelFile = "<html xmlns:o='urn:schemas-microsoft-com:office:office' " + "xmlns:x='urn:schemas-microsoft-com:office:excel' xmlns='http://www.w3.org/TR/REC-html40'>"; 
	excelFile += '<meta http-equiv="content-type" content="application/vnd.ms-excel; charset=UTF-8">'; 
	excelFile += '<meta http-equiv="content-type" content="application/vnd.ms-excel'; 
	excelFile += '; charset=UTF-8">'; 
	excelFile += "<head>"; 
	excelFile += "<!--[if gte mso 9]>"; 
	excelFile += "<xml>"; 
	excelFile += "<x:ExcelWorkbook>"; 
	excelFile += "<x:ExcelWorksheets>"; 
	excelFile += "<x:ExcelWorksheet>"; 
	excelFile += "<x:Name>"; 
	excelFile += "sheet"; 
	excelFile += "</x:Name>"; 
	excelFile += "<x:WorksheetOptions>"; 
	excelFile += "<x:DisplayGridlines/>"; 
	excelFile += "</x:WorksheetOptions>"; 
	excelFile += "</x:ExcelWorksheet>"; 
	excelFile += "</x:ExcelWorksheets>"; 
	excelFile += "</x:ExcelWorkbook>"; 
	excelFile += "</xml>"; 
	excelFile += "<![endif]-->"; 
	excelFile += "</head>";
	excelFile += "<body>"; 
	excelFile += excel; 
	excelFile += "</body>"; 
	excelFile += "</html>";
	var uri = 'data:application/vnd.ms-excel;charset=utf-8,' + encodeURIComponent(excelFile); 
	var link = document.createElement("a"); 
	link.href = uri; link.style = "visibility:hidden"; 
	link.download = FileName + ".xls"; 
	document.body.appendChild(link); 
	link.click(); 
	document.body.removeChild(link); 
}

function getTime(){
    var now = new Date();
    var nowString = now.getFullYear() + "-" +(now.getMonth() + 1) + "-" + now.getDate() +
        " " + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds();
    return nowString;
}
var version;
function getVersion(){
	var b=1;
	$.ajax({
		type:'get',
		async:false,
		url:server[0]._server_port+(server[0].mappings)[0]._interface,
		success:function(data){
			//if(data.data.version!=ExtensionInfo.version){
			if(data.data.version!="1.2.7"){
				chrome.browserAction.setBadgeText({text: 'New'});
				chrome.browserAction.setBadgeBackgroundColor({color: [255, 0, 0, 255]});
				version=JSON.parse(data).data.version;
				b= 2;
			}else{
				chrome.browserAction.setBadgeText({text: ''});
				chrome.browserAction.setBadgeBackgroundColor({color: [255, 0, 0, 255]});
				b= 1;
			}
		},
	error:function (data) {
		b=data.status;
    }

	})
	return b;
}


function downloadVersion(){
	chrome.tabs.create({url: server[0]._server_port+(server[0].mappings)[1]._interface+"?v="+version});
}

function Tip(value){
	alert(value);
}


function set_QuShu_Shop_whole_Data(val,loginUserName){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName},
		url:server[0]._server_port+"/storage/add_previewBySchema",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function set_QuShu_item_whole_topItem(val,loginUserName){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName},
		url:server[0]._server_port+"/storage/set_QuShu_item_whole_topItem",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

var category_status=true;
function addcategory(val,loginUserName){
	if(!category_status){
		return false;
	}
	category_status=false;
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName},
		url:server[0]._server_port+"/storage/addcategory",
		success:function(value){category_status=true;
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

var category_status=true;
function addshopCate(val,loginUserName){
	if(!category_status){
		return false;
	}
	category_status=false;
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName},
		url:server[0]._server_port+(server[0].mappings)[23]._interface,
		success:function(value){category_status=true;
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function reportIndex(val,loginUserName,date,cateId,dateType,device,seller){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],cateId:cateId,dateType:dateType,device:device,seller:seller},
		url:server[0]._server_port+(server[0].mappings)[14]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function reportTrend(val,loginUserName,date,cateId,dateType,device,seller){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],cateId:cateId,dateType:dateType,device:device,seller:seller},
		url:server[0]._server_port+(server[0].mappings)[20]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}


function mkt_trend_cate(val,loginUserName,date,cateId,dateType,device,seller,indexCode){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],cateId:cateId,dateType:dateType,device:device,seller:seller,indexCode:indexCode},
		url:server[0]._server_port+"/storage/mkt_trend_cate",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function marcro_core_trend(val,loginUserName,date,dateType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType},
		url:server[0]._server_port+(server[0].mappings)[41]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function marcro_item_top(val,loginUserName,date,dateType,device){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device},
		url:server[0]._server_port+"/storage/marcro_item_top",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mc_industry_theme_new(val,loginUserName,date,dateType,device,cateId){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId},
		url:server[0]._server_port+"/storage/mc_industry_theme_new",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mc_industry_theme_subject(val,loginUserName,date,dateType,device,cateId){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId},
		url:server[0]._server_port+"/storage/mc_industry_theme_subject",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mc_industry_searchWord(val,loginUserName,date,dateType,device,cateId){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId},
		url:server[0]._server_port+"/storage/mc_industry_searchWord",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mc_industry_tailWord(val,loginUserName,date,dateType,device,cateId){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId},
		url:server[0]._server_port+"/storage/mc_industry_tailWord",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}
function mc_industry_brandWord(val,loginUserName,date,dateType,device,cateId){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId},
		url:server[0]._server_port+"/storage/mc_industry_brandWord",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}
function mc_industry_coreWord(val,loginUserName,date,dateType,device,cateId){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId},
		url:server[0]._server_port+"/storage/mc_industry_coreWord",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}
function mc_industry_attrWord(val,loginUserName,date,dateType,device,cateId){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId},
		url:server[0]._server_port+"/storage/mc_industry_attrWord",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mkt_rank_shop_hotsale(val,loginUserName,date,dateType,device,cateId,sellerType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId,sellerType:sellerType},
		url:server[0]._server_port+(server[0].mappings)[51]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mkt_rank_shop_hotsearch(val,loginUserName,date,dateType,device,cateId,sellerType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId,sellerType:sellerType},
		url:server[0]._server_port+(server[0].mappings)[53]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}
function mkt_rank_item_hotsale(val,loginUserName,date,dateType,device,cateId,sellerType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId,sellerType:sellerType},
		url:server[0]._server_port+(server[0].mappings)[54]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mkt_rank_item_hotsearch(val,loginUserName,date,dateType,device,cateId,sellerType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId,sellerType:sellerType},
		url:server[0]._server_port+(server[0].mappings)[55]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mkt_rank_item_hotpurpose(val,loginUserName,date,dateType,device,cateId,sellerType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId,sellerType:sellerType},
		url:server[0]._server_port+(server[0].mappings)[56]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mkt_rank_brand_hotsale(val,loginUserName,date,dateType,device,cateId,sellerType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId,sellerType:sellerType},
		url:server[0]._server_port+(server[0].mappings)[57]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mkt_rank_brand_hotsearch(val,loginUserName,date,dateType,device,cateId,sellerType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,cateId:cateId,sellerType:sellerType},
		url:server[0]._server_port+(server[0].mappings)[58]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				alert(data.msg);
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function bda_visitor_distribution_listPeriods(val,loginUserName,date,dateType,device,index){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,index:index},
		url:server[0]._server_port+"/storage/bda_visitor_distribution_listPeriods",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){
			}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function bda_visitor_distribution_listAreas(val,loginUserName,date,dateType,device){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device},
		url:server[0]._server_port+"/storage/bda_visitor_distribution_listAreas",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function bda_visitor_distribution_listFeatures(val,loginUserName,date,dateType,device){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device},
		url:server[0]._server_port+"/storage/bda_visitor_distribution_listFeatures",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function bda_visitor_distribution_listBehaviors(val,loginUserName,date,dateType,device){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device},
		url:server[0]._server_port+"/storage/bda_visitor_distribution_listBehaviors",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){
			}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function bda_visitor_visitor_compares(val,loginUserName,date,dateType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType},
		url:server[0]._server_port+(server[0].mappings)[67]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mc_ci_config_rival_item_getMonitoredList(val,loginUserName,firstCateId,rivalType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,cateId:firstCateId,rivalType:rivalType},
		url:server[0]._server_port+(server[0].mappings)[68]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mc_rivalShop_recommend_item(val,loginUserName){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName},
		url:server[0]._server_port+(server[0].mappings)[69]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mc_rivalItem_analysis_getCoreTrend(val,loginUserName,date,dateType,device,selfItemId,rivalItem1Id,rivalItem2Id,cateId){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,selfItemId:selfItemId,rivalItem1Id:rivalItem1Id,rivalItem2Id:rivalItem2Id,cateId:cateId},
		url:server[0]._server_port+(server[0].mappings)[70]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}


function ipoll_live_getFlowAndPay(val,loginUserName){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName},
		url:server[0]._server_port+'/storage/ipoll_live_getFlowAndPay',
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}


function mc_rivalItem_analysis_getKeywords(val,loginUserName,date,dateType,device,sellerType,cateId,itemId,topType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device
			,sellerType:sellerType,cateId:cateId,itemId:itemId,topType:topType},
		url:server[0]._server_port+(server[0].mappings)[73]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});				
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function mc_rivalItem_analysis_getFlowSource(val,loginUserName,date,dateType,device,cateId,selfItemId,rivalItem1Id,rivalItem2Id){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device
			,cateId:cateId,selfItemId:selfItemId,rivalItem1Id:rivalItem1Id,rivalItem2Id:rivalItem2Id},
		url:server[0]._server_port+(server[0].mappings)[74]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function flow_v3_shop_source_tree(val,loginUserName,date,dateType,device,belong,itemId){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device
			,belong:belong},
		url:server[0]._server_port+"/storage/flow_v3_shop_source_tree",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function flow_v3_item_source(val,loginUserName,date,dateType,device,belong,itemId){
	if(dateType!='day')return ;
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device
			,belong:belong,itemId:itemId},
		url:server[0]._server_port+"/storage/flow_v3_item_source",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function bda_toolbox_wordAide_getSearchKeys(val,loginUserName,date,dateType,device,kwType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,kwType:kwType
			},
		url:server[0]._server_port+"/storage/bda_toolbox_wordAide_getSearchKeys",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {
					
				});
				
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}


function flow_wordAide_competitionSearch(val,loginUserName,date,dateType,device,kwType,rivalSellerId){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,kwType:kwType,rivalSellerId:rivalSellerId
			},
		url:server[0]._server_port+(server[0].mappings)[113]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {
					
				});
				
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function set_tmall_flow_daily(val,tmall_loginName,response,ctoken){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:tmall_loginName.split(",")[1],shopid:tmall_loginName.split(",")[0]},
		url:server[0]._server_port+(server[0].mappings)[114]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function set_postListReplenishAdvice(val,tmall_loginName,response,computeTimeEnd){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:tmall_loginName.split(",")[1],shopid:tmall_loginName.split(",")[0]},
		url:server[0]._server_port+(server[0].mappings)[115]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function set_queryIndexData(val,tmall_loginName,query){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:tmall_loginName.split(",")[1],shopid:tmall_loginName.split(",")[0],date:JSON.parse(decodeURIComponent(query)).bizdate},
		url:server[0]._server_port+(server[0].mappings)[116]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function bda_flow_flowmap_shopPagePathFlow(val,loginUserName,date,dateType,device,deviceLogicType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device
			,deviceLogicType:deviceLogicType},
		url:server[0]._server_port+(server[0].mappings)[80]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {
					
				});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function tipUserLogin(val,loginUserName,url){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,url:url},
		url:server[0]._server_port+(server[0].mappings)[81]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {
					
				});
			}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function bda_flow_flowmap_shopPageVisitorRank(val,loginUserName,date,dateType,device,deviceLogicType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device
			,deviceLogicType:deviceLogicType},
		url:server[0]._server_port+(server[0].mappings)[85]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function bda_flow_flowmap_pageLeaveRank(val,loginUserName,date,dateType,device,deviceLogicType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device
			,deviceLogicType:deviceLogicType},
		url:server[0]._server_port+(server[0].mappings)[87]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function bda_flow_flowmap_pageDestRank(val,loginUserName,date,dateType,device,deviceLogicType){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device
			,deviceLogicType:deviceLogicType},
		url:server[0]._server_port+(server[0].mappings)[88]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {
					
				});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function flow_new_item_itemSearch(val,loginUserName){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName},
		url:server[0]._server_port+"/storage/flow_new_item_itemSearch",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function flow_configuration_page(val,loginUserName,appType,dateType,date,pageId){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,appType:appType,pageId:pageId},
		url:server[0]._server_port+'/storage/flow_configuration_page',
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {
					
				});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function competition_goods_customer(val,loginUserName,date,dateType,cateId){	
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,cateId:cateId},
		url:server[0]._server_port+"/storage/competition_goods_customer",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {
					
				});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function competition_goods_customer_whereabouts(val,loginUserName,date,dateType,device,cateId,itemId){	
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,cateId:cateId,device:device,itemId:itemId},
		url:server[0]._server_port+"/storage/competition_goods_customer_whereabouts",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {
					
				});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function competition_goods_search(val,loginUserName,date,dateType,device,cateId,indexCode){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,cateId:cateId,type:indexCode.split(',')[2].split('SeGuide')[1],device:device},
		url:server[0]._server_port+(server[0].mappings)[96]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {
					
				});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function competition_goods_search_whereabouts(val,loginUserName,date,dateType,device,cateId,itemId){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,cateId:cateId,device:device,itemId:itemId},
		url:server[0]._server_port+(server[0].mappings)[110]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {
					
				});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function rank_getCoreItemEffectRank(val,loginUserName,device,page){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,device:device,dataTime:'2019-03-31 13',page:page},
		url:server[0]._server_port+'/push/tb/rank_getCoreItemEffectRank',
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {
					
				});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function getFlowProductList(val,loginUserName,date,dateType,device){
	if(dateType!='day')return ;
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device},
		url:server[0]._server_port+"/storage/flow_new_monitor_item_tops_rank",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {
					
				});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

chrome.tabs.onCreated.addListener(function(tab) {
	startDebugger()
});
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo,tab) {
	startDebugger()
});



function getQQ(count){
	var qq="";
	$.each(count,function(){
		qq=qq+Math.random()*10;
	})
	return qq;
}

function generateMixed(n) {
	var chars = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
     var res = "";
     for(var i = 0; i < n ; i ++) {
         var id = Math.ceil(Math.random()*35);
         res += chars[id];
     }
     return res;
}

var kw_status=true;
function Keyword_qushi(val,loginUserName,date,dateType,device,_keyword){

//	if(keyWord==""||keyWord==null){
//		getKeyWord();
//	}
//	var boolean=false;
//	$.each(keyWord,function(){
//		if(this.keyword.toLowerCase()==_keyword.toLowerCase()){
//			boolean=true;
//		}
//	})
//	if(!boolean){
//		chrome.tabs.sendRequest(_source.tabId, {data: '先添加改关键词"'+_keyword+'",再抓取！',cmd:"tip"}, function(value) {});
//		return false;
//	}
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,keyword:_keyword},
		url:server[0]._server_port+"/storage/Keyword_qushi",
		success:function(value){kw_status=true;
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

var keyWord=[];
function getKeyWord(){
	$.ajax({
		type:'get',
		async:false,
		url:server[0]._server_port+(server[0].mappings)[25]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==1){
				keyWord=data.data;
				return true;
			}else if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}else{
					alert(data.msg)
			}
			return false;
		}
	})
}



function searchword_relatedWord(val,loginUserName,date,dateType,device,_keyword){
//	if(keyWord==""||keyWord==null){
//		getKeyWord();
//	}
//	var boolean=false;
//	$.each(keyWord,function(){
//		if(this.keyword.toLowerCase()==_keyword.toLowerCase()){
//			boolean=true;
//		}
//	})
//	if(!boolean){
//		chrome.tabs.sendRequest(_source.tabId, {data: '先添加改关键词"'+_keyword+'",再抓取！',cmd:"tip"}, function(value) {});
//		return false;
//	}
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,keyword:_keyword},
		url:server[0]._server_port+"/storage/searchword_relatedWord",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}


function searchword_relatedBrand(val,loginUserName,date,dateType,device,_keyword){
//	if(keyWord==""||keyWord==null){
//		getKeyWord();
//	}
//	var boolean=false;
//	$.each(keyWord,function(){
//		if(this.keyword.toLowerCase()==_keyword.toLowerCase()){
//			boolean=true;
//		}
//	})
//	if(!boolean){
//		chrome.tabs.sendRequest(_source.tabId, {data: '先添加改关键词"'+_keyword+'",再抓取！',cmd:"tip"}, function(value) {});
//		return false;
//	}
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,keyword:_keyword},
		url:server[0]._server_port+"/storage/searchword_relatedBrand",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function searchword_relatedProperty(val,loginUserName,date,dateType,device,_keyword){
//	if(keyWord==""||keyWord==null){
//		getKeyWord();
//	}
//	var boolean=false;
//	$.each(keyWord,function(){
//		if(this.keyword.toLowerCase()==_keyword.toLowerCase()){
//			boolean=true;
//		}
//	})
//	if(!boolean){
//		chrome.tabs.sendRequest(_source.tabId, {data: '先添加改关键词"'+_keyword+'",再抓取！',cmd:"tip"}, function(value) {});
//		return false;
//	}
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,keyword:_keyword},
		url:server[0]._server_port+"/storage/searchword_relatedProperty",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}
function searchword_relatedHotWord(val,loginUserName,date,dateType,device,_keyword){
//	if(keyWord==""||keyWord==null){
//		getKeyWord();
//	}
//	var boolean=false;
//	$.each(keyWord,function(){
//		if(this.keyword.toLowerCase()==_keyword.toLowerCase()){
//			boolean=true;
//		}
//	})
//	if(!boolean){
//		chrome.tabs.sendRequest(_source.tabId, {data: '先添加改关键词"'+_keyword+'",再抓取！',cmd:"tip"}, function(value) {});
//		return false;
//	}
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,keyword:_keyword},
		url:server[0]._server_port+"/storage/searchword_relatedHotWord",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {
					
				});
			}
		}
	})
}

function searchword_getCategory(val,loginUserName,date,dateType,device,_keyword,level1Id){
//	if(keyWord==""||keyWord==null){
//		getKeyWord();
//	}
//	var boolean=false;
//	$.each(keyWord,function(){
//		if(this.keyword.toLowerCase()==_keyword.toLowerCase()){
//			boolean=true;
//		}
//	})
//	if(!boolean){
//		chrome.tabs.sendRequest(_source.tabId, {data: '先添加改关键词"'+_keyword+'",再抓取！',cmd:"tip"}, function(value) {});
//		return false;
//	}
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,startDate:date.split('|')[0],endDate:date.split('|')[1],dateType:dateType,device:device,keyword:_keyword,top_category:level1Id},
		url:server[0]._server_port+"/storage/searchword_getCategory",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

var injection_KeyWords;
function getKeyWords(){
	$.ajax({
		type:'get',
		async:false,
		url:server[0]._server_port+(server[0].mappings)[25]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==1){
				injection_KeyWords=data.data;
			}
		}
	})
}

function topListData(val,loginUserName,orderBy){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,orderBy:orderBy},
		url:server[0]._server_port+'/push/jd/topListData',
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function getProductList(val,loginUserName,type,startDate,endDate){
	if(startDate!=endDate)return ;
	if(type!=1)return ;
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,type:type,startDate:startDate,endDate:endDate,dateType:'day'},
		url:server[0]._server_port+"/flagship/store/getProductList",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function setBrandAndCategoryNew(val,loginUserName){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName},
		url:server[0]._server_port+"/flagship/store/setBrandAndCategoryNew",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}
function setIndustryKeywordsData(val,loginUserName,firstCategoryId,secondCategoryId,thirdCategoryId,channel,startDate,endDate,orderBy,date){
	let cid=firstCategoryId==""?"":firstCategoryId;
		cid=secondCategoryId==""?cid:secondCategoryId;
		cid=thirdCategoryId==""?cid:thirdCategoryId;
		//if((new Date(endDate).getTime() - new Date(startDate).getTime())/ (1000 * 60 * 60 * 24)>7)
		//if(orderBy!='SearchIndex')return ;
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,
			cid:cid,
			channel:channel,
			startDate:startDate,
			endDate:endDate,
			dateType:'day',
			modelType:orderBy
		},
		url:server[0]._server_port+"/flagship/store/setIndustryKeywordsData",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}
function setOldAndNewConsumerData(val,loginUserName,firstCategoryId,secondCategoryId,thirdCategoryId,channel,brandId,shopType,repurchaseId,startDate,endDate,orderBy,date){
	console.log(val)
	let cid=firstCategoryId==""?"":firstCategoryId;
		cid=secondCategoryId==""?cid:secondCategoryId;
		cid=thirdCategoryId==""?cid:thirdCategoryId;
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,
			cid:cid,
			channel:channel,
			shopType:shopType,
			repurchaseId:repurchaseId,
		},
		url:server[0]._server_port+"/flagship/store/setOldAndNewConsumerData",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function setallproductdetail(val,loginUserName,firstCategoryId,secondCategoryId,thirdCategoryId,channel,brandId,shopType,repurchaseId,startDate,endDate,orderBy,date,pageNum){
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,
			startDate:startDate,
			endDate:endDate,
			pageNum:pageNum
		},
		url:server[0]._server_port+"/flagship/store/setallproductdetail",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function setLossDirectionData(val,loginUserName,startDate,endDate,channel,skuId){
	if(channel!=0)return ;
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,
			startDate:startDate,
			endDate:endDate,
			channel:channel,
			skuId :skuId
		},
		url:server[0]._server_port+"/flagship/store/setLossDirectionData",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function setindustryFeature(val,loginUserName,startDate,endDate,channel,brandId,shopType,cid){
	if(channel!=0)return ;
	if(brandId!='all')return ;
	if(shopType!='all')return ;
	if(startDate!=endDate)return ;
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,
			startDate:startDate,
			endDate:endDate,
			cid:cid
		},
		url:server[0]._server_port+"/flagship/store/setindustryFeature",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}


function setBrandGridData(val,loginUserName,startDate,endDate,channel,brandId,shopType,cid){
	if(channel!=0)return ;
	if(brandId!='all')return ;
	if(shopType!='all')return ;
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,
			startDate:startDate,
			endDate:endDate,
			cid:cid
		},
		url:server[0]._server_port+"/flagship/store/setBrandGridData",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function setSearchGridData(val,loginUserName,startDate,endDate,channel,brandId,shopType,cids,pageNum){
	if(pageNum>50)return ;
	if(channel!=0)return ;
	//if(brandId!='all')return ;
	if(shopType!='all')return ;
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,
			startDate:startDate,
			endDate:endDate,
			channel:channel,
			brandId:brandId,
			shopType:shopType,
			cids:cids
		},
		url:server[0]._server_port+(server[0].mappingsjd)[11]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function setindustryFeatureCity(val,loginUserName,startDate,endDate,channel,brandId,shopType,provinceId,cid){
	if(channel!=0)return ;
	if(brandId!='all')return ;
	if(shopType!='all')return ;
	if(startDate!=endDate)return ;
	$.ajax({
		type:"post",
		data:{data:val,mainUserName:loginUserName,
			startDate:startDate,
			endDate:endDate,
			provinceId:provinceId,
			cid:cid
		},
		url:server[0]._server_port+"/flagship/store/setindustryFeatureCity",
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==-2){
				alert(data.msg);
			}
			if(data.status==-1){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
			if(data.status==2){}
			if(data.status==0){
				chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
			}
		}
	})
}

function setAreaData(val,loginUserName,areaType){
	let starttime = new Date(Date.parse(new Date().getFullYear()+"-"+(new Date().getMonth()+1)+"-"+new Date().getDate()+" 23:40"));
	let endtime = new Date(Date.parse(new Date().getFullYear()+"-"+(new Date().getMonth()+1)+"-"+new Date().getDate()+" 23:59"));
	if(new Date()>=starttime && new Date()<=endtime){
		$.ajax({
			type:"post",
			data:{data:val,mainUserName:loginUserName,
				areaType:areaType
			},
			url:server[0]._server_port+"/flagship/store/setAreaData",
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==-2){
					alert(data.msg);
				}
				if(data.status==-1){
					chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
				}
				if(data.status==2){}
				if(data.status==0){
					chrome.tabs.sendRequest(_source.tabId, {data: data.msg,cmd:"tip"}, function(value) {});
				}
			}
		})
	}else{
		console.log("不在时间范围")
	}
	
	
}

chrome.runtime.onMessageExternal.addListener(function(request, sender, sendResponse) {
	  if (request.type == 'keyWords') {
		  if(localStorage.keyWords==null){
			  $.ajax({
					type:'get',
					async:false,
					url:server[0]._server_port+(server[0].mappings)[25]._interface,
					success:function(value){
						var data={};
						if(Object.prototype.toString.call(value)=="[object String]"){
							data=JSON.parse(value);
						}
						if(Object.prototype.toString.call(value)=="[object Object]"){
							data=value;
						}
						if(data.status==1){
							localStorage.setItem("keyWords", JSON.stringify(data.data));
							sendResponse(data.data);
						}
					}
				})
		  }else{
			  sendResponse(JSON.parse(localStorage.keyWords));
		  }
	  }
	  
	  if(request.type == "login"){
		  window.open("../html/popupl")
	  }
	  
	  if(request.type == "flow_configuration_page_picture"){
		 //alert(JSON.stringify(request.data));
		 $.ajax({
				type:'post',
				async:false,
				data:{
					data:JSON.stringify(request.data),
					mainUserName:JSON.parse(JSON.parse(localStorage.tab_loginInfo)).data.loginUserName,
					startDate:request.date
				},
				url:server[0]._server_port+"/storage/flow_configuration_page_picture",
				success:function(value){
					var data={};
					if(Object.prototype.toString.call(value)=="[object String]"){
						data=JSON.parse(value);
					}
					if(Object.prototype.toString.call(value)=="[object Object]"){
						data=value;
					}
					if(data.status==1){
						sendResponse("success!");
					}
				}
			})
		 
	  }
	  
	  if(request.type == "getproductList"){
			 //alert(JSON.stringify(request.data));
			 $.ajax({
					type:'post',
					async:false,
					data:{
						device:request.device,
						mainUserName:JSON.parse(JSON.parse(localStorage.tab_loginInfo)).data.loginUserName,
						startDate:request.date,
						belong:request.belong
					},
					url:server[0]._server_port+"/flagship/store/getProductList",
					success:function(value){
						var data={};
						if(Object.prototype.toString.call(value)=="[object String]"){
							data=JSON.parse(value);
						}
						if(Object.prototype.toString.call(value)=="[object Object]"){
							data=value;
						}
						if(data.status==1){
							sendResponse(value);
						}
					}
				})
			 
		  }
	});
var _cpu,_storage,_display;
function sysinfo(){
	chrome.system.cpu.getInfo(function(info){
	    _cpu=info;
	});
	chrome.system.storage.getInfo(function(info){
		_storage=info;
	});
	chrome.system.display.getInfo(function(info){
		_display=info;
	});
}

function getSystemInfo(){
	return _storage[0].id+'-'+_display[0].id;
}
setInterval(function() {
	location.reload();
}, 60*60*1000);

chrome.webRequest.onBeforeRequest.addListener(initialListener, {urls: ["https://sycm.taobao.com/*","https://*.jd.com/*","*://*.tmall.com/*"]}, ["blocking"]);
$(document).ready(function(){
	startDebugger();
	sysinfo()
//	_i();
//	_ijd();
//	_jdurl();
//	_tburl();
})