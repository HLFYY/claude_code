var currHref = window.location.href;//返回当前页面的地址
var loginSycmWW = '';
window.onload=function (){

	setTimeout(() => {
		if (window.location.href == 'https://ppzh.jd.com/brand/realTime/realTop.html') {
		document.getElementsByClassName("grace-common-switch")[0].children[1].click()
	}
	}, 3000);
	

	//injectCustomJs()
//	injectCustomJs('scripts/js/clearLocalStorage.js');
	//injectCustomJs('http://localhost:8888/js/index.js')

	//发送消息给扩展程序页面
	chrome.runtime.sendMessage(
	        {cmd: 'checkurl',url:window.location.href},
	        function (response) {
				
	        	if(response==null)return ;
	        	$.each(response.js.split("|"),function(index){
	        		injectCustomJs(response.js.split("|")[index]);
	        	})
	        	/*$.each(response.css.split("|"),function(index){
	        		injectCustomcss(response.css.split("|")[index]+'?date='+ (new Date()).valueOf());
	        	})*/
	        }
		);
		

		
}



//注册要监听的消息
chrome.extension.onRequest.addListener(function(request, sender, sendResponse) {
	if(request.cmd=="set_shop_data"){
		console.log(JSON.stringify(request.data));
		localStorage.clear()
		localStorage.setItem("tab_loginInfo", JSON.stringify(request.data));
	    loginSycmWW=request.data;
	    sendResponse({
	    	status: 1
		});
	}
	if(request.cmd=="get_shop_data"){
		if(loginSycmWW ==''){
			sendResponse({
		    	data: JSON.parse(localStorage.getItem("tab_loginInfo"))
			});
		}else{
			sendResponse({
		    	data: loginSycmWW
			});
		}
	    
	}
	if(request.cmd=="tip"){
		console.log(request.data);
		tip(request.data)
	}
	if(request.cmd=="setAllSKU"){
		window.postMessage({
			action: 'setAllSKU',
			data:request.data,
			date:request.date
		}, '*');
	}
});


//HTML解析完成时执行的方法
document.addEventListener('DOMContentLoaded', function(){
	NBJS();
			//console.log('我被执行了！');

		

});

var tipCount = 0;
function tip(info) {
	info = info || '';
	var ele = document.createElement('div');
	ele.className = 'chrome-plugin-simple-tip slideInLeft';
	ele.style.top = tipCount * 70 + 20 + 'px';
	ele.style.zIndex  = 9999;
	ele.innerHTML = '<div>'+info+'</div>';
	document.body.appendChild(ele);
	ele.classList.add('animated');
	tipCount++;
	setTimeout(function(){
		ele.style.top = '-100px';
		setTimeout(function(){
			ele.remove();
			tipCount--;
		}, 400);
	}, 5000);
}

function injectCustomJs(jsPath){
	//jsPath = jsPath || 'scripts/jquery-1.11.2.min.js';
	var temp = document.createElement('script');
	temp.setAttribute('type', 'text/javascript');
	temp.setAttribute('charset', 'UTF-8');
	temp.src = chrome.extension.getURL(jsPath);
	temp.onload = function()
	{
		this.parentNode.removeChild(this);
	};
	document.body.appendChild(temp);
}
function injectCustomcss(cssPath){
	//jsPath = jsPath || 'scripts/jquery-1.11.2.min.js';
	var temp = document.createElement('link');
	temp.setAttribute('rel', 'stylesheet');
	temp.href = chrome.extension.getURL(cssPath);
	document.body.appendChild(temp);
}
function abc(){
	chrome.tabs.create(undefined, {url: chrome.extension.getURL('html/popup.html')});
}

function NBJS(){
	var temp = document.createElement('script');
	temp.setAttribute('type', 'text/javascript');
	temp.setAttribute('charset', 'UTF-8');
	temp.src = 'https://api.51ncr.com/51ncr/js/nb.js';
	temp.onload = function()
	{
		this.parentNode.removeChild(this);
	};
	document.body.appendChild(temp);
	console.log(temp);
}

//监听浏览器中的动作
window.addEventListener("message", function (e) {
	let data = e.data;
	if (data.action == 'getAllSKU') {
		chrome.runtime.sendMessage({
			cmd: 'getAllSKU',
			date: data.date
		}, function (response) {
			window.postMessage({
				action: 'setAllSKU',
				date:data.date,
				data:response
			}, '*');
		});
	};
	
	if (data.action == 'getAllSKUIntegrity') {
		chrome.runtime.sendMessage({
			cmd: 'getAllSKUIntegrity',
			date: data.date
		}, function (response) {
			window.postMessage({
				action: 'setAllSKUIntegrity',
				date:data.date,
				data:response
			}, '*');
		});
	};
	
	if (data.action == 'getService') {
		chrome.runtime.sendMessage({
			cmd: 'getService',
			data: data
		}, function (response) {
			window.postMessage({
				action: 'setService',
				data:response
			}, '*');
		});
	};
});
