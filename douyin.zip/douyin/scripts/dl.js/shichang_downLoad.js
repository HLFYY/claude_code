$(".marketBtn").click(function(){
	parameterTip()
	showData()
})
$.ajaxSetup({
	crossDomain : true,
	xhrFields : {
		withCredentials : true
	}
});
$(document).ready(function() {
	$("#checkbox001").click()
	init_top_category();
	init_report_index();
	getKeyWord()
});

function getKeyWord(){
	$.ajax({
		type:'get',
		async:false,
		url:server[0]._server_port+(server[0].mappings)[25]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$("#keyWord_select").html('')//<option value="">全部关键词</option>
				$.each(data.data,function(){
					$("#keyWord_select").append('<option value="'+this.keyword+'">'+this.keyword+'</option>')
				})
			}else
				if(data.status==-1){
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
				}else{
					alert(data.msg)
				}
		}
	})
}
var report_index=[];
function init_report_index(){
	$.ajax({
		type:'post',
		url:server[0]._server_port+(server[0].mappings)[21]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$.each(data.data,function(index){
					if(index==0){
						report_index.push(this.indexCode);
						$("#report_index").append('<div > <input type="checkbox" class="magic-radio" id="checkbox_'+this.indexCode+'" checked="checked"> <label for="checkbox_'+this.indexCode+'" >'+this.name+'</label> </div>');
					}else{
						$("#report_index").append('<div > <input type="checkbox" class="magic-radio" id="checkbox_'+this.indexCode+'" > <label for="checkbox_'+this.indexCode+'" >'+this.name+'</label> </div>');
					}
				})
			}
		}
	})
}
function init_top_category(){
	$.ajax({
		type:"post",
		xhrFields:{withCredentials:true},
		url:server[0]._server_port+(server[0].mappings)[17]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$.each(data.data,function(index){
					if(index==0)category_id=this.cid
				$(".category1").append('<li value="'+this.cid+'" status="T"><span title="'+this.name+'">'+this.name+'</span></li>')
			})
			}
		}
	})
}
$(".selectCategory").on("mouseover", "li", function() {
	var obj=$(this);
	var name=$(this).text();
	var cg=$(this).parent().attr('class');
	$.ajax({
		type:"post",
		data:{categoryId:$(this).attr("value")},
		url:server[0]._server_port+(server[0].mappings)[15]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				if(data.data.length>0){
					obj.html("");
					obj.append('<span title="'+name+'">'+name+'</span><i class="iconfont icon-youjiantou pull-right"></i>');
				}
				if(cg=="category1"){
					$(".category2").html("")
					$.each(data.data,function(index){
						$(".category2").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
					})
				}
				if(cg=="category2"){
					$(".category3").html("")
					$.each(data.data,function(index){
						$(".category3").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
					})
				}
			}
		}
	})
});
$(".selectCategory>span").click(function(e){
	$(".selectCategory>div").show(500);
	e.stopPropagation();
    $(document,".fa-times").click(function(){
      $(".selectCategory>div").hide(500);
    })
})
var category_id='';
var category_name="";
var report_status=true;
$("#categoryDiv").on("mouseup", "li", function() {
	if($(this).attr("status")=='T'){
		report_status=true
	}else{
		report_status=false
	}
	_switch();
	$(".selectCategory>div").hide(500);
	category_id=$(this).attr("value");
	category_name=$(this).text()
	$(".selectCategory>span").text($(this).text());
	$(this).addClass("active").siblings("li").removeClass("active");
	//showData()
});
function _switch(){
	if(report_status){
		$("#checkbox_payByrCntIndex").parent().hide()
		$("#checkbox_payByrCntIndex").prop("checked",false);
		$("#checkbox_seIpvUvHits").parent().hide()
		$("#checkbox_seIpvUvHits").prop("checked",false);
		$("#checkbox_sePvIndex").parent().hide()
		$("#checkbox_sePvIndex").prop("checked",false);
		$("#checkbox_tradeIndex").parent().hide()
		$("#checkbox_tradeIndex").prop("checked",false);
	}else{
		$("#checkbox_payByrCntIndex").parent().show()
		$("#checkbox_seIpvUvHits").parent().show()
		$("#checkbox_sePvIndex").parent().show()
		$("#checkbox_tradeIndex").parent().show()
	}
}
var dateType = 'day';
// 选择日期
$("#checkbox131").click(function() {
	$("#checkbox132,#checkbox133").prop("checked", false);
	$(".monthBox,.weekBox,.dateBox").hide();
	$(".dateBox").show();
	dateType = 'day';
})
$("#checkbox132").click(function() {
	if($("#checkbox012").prop('checked')){
		alert("相关词分析暂时没有周和月")
		return false;
	}
	if($("#checkbox003").prop('checked')){
		alert("暂时没有周和月")
		return false;
	}
	$("#checkbox131,#checkbox133").prop("checked", false);
	$(".monthBox,.weekBox,.dateBox").hide();
	$(".weekBox").show();
	dateType = 'week';
})
$("#checkbox133").click(function() {
	if($("#checkbox012").prop('checked')){
		alert("相关词分析暂时没有周和月")
		return false;
	}
	if($("#checkbox003").prop('checked')){
		alert("暂时没有周和月")
		return false;
	}
	$("#checkbox132,#checkbox131").prop("checked", false);
	$(".monthBox,.weekBox,.dateBox").hide();
	$(".monthBox").show();
	dateType = 'month';
})

var btn_type=1;

$("#checkbox001").click(function(){btn_type=1
	if($("#checkbox001").prop('checked')){
		$("#erji").hide(100)
		$("#sanji").hide(100)
		$("#keyWord_catagory").hide(100)
		$("#categoryDiv").parent().show(200)
		$("#report_index").parent().show(200)
		$("#checkbox222").parent().parent().show(200)
		$("#checkbox2411").parent().parent().hide()
		$("#checkbox3411").parent().parent().hide()
		$("#checkbox2431").parent().parent().hide()
		$("#checkbox_market_rank_1").parent().parent().hide()
		$("#checkbox_market_rank_type_1").parent().parent().hide()
	}
})

$("#checkbox003").click(function(){btn_type=8
	if($("#checkbox003").prop('checked')){
		$("#checkbox131").click()
		$("#erji").hide(100)
		$("#sanji").hide(100)
		$("#keyWord_catagory").hide(100)
		$("#categoryDiv").parent().show(200)
		$("#checkbox222").parent().parent().show()
		$("#checkbox221").parent().parent().hide()
		$("#checkbox000").parent().parent().hide()
		$("#checkbox2411").parent().parent().show(200)
		$("#checkbox3411").parent().parent().show(200)
		$("#checkbox2431").parent().parent().show(200)
		$("#checkbox_market_rank_1").parent().parent().hide()
		$("#checkbox_market_rank_type_1").parent().parent().hide()
	}
})

$("#checkbox004").click(function(){btn_type=9
	if($("#checkbox004").prop('checked')){
		$("#checkbox131").click()
		$("#erji").hide(100)
		$("#sanji").hide(100)
		$("#keyWord_catagory").hide()
		$("#categoryDiv").parent().show(200)
		$("#checkbox222").parent().parent().show()
		$("#checkbox221").parent().parent().hide()
		$("#checkbox000").parent().parent().hide()
		$("#checkbox3411").parent().parent().hide()
		$("#checkbox2431").parent().parent().hide()
		$("#checkbox221").parent().parent().show(200)
		$("#checkbox_market_rank_1").parent().parent().show(200)
		$("#checkbox_market_rank_type_1").parent().parent().show(200)
	}
})

$("#checkbox002").click(function(){
	if($("#checkbox002").prop('checked')){
		$("#erji").show(200)
		$("#categoryDiv").parent().hide(100)
		$("#report_index").parent().hide(100)
		$("#keyWord_catagory").hide(100)
		$("#sanji").hide(100)
		$("#keyWord_catagory").show(200)
		$("#parent_cateId").parent().hide(100)
		$("#checkbox222").parent().parent().hide(100)
		$("#checkbox2431").parent().parent().hide()
		if($("#checkbox011").prop('checked')){
			btn_type=2
		}
		if($("#checkbox012").prop('checked')){
			$("#sanji").show(200)
		}
		if($("#checkbox013").prop('checked')){btn_type=3
			$("#keyWord_catagory").show(200)
			$("#parent_cateId").parent().show(200)
		}
		$("#checkbox2411").parent().parent().hide(200)
		$("#checkbox3411").parent().parent().hide(200)
		$("#checkbox_market_rank_1").parent().parent().hide()
		$("#checkbox_market_rank_type_1").parent().parent().hide()
	}
})
$("#checkbox011").click(function(){btn_type=2
	if($("#checkbox011").prop('checked')){
		$("#sanji").hide(100)
		$("#keyWord_catagory").show(200)
		$("#parent_cateId").parent().hide(100)
	}
})
$("#checkbox012").click(function(){
	if($("#checkbox012").prop('checked')){
		$("#checkbox131").click()
		$("#sanji").show(200)
		$("#keyWord_catagory").show(200)
		$("#parent_cateId").parent().hide(100)
		if($("#checkbox021").prop('checked')){
			btn_type=4
		}
	}
})
$("#checkbox013").click(function(){btn_type=3
	if($("#checkbox013").prop('checked')){
		$("#sanji").hide(100)
		$("#keyWord_catagory").show(200)
		$("#parent_cateId").parent().show(200)
	}
})

$("#checkbox021").click(function(){
	btn_type=4
})
$("#checkbox022").click(function(){
	btn_type=5
})
$("#checkbox023").click(function(){
	btn_type=6
})
$("#checkbox024").click(function(){
	btn_type=7
})


$(".dateBox").change(function(){
	if(btn_type==3){
		getParent_category(".dateBox")
	}
})
$(".weekBox").change(function(){
	if(btn_type==3){
		getParent_category(".weekBox")
	}
	
})
$(".monthBox").change(function(){
	if(btn_type==3){
		getParent_category(".monthBox")
	}
})
$("#keyWord_select").change(function(){
	if(dateType=="day"){
		getParent_category(".dateBox")
	}
	if(dateType=="week"){
		getParent_category(".weekBox")
	}
	if(dateType=="month"){
		getParent_category(".monthBox")
	}
})
function getParent_category(val){
	$.ajax({
		type:'post',
		async:false,
		data:{
			startDate:$(val).find("input")[0].value.trim(),
			dateType:dateType,
			keyword:$("#keyWord_select").val(),
			device:terminal_id
			},
		url:server[0]._server_port+(server[0].mappings)[33]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$("#parent_cateId").html('')
				if(data.data.length>0){
					$.each(data.data,function(){
						$("#parent_cateId").append('<option value="'+this.cateId+'">'+this.cateName+'</option>')
					})
				}else{
					$("#parent_cateId").append('<option value="">'+$(".dateBox").find("input")[0].value.trim()+'号未抓类目</option>')
				}
				
			}else if(data.status==-1){
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
			}else{
					alert(data.msg)
			}
		}
	})

}

var download_date=[];
function showData(){
	page=1;
	pageSize=10;
	download_date=[];
	$("#page").hide();
	$("#scph_date").html("")
	$("#scph_title").html("")
	$("#scph_data").html("")
	if(btn_type==1){
		tjcheckBox();
		
		if (dateType == "day") {
			getDate_sc_hydp_day()
		}
		if (dateType == "week") {
			getDate_sc_hydp_week()
		}
		if (dateType == "month") {
			getDate_sc_hydp_month()
		}
		
	}
	if(btn_type==2){
		if (dateType == "day") {
			market_keyword_day(30)
		}
		if (dateType == "week") {
			market_keyword_week(30)
		}
		if (dateType == "month") {
			market_keyword_month(30)
		}
		
	}
	if(btn_type==3){
		if (dateType == "day") {
			market_leimugoucheng_keyword_day(32)
		}
		if (dateType == "week") {
			market_leimugoucheng_keyword_week(32)
		}
		if (dateType == "month") {
			market_leimugoucheng_keyword_month(32)
		}
		
	}
	if(btn_type==4){
		market_keyword(31)
	}
	if(btn_type==5){
		market_keyword(31)
	}
	if(btn_type==6){
		market_keyword(31)
	}
	if(btn_type==7){
		market_keyword(31)
	}
	if(btn_type==8){
		market_search_rank()
	}
	if(btn_type==9){
		if (dateType == "day") {
			market_rank_day()
		}
		if (dateType == "week") {
			market_rank_week()
		}
		if (dateType == "month") {
			market_rank_month()
		}
	}
}

function market_rank_month(){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))
	var boolean=true;
	for(var i=0;i<=count;i++){
		var tr_id=getMonth(startDate,i);
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType,
				tab:market_rank_tab,
				tabOne:market_rank_tabOne,
				device:terminal_id,
				sellerId:seller_id,
				categoryId:category_id,
			},
			url:server[0]._server_port+(server[0].mappings)[59]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index+1>count){index=0;
						if(boolean){
							$(".timeSelect").html('')
							for(var j=0;j<=count;j++){
								var tr_id=getMonth(startDate,j);
								download_date.push(tr_id);
								if(j==0){
									Pangolin_market_rank_preview(tr_id,endDate);
									$(".timeSelect").append('<span class="active" value="'+tr_id+'">'+tr_id.split('-')[0]+'年'+tr_id.split('-')[1]+'月</span>');
								}else{
									$(".timeSelect").append('<span value="'+tr_id+'">'+tr_id.split('-')[0]+'年'+tr_id.split('-')[1]+'月</span>');
								}
							}
						}
						
					}
				}
			}
		})
	}
}

function market_rank_week(){

	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}
	var boolean=true;
	for(var i=0;i<count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType,
				tab:market_rank_tab,
				tabOne:market_rank_tabOne,
				device:terminal_id,
				sellerId:seller_id,
				categoryId:category_id,
			},
			url:server[0]._server_port+(server[0].mappings)[59]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index+1>count){index=0;
						if(boolean){
							$(".timeSelect").html('')
							for(var j=0;j<count;j++){
								download_date.push(addDate(startDate, 7*j));
								if(j==0){
									Pangolin_market_rank_preview(addDate(startDate,  7*j),endDate);
									$(".timeSelect").append('<span class="active" value="'+addDate(startDate,  7*j)+'">第'+($(".timeSelect").find("span").length+1)+'周</span>');
								}else{
									$(".timeSelect").append('<span value="'+addDate(startDate,  7*j)+'">第'+($(".timeSelect").find("span").length+1)+'周</span>');
								}
							}
						}
					}
				}
			}
		})
	}

}

function market_rank_day(){
	var startDate;
	var endDate;
	startDate=$(".dateBox").find("input")[0].value.trim()
	endDate=$(".dateBox").find("input")[1].value.trim()
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				tab:market_rank_tab,
				tabOne:market_rank_tabOne,
				device:terminal_id,
				sellerId:seller_id,
				categoryId:category_id,
			},
			url:server[0]._server_port+(server[0].mappings)[59]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
					if(boolean){
						$(".timeSelect").html('')
						for(var j=0;j<=count;j++){
							download_date.push(addDate(startDate,j));
							if(j==0){
								Pangolin_market_rank_preview(addDate(startDate,j),endDate);
								$(".timeSelect").append('<span class="active" value="'+addDate(startDate,j)+'">'+addDate(startDate,j)+'</span>');
							}else{
								$(".timeSelect").append('<span value="'+addDate(startDate,  j)+'">'+addDate(startDate,j)+'</span>');
							}
						}
					}
				}
				}
			}
		})
	}
}


function market_search_rank(){
	var startDate;
	var endDate;
	startDate=$(".dateBox").find("input")[0].value.trim()
	endDate=$(".dateBox").find("input")[1].value.trim()
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				tab:search_rank,
				tabOne:rankType,
				device:terminal_id,
				categoryId:category_id,
			},
			url:server[0]._server_port+(server[0].mappings)[50]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
					if(boolean){
						$(".timeSelect").html('')
						for(var j=0;j<=count;j++){
							download_date.push(addDate(startDate,j));
							if(j==0){
								Pangolin_market_search_rank_preview(addDate(startDate,j),endDate);
								$(".timeSelect").append('<span class="active" value="'+addDate(startDate,j)+'">'+addDate(startDate,j)+'</span>');
							}else{
								$(".timeSelect").append('<span value="'+addDate(startDate,  j)+'">'+addDate(startDate,j)+'</span>');
							}
						}
					}
				}
				}
			}
		})
	}
}

function Pangolin_market_rank_preview(sd,ed){
	leimugoucheng_Date=sd;
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			tab:market_rank_tab,
			tabOne:market_rank_tabOne,
			device:terminal_id,
			sellerId:seller_id,
			categoryId:category_id,
			pageIndex:page,
			pageSize:pageSize
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[60]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			$("#scph_date").html('')
			$("#scph_title").html('')
			$("#scph_data").html('')
			if(data.status==1){
				if(data.data.length>0){
					$("#page").show()
					$("#page").paging({
					      pageNo:page,
					      totalPage: Math.ceil(data.total[0].num/pageSize),
					      totalSize: data.total[0].num,
					      callback:function(value){
					    	  page=value;
					    	  Pangolin_market_rank_preview(leimugoucheng_Date,leimugoucheng_Date)
					      }
					    })
					    if(market_rank_tab==0){
					    	if(market_rank_tabOne==0){
					    		$.each(data.data,function(index){
									if(dateType=='day'){
										$("#scph_date").append('<tr> <td>'+this.startDate+'</td> </tr>')
									}else{
										$("#scph_date").append('<tr> <td>'+this.startDate+"~"+this.enddate+'</td> </tr>')
									}
									if(index==0){
										$("#scph_title").append('<tr> <th>店铺</th><th>行业排名</th><th>交易指数</th><th>交易增长幅度</th><th>支付转化指数</th></tr>')
									}
									$("#scph_data").append('<tr><td>'+this.shop_title+'</td><td>'+this.cateRankId+'</td><td>'+Number(this.tradeIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.tradeGrowthRange.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.payRateIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
					    		})
					    	}else{
					    		$.each(data.data,function(index){
					    			if(dateType=='day'){
										$("#scph_date").append('<tr> <td>'+this.startDate+'</td> </tr>')
									}else{
										$("#scph_date").append('<tr> <td>'+this.startDate+"~"+this.enddate+'</td> </tr>')
									}
									if(index==0){
										$("#scph_title").append('<tr> <th>店铺</th><th>行业排名</th><th>流量指数</th><th>搜索人气</th><th>交易指数</th></tr>')
									}
									$("#scph_data").append('<tr><td>'+this.shop_title+'</td><td>'+this.cateRankId+'</td><td>'+Number(this.uvIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.seIpvUvHits.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.tradeIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
					    		})
					    	}
					    }
					    
					if(market_rank_tab==1){
				    	if(market_rank_tabOne==0){
				    		$.each(data.data,function(index){
				    			if(dateType=='day'){
									$("#scph_date").append('<tr> <td>'+this.startDate+'</td> </tr>')
								}else{
									$("#scph_date").append('<tr> <td>'+this.startDate+"~"+this.enddate+'</td> </tr>')
								}
								if(index==0){
									$("#scph_title").append('<tr> <th>商品</th><th>行业排名</th><th>交易指数</th><th>交易增长幅度</th><th>支付转化指数</th></tr>')
								}
								$("#scph_data").append('<tr><td>'+this.item_title+'</td><td>'+this.cateRankId+'</td><td>'+Number(this.tradeIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.tradeGrowthRange.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.payRateIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
				    		})
				    	}else if(market_rank_tabOne==1){
				    		$.each(data.data,function(index){
				    			if(dateType=='day'){
									$("#scph_date").append('<tr> <td>'+this.startDate+'</td> </tr>')
								}else{
									$("#scph_date").append('<tr> <td>'+this.startDate+"~"+this.enddate+'</td> </tr>')
								}
								if(index==0){
									$("#scph_title").append('<tr> <th>商品</th><th>行业排名</th><th>流量指数</th><th>搜索人气</th><th>交易指数</th></tr>')
								}
								$("#scph_data").append('<tr><td>'+this.shop_title+'</td><td>'+this.cateRankId+'</td><td>'+Number(this.uvIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.seIpvUvHits.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.tradeIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
				    		})
				    	}else{
				    		$.each(data.data,function(index){
				    			if(dateType=='day'){
									$("#scph_date").append('<tr> <td>'+this.startDate+'</td> </tr>')
								}else{
									$("#scph_date").append('<tr> <td>'+this.startDate+"~"+this.enddate+'</td> </tr>')
								}
								if(index==0){
									$("#scph_title").append('<tr> <th>商品</th><th>行业排名</th><th>收藏人气</th><th>加购人气</th><th>交易指数</th></tr>')
								}
								$("#scph_data").append('<tr><td>'+this.shop_title+'</td><td>'+this.cateRankId+'</td><td>'+Number(this.cltHits.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.cartHits.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.tradeIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
				    		})
				    	}
				    }
					
					if(market_rank_tab==2){
				    	if(market_rank_tabOne==0){
				    		$.each(data.data,function(index){
				    			if(dateType=='day'){
									$("#scph_date").append('<tr> <td>'+this.startDate+'</td> </tr>')
								}else{
									$("#scph_date").append('<tr> <td>'+this.startDate+"~"+this.enddate+'</td> </tr>')
								}
								if(index==0){
									$("#scph_title").append('<tr> <th>品牌</th><th>行业排名</th><th>交易指数</th><th>交易增长幅度</th><th>支付转化指数</th></tr>')
								}
								$("#scph_data").append('<tr><td>'+this.brandModel_brandName+'</td><td>'+this.cateRankId+'</td><td>'+Number(this.tradeIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.tradeGrowthRange.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.payRateIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
				    		})
				    	}else{
				    		$.each(data.data,function(index){
				    			if(dateType=='day'){
									$("#scph_date").append('<tr> <td>'+this.startDate+'</td> </tr>')
								}else{
									$("#scph_date").append('<tr> <td>'+this.startDate+"~"+this.enddate+'</td> </tr>')
								}
								if(index==0){
									$("#scph_title").append('<tr> <th>品牌</th><th>行业排名</th><th>流量指数</th><th>搜索人气</th><th>交易指数</th></tr>')
								}
								$("#scph_data").append('<tr><td>'+this.brandModel_brandName+'</td><td>'+this.cateRankId+'</td><td>'+Number(this.uvIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.seIpvUvHits.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.tradeIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
				    		})
				    	}
				    }
					
				$(".market1").hide();
				$(".market2").show();
				}else{
					$("#scph_title").append('<tr><th conspan="4">没查到数据！请确定该时间条件下是否抓取了数据！<a href="../html/market_analysis.html" target="_blank">跳转查询！</a></th></tr>')
				}
			}
		}
	})
}

function Pangolin_market_search_rank_preview(sd,ed){
		leimugoucheng_Date=sd;
		//download_date.push(sd);
		$.ajax({
			type:'post',
			data:{
				startDate:sd,
				endDate:ed,
				dateType:dateType,
				tab:search_rank,
				tabOne:rankType,
				device:terminal_id,
				categoryId:category_id,
				pageIndex:page,
				pageSize:pageSize
			},
			async:false,
			url:server[0]._server_port+(server[0].mappings)[52]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				$("#scph_date").html('')
				$("#scph_title").html('')
				$("#scph_data").html('')
				if(data.status==1){
					if(data.data.length>0){
						$("#page").show()
						$("#page").paging({
						      pageNo:page,
						      totalPage: Math.ceil(data.total[0].num/pageSize),
						      totalSize: data.total[0].num,
						      callback:function(value){
						    	  page=value;
						    	  Pangolin_market_search_rank_preview(leimugoucheng_Date,leimugoucheng_Date)
						      }
						    })
						    if(search_rank==0){
						    	if(rankType==0){
						    		 $.each(data.data,function(index){
											$("#scph_date").append('<tr> <td>'+this.startDate+'</td> </tr>')
											if(index==0){
												$("#scph_title").append('<tr> <th>搜索词</th><th>热搜排名</th><th>搜索人气</th><th>点击人气</th><th>点击率</th><th>支付转化率</th></tr>')
											}
											$("#scph_data").append('<tr><td>'+this.searchWord+'</td><td>'+this.hotSearchRank+'</td><td>'+this.seIpvUvHits+'</td><td>'+this.clickHits+'</td><td>'+Number(this.clickRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+(this.payRate==undefined?"":Number(this.payRate.toString().match(/^\d+(?:\.\d{0,4})?/)))+'</td></tr>')
									})
						    	}else{
						    		 $.each(data.data,function(index){
											$("#scph_date").append('<tr> <td>'+this.startDate+'</td> </tr>')
											if(index==0){
												$("#scph_title").append('<tr> <th>搜索词</th><th>飙升排名</th><th>搜索人气</th><th>点击人气</th><th>点击率</th><th>支付转化率</th></tr>')
											}
											$("#scph_data").append('<tr><td>'+this.searchWord+'</td><td>'+this.soarRank+'</td><td>'+this.seIpvUvHits+'</td><td>'+this.clickHits+'</td><td>'+Number(this.clickRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+(this.payRate==undefined?"":Number(this.payRate.toString().match(/^\d+(?:\.\d{0,4})?/)))+'</td></tr>')
									})
						    	}
						    }
						if(search_rank==1){
					    	if(rankType==0){
					    		 $.each(data.data,function(index){
										$("#scph_date").append('<tr> <td>'+this.startDate+'</td> </tr>')
										if(index==0){
											$("#scph_title").append('<tr> <th>搜索词</th><th>热搜排名</th><th>搜索人气</th><th>点击人气</th><th>点击率</th><th>支付转化率</th></tr>')
										}
										$("#scph_data").append('<tr><td>'+this.searchWord+'</td><td>'+this.hotSearchRank+'</td><td>'+this.seIpvUvHits+'</td><td>'+this.clickHits+'</td><td>'+Number(this.clickRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+(this.payRate==undefined?"":Number(this.payRate.toString().match(/^\d+(?:\.\d{0,4})?/)))+'</td></tr>')
								})
					    	}else{
					    		 $.each(data.data,function(index){
										$("#scph_date").append('<tr> <td>'+this.startDate+'</td> </tr>')
										if(index==0){
											$("#scph_title").append('<tr> <th>搜索词</th><th>飙升排名</th><th>搜索增长幅度</th><th>搜索人气</th><th>点击人气</th><th>点击率</th><th>支付转化率</th></tr>')
										}
										$("#scph_data").append('<tr><td>'+this.searchWord+'</td><td>'+this.soarRank+'</td><td>'+this.seIpvUvHits+'</td><td>'+this.seIpvUvHits+'</td><td>'+this.clickHits+'</td><td>'+Number(this.clickRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+(this.payRate==undefined?"":Number(this.payRate.toString().match(/^\d+(?:\.\d{0,4})?/)))+'</td></tr>')
								})
					    	}
					    }
						   
						if(search_rank==2||search_rank==3||search_rank==4){
					    	if(rankType==0){
					    		 $.each(data.data,function(index){
										$("#scph_date").append('<tr> <td>'+this.startDate+'</td> </tr>')
										if(index==0){
											$("#scph_title").append('<tr> <th>搜索词</th><th>热搜排名</th><th>相关搜索词数</th><th>相关词搜索人气</th><th>相关词点击人气</th><th>词均点击率</th><th>词均支付转化率</th></tr>')
										}
										$("#scph_data").append('<tr><td>'+this.searchWord+'</td><td>'+this.hotSearchRank+'</td><td>'+this.relSeWordCnt+'</td><td>'+this.avgWordSeIpvUvHits+'</td><td>'+this.avgWordClickHits+'</td><td>'+this.avgWordClickRate+'</td><td>'+this.avgWordPayRate+'</td></tr>')
								})
					    	}else{
					    		 $.each(data.data,function(index){
										$("#scph_date").append('<tr> <td>'+this.startDate+'</td> </tr>')
										if(index==0){
											$("#scph_title").append('<tr> <th>搜索词</th><th>飙升排名</th><th>词均搜索增长幅度</th><th>相关搜索词数</th><th>相关词搜索人气</th><th>相关词点击人气</th><th>词均支付转化率</th></tr>')
										}
										$("#scph_data").append('<tr><td>'+this.searchWord+'</td><td>'+this.soarRank+'</td><td>'+this.avgWordSeRiseRate+'</td><td>'+this.relSeWordCnt+'</td><td>'+this.avgWordSeIpvUvHits+'</td><td>'+this.avgWordClickHits+'</td><td>'+this.avgWordPayRate+'</td></tr>')
								})
					    	}
					    }
						
						
					$(".market1").hide();
					$(".market2").show();
					}else{
						$("#scph_title").append('<tr><th conspan="4">没查到数据！请确定该时间条件下是否抓取了数据！<a href="../html/market_analysis.html" target="_blank">跳转查询！</a></th></tr>')
					}
				}
			}
		})
}







function market_keyword(val){
	var startDate;
	var endDate;
	startDate=$(".dateBox").find("input")[0].value.trim()
	endDate=$(".dateBox").find("input")[1].value.trim()
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:'day',
				keyword:$("#keyWord_select").val(),
				device:terminal_id,
				parentcateId:$("#parent_cateId").val(),
				relatedWordsType:btn_type==4?0:btn_type==5?1:btn_type==6?2:btn_type==7?3:0
			},
			url:server[0]._server_port+(server[0].mappings)[val]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
					if(boolean){
						$(".timeSelect").html('')
						for(var j=0;j<=count;j++){
							download_date.push(addDate(startDate,j));
							if(j==0){
								Pangolin_searchword_all(addDate(startDate,j),endDate);
								$(".timeSelect").append('<span class="active" value="'+addDate(startDate,j)+'">'+addDate(startDate,j)+'</span>');
							}else{
								$(".timeSelect").append('<span value="'+addDate(startDate,  j)+'">'+addDate(startDate,j)+'</span>');
							}
						}
					}
				}
				}
			}
		})
	}
}
var page=1;
var pageSize=10;
function Pangolin_searchword_all(sd,ed){
	leimugoucheng_Date=sd;
	//download_date.push(sd);
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			keyword:$("#keyWord_select").val(),
			device:terminal_id,
			parentcateId:$("#parent_cateId").val(),
			parentcateName:$("#parent_cateId option:selected").text(),
			pageIndex:page,
			pageSize:pageSize,
			relatedWordsType:btn_type==4?0:btn_type==5?1:btn_type==6?2:btn_type==7?3:0
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[40]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			$("#scph_date").html('')
			$("#scph_title").html('')
			$("#scph_data").html('')
			if(data.status==1){
				if(data.data.length>0){
					$("#page").show()
					$("#page").paging({
					      pageNo:page,
					      totalPage: Math.ceil(data.total[0].num/pageSize),
					      totalSize: data.total[0].num,
					      callback:function(value){
					    	  page=value;
					    	  Pangolin_searchword_all(leimugoucheng_Date,leimugoucheng_Date)
					      }
					    })
					    if(btn_type==4){
					    	$.each(data.data,function(index){
								$("#scph_date").append('<tr> <td>'+$("#keyWord_select").val()+'</td> </tr>')
								if(index==0){
									$("#scph_title").append('<tr> <th>关键词</th><th>搜索人数</th><th>点击人气</th><th>点击热度</th><th>点击率</th><th>在线商品数</th><th>直通车参考价</th><th>支付转化率</th><th>搜索人气</th><th>搜索热度</th><th>商城点击占比</th><th>交易指数</th></tr>')
								}
								$("#scph_data").append('<tr><td>'+this.self_keyword+'</td><td>'+this.spvRatio+'</td><td>'+this.clickHits+'</td><td>'+this.clickHot+'</td><td>'+this.clickRate+'</td><td>'+this.onlineGoodsCnt+'</td><td>'+Number(this.p4pAmt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+this.payConvRate+'</td><td>'+this.seIpvUvHits+'</td><td>'+this.sePvIndex+'</td><td>'+this.tmClickRatio+'</td><td>'+this.tradeIndex+'</td></tr>')
							
							})
					    }
					
					if(btn_type==5){
				    	$.each(data.data,function(index){
							$("#scph_date").append('<tr> <td>'+$("#keyWord_select").val()+'</td> </tr>')
							if(index==0){
								$("#scph_title").append('<tr> <th>关键词</th><th>搜索人气</th><th>相关搜索词数</th><th>词均点击率</th><th>点击人气</th><th>词均支付转化率</th><th>直通车参考价</th></tr>')
							}
							$("#scph_data").append('<tr><td>'+this.self_keyword+'</td><td>'+this.seIpvUvHits+'</td><td>'+this.relSeWordCnt+'</td><td>'+this.avgWordClickRate+'</td><td>'+this.clickHits+'</td><td>'+this.avgWordPayRate+'</td><td>'+Number(this.p4pAmt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
						
						})
				    }
					if(btn_type==6){
				    	$.each(data.data,function(index){
							$("#scph_date").append('<tr> <td>'+$("#keyWord_select").val()+'</td> </tr>')
							if(index==0){
								$("#scph_title").append('<tr> <th>关键词</th><th>搜索人气</th><th>相关搜索词数</th><th>词均点击率</th><th>点击人气</th><th>词均支付转化率</th><th>直通车参考价</th></tr>')
							}
							$("#scph_data").append('<tr><td>'+this.self_keyword+'</td><td>'+this.seIpvUvHits+'</td><td>'+this.relSeWordCnt+'</td><td>'+this.avgWordClickRate+'</td><td>'+this.clickHits+'</td><td>'+this.avgWordPayRate+'</td><td>'+Number(this.p4pAmt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
						
						})
				    }
					if(btn_type==7){
				    	$.each(data.data,function(index){
							$("#scph_date").append('<tr> <td>'+$("#keyWord_select").val()+'</td> </tr>')
							if(index==0){
								$("#scph_title").append('<tr> <th>关键词</th><th>搜索人气</th><th>相关搜索词数</th><th>词均点击率</th><th>点击人气</th><th>词均支付转化率</th><th>直通车参考价</th></tr>')
							}
							$("#scph_data").append('<tr><td>'+this.self_keyword+'</td><td>'+this.seIpvUvHits+'</td><td>'+this.relSeWordCnt+'</td><td>'+this.avgWordClickRate+'</td><td>'+this.clickHits+'</td><td>'+this.avgWordPayRate+'</td><td>'+Number(this.p4pAmt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
						
						})
				    }
				$(".market1").hide();
				$(".market2").show();
				}else{
					$("#scph_title").append('<tr><th conspan="4">没查到数据！请确定该时间条件下是否抓取了数据！<a href="../html/market_analysis.html" target="_blank">跳转查询！</a></th></tr>')
				}
			}
		}
	})
}

function market_leimugoucheng_keyword_month(val){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))
	var boolean=true;
	for(var i=0;i<count;i++){
		var tr_id=getMonth(startDate,i);
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType,
				keyword:$("#keyWord_select").val(),
				device:terminal_id,
				parentcateId:$("#parent_cateId").val(),
				relatedWordsType:btn_type==4?0:btn_type==5?1:btn_type==6?2:btn_type==7?3:0
			},
			url:server[0]._server_port+(server[0].mappings)[val]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index+1>count){index=0;
						if(boolean){
							$(".timeSelect").html('')
							for(var j=0;j<=count;j++){
								var tr_id=getMonth(startDate,j);
								download_date.push(tr_id);
								if(j==0){
									Pangolin_market_fx_searchword_Category_preview(tr_id,endDate);
									$(".timeSelect").append('<span class="active" value="'+tr_id+'">'+tr_id.split('-')[0]+'年'+tr_id.split('-')[1]+'月</span>');
								}else{
									$(".timeSelect").append('<span value="'+tr_id+'">'+tr_id.split('-')[0]+'年'+tr_id.split('-')[1]+'月</span>');
								}
							}
						}
						
					}
				}
			}
		})
	}
}


function market_leimugoucheng_keyword_week(val){
	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}
	var boolean=true;
	for(var i=0;i<count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType,
				keyword:$("#keyWord_select").val(),
				device:terminal_id,
				parentcateId:$("#parent_cateId").val(),
				relatedWordsType:btn_type==4?0:btn_type==5?1:btn_type==6?2:btn_type==7?3:0
			},
			url:server[0]._server_port+(server[0].mappings)[val]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index+1>count){index=0;
						if(boolean){
							$(".timeSelect").html('')
							for(var j=0;j<=count;j++){
								download_date.push(addDate(startDate, 7*j));
								if(j==0){
									Pangolin_market_fx_searchword_Category_preview(addDate(startDate,  7*j),endDate);
									$(".timeSelect").append('<span class="active" value="'+addDate(startDate,  7*j)+'">第'+($(".timeSelect").find("span").length+1)+'周</span>');
								}else{
									$(".timeSelect").append('<span value="'+addDate(startDate,  7*j)+'">第'+($(".timeSelect").find("span").length+1)+'周</span>');
								}
							}
						}
					}
				}
			}
		})
	}
}

function market_leimugoucheng_keyword_day(val){
	var startDate;
	var endDate;
	startDate=$(".dateBox").find("input")[0].value.trim()
	endDate=$(".dateBox").find("input")[1].value.trim()
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				keyword:$("#keyWord_select").val(),
				device:terminal_id,
				parentcateId:$("#parent_cateId").val(),
				relatedWordsType:btn_type==4?0:btn_type==5?1:btn_type==6?2:btn_type==7?3:0
			},
			url:server[0]._server_port+(server[0].mappings)[val]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
						if(boolean){
							$(".timeSelect").html('')
							for(var j=0;j<=count;j++){
								download_date.push(addDate(startDate,j));
								if(j==0){
									Pangolin_market_fx_searchword_Category_preview(addDate(startDate,j),endDate);
									$(".timeSelect").append('<span class="active" value="'+addDate(startDate,j)+'">'+addDate(startDate,j)+'</span>');
								}else{
									$(".timeSelect").append('<span value="'+addDate(startDate,  j)+'">'+addDate(startDate,j)+'</span>');
								}
							}
						}
					}
				}
			}
		})
	}
}


var leimugoucheng_Date='';
$(".timeSelect").on("click","span",function(){
	$("#scph_date").html("")
	$("#scph_title").html("")
	$("#scph_data").html("")
	$(this).addClass("active").siblings("span").removeClass("active");
	if(btn_type==3){
		Pangolin_market_fx_searchword_Category_preview($(this).attr("value"),$(this).attr("value"))
	}else{
		Pangolin_searchword_all($(this).attr("value"),$(this).attr("value"))
	}
	if(btn_type==8){
		Pangolin_market_search_rank_preview($(this).attr("value"),$(this).attr("value"));
	}
	if(btn_type==9){
		Pangolin_market_rank_preview($(this).attr("value"),$(this).attr("value"))
	}
})

function Pangolin_market_fx_searchword_Category_preview(sd,ed){
	leimugoucheng_Date=sd;
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			keyword:$("#keyWord_select").val(),
			device:terminal_id,
			parentcateId:$("#parent_cateId").val(),
			parentcateName:$("#parent_cateId option:selected").text(),
			relatedWordsType:btn_type==4?0:btn_type==5?1:btn_type==6?2:btn_type==7?3:0
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[btn_type==3?39:39]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				if(data.data.length>0){
				$.each(data.data,function(index){
					$("#scph_date").append('<tr> <td>'+$("#keyWord_select").val()+'</td> </tr>')
					if(index==0){
					$("#scph_title").append('<tr> <th>父类目名称</th> <th>子类目名称</th><th>点击热度</th> <th>点击人气</th> <th>点击人数占比</th> <th>点击次数占比</th> <th>点击率</th> </tr>')
					}
					$("#scph_data").append('<tr><td>'+this.parentcateName+'</td><td>'+this.cateName+'</td><td>'+this.clickHot+'</td><td>'+this.clickHits+'</td><td>'+Number(this.clickHitsRatio.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.clickCntRatio.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.clickRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
				})
				$(".market1").hide();
				$(".market2").show();
				}else{
					$("#scph_title").append('<tr><th conspan="4">没查到数据！请确定该时间条件下是否抓取了数据！<a href="../html/market_analysis.html" target="_blank">跳转查询！</a></th></tr>')
				}
			}
		}
	})
}


function market_keyword_month(val){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))
	var boolean=true;
	for(var i=0;i<=count;i++){
		var tr_id=getMonth(startDate,i);
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType,
				keyword:$("#keyWord_select").val(),
				device:terminal_id,
				parentcateId:$("#parent_cateId").val(),
				relatedWordsType:btn_type==4?0:btn_type==5?1:btn_type==6?2:btn_type==7?3:0
			},
			url:server[0]._server_port+(server[0].mappings)[val]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								var tr_id=getMonth(startDate,j);
								Pangolin_searchword_relatedword_preview(tr_id,endDate)
								download_date.push(tr_id);
							}
						}
					}
				}
			}
		})
	}
}

function market_keyword_week(val){
	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}
	var boolean=true;
	for(var i=0;i<count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				keyword:$("#keyWord_select").val(),
				device:terminal_id,
				parentcateId:$("#parent_cateId").val(),
				relatedWordsType:btn_type==4?0:btn_type==5?1:btn_type==6?2:btn_type==7?3:0
			},
			url:server[0]._server_port+(server[0].mappings)[val]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index+1>count){index=0;
						if(boolean){
							for(var j=0;j<count;j++){
								Pangolin_searchword_relatedword_preview(addDate(startDate,  7*j),endDate)
								download_date.push(addDate(startDate,7*j));
							}
						}
					}
				}
			}
		})
	}
}

function market_keyword_day(val){
	var startDate;
	var endDate;
	startDate=$(".dateBox").find("input")[0].value.trim()
	endDate=$(".dateBox").find("input")[1].value.trim()
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				keyword:$("#keyWord_select").val(),
				device:terminal_id,
				parentcateId:$("#parent_cateId").val(),
				relatedWordsType:btn_type==4?0:btn_type==5?1:btn_type==6?2:btn_type==7?3:0
			},
			url:server[0]._server_port+(server[0].mappings)[val]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								Pangolin_searchword_relatedword_preview(addDate(startDate,j),endDate)
								download_date.push(addDate(startDate,j));
							}
						}
					}
				}
			}
		})
	}
}

function Pangolin_searchword_relatedword_preview(sd,ed){
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			keyword:$("#keyWord_select").val(),
			device:terminal_id,
			parentcateId:$("#parent_cateId").val(),
			relatedWordsType:btn_type==4?0:btn_type==5?1:btn_type==6?2:btn_type==7?3:0
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[btn_type==2?38:38]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				var th=""
				var tr=""
				var date=""
				$.each(data.data[0],function(name,value) {
					if(name =='startDate'){
						if(dateType=='day'){
							$("#scph_date").append('<tr> <td>'+value+'</td> </tr>');
						}else{
							$("#scph_date").append('<tr> <td>'+data.data[0].start_end_Date+'</td> </tr>');
						}
					}else if(name=='endDate' || name =='startDate' || name=="shopName"|| name=="start_end_Date"|| name=="dateType"){
						
					}else if(name=='product_Name' || name =='product_Id'|| name =='keyword'){
					
					}else{
						th=th+'<th>'+name+'</th>';
						tr=tr+'<td>'+	
						Number(value.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>';
					}
				});
				$("#scph_title").html("")
				$("#scph_title").append('<tr>'+th+'</tr>');
				$("#scph_data").append('<tr>'+tr+'</tr>');
				$(".market1").hide();
				$(".market2").show();
			}
		}
	})
}






var _index_code=[]
function tjcheckBox(){
	_index_code=[];
	$.each($("#report_index").find('input'),function(index){
		if(this.checked){
			_index_code.push('['+$(this).next().text()+']')
		}
	})
}

function addDate(date, days) {

    var date = new Date(date);
    date.setDate(date.getDate() + days);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return date.getFullYear() + '-' + getFormatDate(month) + '-' + getFormatDate(day);
}
function getFormatDate(arg) {
    if (arg == undefined || arg == '') {
        return '';
    }

    var re = arg + '';
    if (re.length < 2) {
        re = '0' + re;
    }

    return re;
}


var seller_id=-1;
$("#checkbox221").click(function(){
if ($("#checkbox221").prop('checked')) {
	seller_id=-1;
}
})
$("#checkbox222").click(function(){
	if ($("#checkbox222").prop('checked')) {
		seller_id=0;
	}
})
$("#checkbox223").click(function(){
	if ($("#checkbox223").prop('checked')) {
		seller_id=1;
	}
})

var terminal_id=0;
$("#checkbox241").click(function(){
	if ($("#checkbox241").prop('checked')) {
		terminal_id=0;
	}
})
$("#checkbox242").click(function(){
	if ($("#checkbox242").prop('checked')) {
		terminal_id=1;
	}
})
$("#checkbox243").click(function(){
	if ($("#checkbox243").prop('checked')) {
		terminal_id=2;
	}
})


var index=0;
function getDate_sc_hydp_day(){
	var startDate;
	var endDate;
	startDate=$(".dateBox").find("input")[0].value.trim()
	endDate=$(".dateBox").find("input")[1].value.trim()
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				categoryId:category_id,
				sellerId:seller_id,
				terminalId:terminal_id
			},
			url:server[0]._server_port+(server[0].mappings)[16]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								preview_report_index_data(addDate(startDate,j),endDate)
								download_date.push(addDate(startDate,j));
							}
						}
					}
				}

			}
		})
	}
}

function getDate_sc_hydp_week(){
	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}
	var boolean=true;
	for(var i=0;i<count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType,
				categoryId:category_id,
				sellerId:seller_id,
				terminalId:terminal_id
			},
			url:server[0]._server_port+(server[0].mappings)[16]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index+1>count){index=0;
						if(boolean){
							for(var j=0;j<count;j++){
								preview_report_index_data(addDate(startDate,  7*j),endDate)
								download_date.push(addDate(startDate,  7*j));
							}
						}
					}
				}
			}
		})
	}
}

function getIntervalMonth(startDate,endStart){
    var startMonth = startDate.getMonth();
    var endMonth = endStart.getMonth();
    var intervalMonth = (endStart.getFullYear()*12+endMonth) - (startDate.getFullYear()*12+startMonth);
    return intervalMonth;
}
function getMonth(startDate,i){
	var year=parseInt(startDate.split('-')[0]);
	var month=parseInt(startDate.split('-')[1]);
	if(month+i>12){
		var count=	parseInt((month+i)/12)
		month=(month+i)-12*count;
		if(month==0){
			year=year+count-1;
			month=12;
			return year+"-"+month+"-01"
		}else{
			year=year+count;
			return year+"-"+(month>9?month:"0"+month)+"-01";
		}
		
	}else{
		month=month+i
		return year+"-"+(month>9?month:"0"+month)+"-01";
	}
}
function getDate_sc_hydp_month(){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))
	var boolean=true;
	for(var i=0;i<=count;i++){
		var tr_id=getMonth(startDate,i);
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType,
				categoryId:category_id,
				sellerId:seller_id,
				terminalId:terminal_id
			},
			url:server[0]._server_port+(server[0].mappings)[16]._interface,
			success:function(value){index++;
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){

				$.each(data.data,function(index){
					if(this.status==3){
						if(boolean){
							alert(this.startDate+"号未抓取！")
							boolean=false;
						}
					}
					if(this.status==2){
						if(boolean){
							alert(this.startDate+"号数据不完整！")
							boolean=false;
						}					
					}
				})
				
				if(index>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								var tr_id=getMonth(startDate,j);
								preview_report_index_data(tr_id,endDate)
								download_date.push(tr_id);
							}
						}
					}
			}

		}
		})
	}
}

function preview_report_index_data(sd,ed){
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			categoryId:category_id,
			sellerId:seller_id,
			terminalId:terminal_id,
			indexCode:_index_code.toString()
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[37]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				var th=""
				var tr=""
				var date=""
				$.each(data.data[0],function(name,value) {
					if(name =='startDate'){
						if(dateType=='day'){
							$("#scph_date").append('<tr> <td>'+value+'</td> </tr>');
						}else{
							$("#scph_date").append('<tr> <td>'+data.data[0].start_end_Date+'</td> </tr>');
						}
					}else if(name=='类目'){
						th='<th>'+name+'</th>'+th;
						tr='<td>'+	
						value+'</td>'+tr;
					}else if(name!='endDate' && name !='startDate' && name!="shopName"&& name!="dateType"&& name!="start_end_Date"){
						th=th+'<th>'+name+'</th>';
						tr=tr+'<td>'+	
						Number(value.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>';
					}
				});
				$("#scph_title").html("")
				$("#scph_title").append('<tr>'+th+'</tr>');
				$("#scph_data").append('<tr>'+tr+'</tr>');
				$(".market1").hide();
				$(".market2").show();
			}
		}
	})
}


function parameterTip(){
	$(".showCondition").html('')
	if ($("#checkbox001").prop('checked')) {
		$(".showCondition").append('<div> <b>一级分类:</b> <span>市场大盘</span> </div>')
		$(".showCondition").append('<div> <b>选择类目:</b> <span>'+category_name+'</span> </div>')
		$(".timeSelect").hide();
		if ($("#checkbox221").prop('checked')) {
			$(".showCondition").append('<div> <b>选择平台:</b> <span>全网</span> </div>')
		}
		if ($("#checkbox222").prop('checked')) {
			$(".showCondition").append('<div> <b>选择平台:</b> <span>淘宝</span> </div>')
		}
		if ($("#checkbox223").prop('checked')) {
			$(".showCondition").append('<div> <b>选择平台:</b> <span>天猫</span> </div>')
		}
		


		if ($("#checkbox241").prop('checked')) {
			$(".showCondition").append('<div> <b>选择终端:</b> <span>所有终端</span> </div>')
		}
		if ($("#checkbox242").prop('checked')) {
			$(".showCondition").append('<div> <b>选择终端:</b> <span>PC端</span> </div>')
		}
		if ($("#checkbox243").prop('checked')) {
			$(".showCondition").append('<div> <b>选择终端:</b> <span>无线终端</span> </div>')
		}
	}
	
	if ($("#checkbox002").prop('checked')) {
		$(".showCondition").append('<div> <b>一级分类:</b> <span>搜索分析</span> </div>')
		if ($("#checkbox011").prop('checked')) {
			$(".showCondition").append('<div> <b>二级分类:</b> <span>搜索词趋势</span> </div>')
			$(".timeSelect").hide();
		}
		if ($("#checkbox012").prop('checked')) {
			$(".showCondition").append('<div> <b>二级分类:</b> <span>相关词分析</span> </div>')
			if ($("#checkbox021").prop('checked')) {
				$(".showCondition").append('<div> <b>三级分类:</b> <span>相关搜索词</span> </div>')
			}
			if ($("#checkbox022").prop('checked')) {
				$(".showCondition").append('<div> <b>三级分类:</b> <span>关联品牌词</span> </div>')
			}
			if ($("#checkbox023").prop('checked')) {
				$(".showCondition").append('<div> <b>三级分类:</b> <span>关联修饰词</span> </div>')
			}
			if ($("#checkbox024").prop('checked')) {
				$(".showCondition").append('<div> <b>三级分类:</b> <span>关联热词</span> </div>')
			}
			$(".timeSelect").show();
		}
		if ($("#checkbox013").prop('checked')) {
			$(".showCondition").append('<div> <b>二级分类:</b> <span>类目构成</span> </div>')
			$(".timeSelect").show();
		}
		
		$(".showCondition").append('<div> <b>选择关键词:</b> <span>'+$("#keyWord_select").val()+'</span> </div>')
		if ($("#checkbox013").prop('checked')) {
			$(".showCondition").append('<div> <b>父类目:</b> <span>'+$("#parent_cateId option:selected").text()+'</span> </div>')
		}
		if ($("#checkbox221").prop('checked')) {
			$(".showCondition").append('<div> <b>选择平台:</b> <span>全网</span> </div>')
		}
		if ($("#checkbox222").prop('checked')) {
			$(".showCondition").append('<div> <b>选择平台:</b> <span>淘宝</span> </div>')
		}
		if ($("#checkbox223").prop('checked')) {
			$(".showCondition").append('<div> <b>选择平台:</b> <span>天猫</span> </div>')
		}
		


		if ($("#checkbox241").prop('checked')) {
			$(".showCondition").append('<div> <b>选择终端:</b> <span>所有终端</span> </div>')
		}
		if ($("#checkbox242").prop('checked')) {
			$(".showCondition").append('<div> <b>选择终端:</b> <span>PC端</span> </div>')
		}
		if ($("#checkbox243").prop('checked')) {
			$(".showCondition").append('<div> <b>选择终端:</b> <span>无线终端</span> </div>')
		}
	}
	
	if ($("#checkbox003").prop('checked')) {
		$(".showCondition").append('<div> <b>一级分类:</b> <span>搜索排行</span> </div>')
		$(".showCondition").append('<div> <b>选择类目:</b> <span>'+category_name+'</span> </div>')
		$(".timeSelect").show();
		


		if ($("#checkbox241").prop('checked')) {
			$(".showCondition").append('<div> <b>选择终端:</b> <span>所有终端</span> </div>')
		}
		if ($("#checkbox242").prop('checked')) {
			$(".showCondition").append('<div> <b>选择终端:</b> <span>PC端</span> </div>')
		}
		if ($("#checkbox243").prop('checked')) {
			$(".showCondition").append('<div> <b>选择终端:</b> <span>无线终端</span> </div>')
		}
		
		if ($("#checkbox2431").prop('checked')) {
			$(".showCondition").append('<div> <b>选择排行:</b> <span>搜索词</span> </div>')
		}
		if ($("#checkbox2432").prop('checked')) {
			$(".showCondition").append('<div> <b>选择排行:</b> <span>长尾词</span> </div>')
		}
		if ($("#checkbox2433").prop('checked')) {
			$(".showCondition").append('<div> <b>选择排行:</b> <span>品牌词</span> </div>')
		}
		if ($("#checkbox2434").prop('checked')) {
			$(".showCondition").append('<div> <b>选择排行:</b> <span>核心词</span> </div>')
		}
		if ($("#checkbox2435").prop('checked')) {
			$(".showCondition").append('<div> <b>选择排行:</b> <span>修饰词</span> </div>')
		}
		if ($("#checkbox3411").prop('checked')) {
			$(".showCondition").append('<div> <b>排行类型:</b> <span>热搜</span> </div>')
		}
		if ($("#checkbox3422").prop('checked')) {
			$(".showCondition").append('<div> <b>排行类型:</b> <span>飙升</span> </div>')
		}
	}
	
	if ($("#checkbox004").prop('checked')) {
		$(".showCondition").append('<div> <b>一级分类:</b> <span>市场排行</span> </div>')
		$(".showCondition").append('<div> <b>选择类目:</b> <span>'+category_name+'</span> </div>')
		$(".timeSelect").show();
		if ($("#checkbox221").prop('checked')) {
			$(".showCondition").append('<div> <b>选择平台:</b> <span>全网</span> </div>')
		}
		if ($("#checkbox222").prop('checked')) {
			$(".showCondition").append('<div> <b>选择平台:</b> <span>淘宝</span> </div>')
		}
		if ($("#checkbox223").prop('checked')) {
			$(".showCondition").append('<div> <b>选择平台:</b> <span>天猫</span> </div>')
		}
		


		if ($("#checkbox241").prop('checked')) {
			$(".showCondition").append('<div> <b>选择终端:</b> <span>所有终端</span> </div>')
		}
		if ($("#checkbox242").prop('checked')) {
			$(".showCondition").append('<div> <b>选择终端:</b> <span>PC端</span> </div>')
		}
		if ($("#checkbox243").prop('checked')) {
			$(".showCondition").append('<div> <b>选择终端:</b> <span>无线终端</span> </div>')
		}
		
		if ($("#checkbox_market_rank_1").prop('checked')) {
			$(".showCondition").append('<div> <b>选择排行:</b> <span>店铺</span> </div>')
		}
		if ($("#checkbox_market_rank_2").prop('checked')) {
			$(".showCondition").append('<div> <b>选择排行:</b> <span>商品</span> </div>')
		}
		if ($("#checkbox_market_rank_3").prop('checked')) {
			$(".showCondition").append('<div> <b>选择排行:</b> <span>品牌</span> </div>')
		}
		if ($("#checkbox_market_rank_type_1").prop('checked')) {
			$(".showCondition").append('<div> <b>排行类型:</b> <span>高交易</span> </div>')
		}
		if ($("#checkbox_market_rank_type_2").prop('checked')) {
			$(".showCondition").append('<div> <b>排行类型:</b> <span>高流量</span> </div>')
		}
		if ($("#checkbox_market_rank_type_3").prop('checked')) {
			$(".showCondition").append('<div> <b>排行类型:</b> <span>高意向</span> </div>')
		}
	}
	
		if (dateType == "day") {
			$(".showCondition").append('<div> <b>时间周期:</b> <span>按天</span> </div>')
		}
		if (dateType == "week") {
			$(".showCondition").append('<div> <b>时间周期:</b> <span>按周</span> </div>')
		}
		if (dateType == "month") {
			$(".showCondition").append('<div> <b>时间周期:</b> <span>按月</span> </div>')
		}

}


$(".reSearch").click(function(){
	$(".market1").show();
	$(".market2").hide();
})

var search_rank=0;
$("#checkbox2431").click(function(){
	search_rank=0
})
$("#checkbox2432").click(function(){
	search_rank=1
})
$("#checkbox2433").click(function(){
	search_rank=2
})
$("#checkbox2434").click(function(){
	search_rank=3
})
$("#checkbox2435").click(function(){
	search_rank=4
})

var rankType=0;
$("#checkbox3411").click(function(){
	rankType=0
})
$("#checkbox3422").click(function(){
	rankType=1
})

var market_rank_tab=0;
$("#checkbox_market_rank_1").click(function(){
	market_rank_tab=0
	if ($("#checkbox_market_rank_1").prop('checked')) {
		if(market_rank_tabOne==2)$("#checkbox_market_rank_type_1").click()
		$("#checkbox_market_rank_type_3").parent().hide()
	}
})
$("#checkbox_market_rank_2").click(function(){
	market_rank_tab=1
	$("#checkbox_market_rank_type_3").parent().show()
})
$("#checkbox_market_rank_3").click(function(){
	market_rank_tab=2
	if ($("#checkbox_market_rank_3").prop('checked')) {
		if(market_rank_tabOne==2)$("#checkbox_market_rank_type_1").click()
		$("#checkbox_market_rank_type_3").parent().hide()
	}
})
var market_rank_tabOne=0;

$("#checkbox_market_rank_type_1").click(function(){
	market_rank_tabOne=0
})
$("#checkbox_market_rank_type_2").click(function(){
	market_rank_tabOne=1
})
$("#checkbox_market_rank_type_3").click(function(){
	market_rank_tabOne=2
})
$("#shichang_download").click(function(){
	if(btn_type==1){
		window.location.href=encodeURI(server[0]._server_port+"/option/ShiChang_hangyedapang_preview_downLoad?dates="+download_date
		+"&dateType="+dateType+"&categoryId="+category_id+"&sellerId="+seller_id+"&terminalId="+terminal_id+"&indexCode="+_index_code.toString());
	}
	if(btn_type==2){
		window.location.href=encodeURI(server[0]._server_port+"/option/Pangolin_keyword_trend_preview_download?dates="+download_date
		+"&dateType="+dateType+"&keyword="+$("#keyWord_select").val()+"&device="+terminal_id+"&parentcateId="+$("#parent_cateId").val())
	}
	if(btn_type==3){	
		window.location.href=encodeURI(server[0]._server_port+"/option/Pangolin_market_fx_searchword_Category_preview_download?startDate="+leimugoucheng_Date+"&dates="+download_date
		+"&dateType="+dateType+"&keyword="+$("#keyWord_select").val()+"&device="+terminal_id+"&parentcateId="+$("#parent_cateId").val()+"&parentcateName="+$("#parent_cateId option:selected").text())
	}
	if(btn_type==4||btn_type==5||btn_type==6||btn_type==7){
		rstp=btn_type==4?0:btn_type==5?1:btn_type==6?2:btn_type==7?3:0
		
		window.location.href=encodeURI(server[0]._server_port+"/option/Pangolin_searchword_relatedword_preview_download?startDate="+leimugoucheng_Date+"&dates="+download_date
		+"&dateType="+dateType+"&keyword="+$("#keyWord_select").val()+"&device="+terminal_id+"&relatedWordsType="+rstp)
	}
	
	if(btn_type==8){
		window.location.href=encodeURI(server[0]._server_port+"/option/Pangolin_market_search_rank_preview_download?startDate="+leimugoucheng_Date+"&dates="+download_date
		+"&dateType="+dateType+"&tab="+search_rank+"&device="+terminal_id+"&tabOne="+rankType+"&categoryId="+category_id)
	}
	if(btn_type==9){
		window.location.href=encodeURI(server[0]._server_port+"/option/Pangolin_market_rank_preview_count_download?startDate="+leimugoucheng_Date+"&dates="+download_date
		+"&dateType="+dateType+"&tab="+market_rank_tab+"&device="+terminal_id+"&tabOne="+market_rank_tabOne+"&categoryId="+category_id+"&sellerId="+seller_id+"&categoryName="+category_name)
	}
})