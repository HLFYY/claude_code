$.ajaxSetup({
	crossDomain : true,
	xhrFields : {
		withCredentials : true
	}
});
$(document).ready(function() {

});

$(".reSearch").click(function(){
	$(".fetchNumber2").hide();
	$(".fetchNumber1").show();
})

var dateType = 'day';
$("#checkbox131").click(function() {
	$("#checkbox132,#checkbox133").prop("checked", false);
	$(".monthBox,.weekBox,.dateBox").hide();
	$(".dateBox").show();
	dateType = 'day';
})
$("#checkbox132").click(function() {
	$("#checkbox131,#checkbox133").prop("checked", false);
	$(".monthBox,.weekBox,.dateBox").hide();
	$(".weekBox").show();
	dateType = 'week';
})
$("#checkbox133").click(function() {
	$("#checkbox132,#checkbox131").prop("checked", false);
	$(".monthBox,.weekBox,.dateBox").hide();
	$(".monthBox").show();
	dateType = 'month';
})

function tongji_terminal() {
	var terminal_id = ""
	if ($("#checkbox151").prop('checked')) {
		terminal_id = terminal_id == "" ? terminal_id + '0' : terminal_id
				+ ',0'
	}
	if ($("#checkbox152").prop('checked')) {
		terminal_id = terminal_id == "" ? terminal_id + '1' : terminal_id
				+ ',1'
	}
	if ($("#checkbox153").prop('checked')) {
		terminal_id = terminal_id == "" ? terminal_id + '2' : terminal_id
				+ ',2'
	}
	return terminal_id;
}

function tongji_theme() {
	var theme_id = ""
		if ($("#checkbox169").prop('checked')) {
			theme_id = theme_id == "" ? theme_id + '1' : theme_id + ',1'
		}
		if ($("#checkbox170").prop('checked')) {
			theme_id = theme_id == "" ? theme_id + '2' : theme_id + ',2'
		}
	if ($("#checkbox163").prop('checked')) {
		theme_id = theme_id == "" ? theme_id + '3' : theme_id + ',3'
	}
	if ($("#checkbox164").prop('checked')) {
		theme_id = theme_id == "" ? theme_id + '4' : theme_id + ',4'
	}
	if ($("#checkbox165").prop('checked')) {
		theme_id = theme_id == "" ? theme_id + '5' : theme_id + ',5'
	}
	if ($("#checkbox166").prop('checked')) {
		theme_id = theme_id == "" ? theme_id + '6' : theme_id + ',6'
	}
	if ($("#checkbox167").prop('checked')) {
		theme_id = theme_id == "" ? theme_id + '7' : theme_id + ',7'
	}
	if ($("#checkbox168").prop('checked')) {
		theme_id = theme_id == "" ? theme_id + '10' : theme_id + ',10'
	}
	
	return theme_id;
}
$("#checkbox111").click(function() {
	if ($("#checkbox111").prop('checked')) {
		dim = 1
		$(".selectProduct").hide(200)
	}
})

$("#checkbox112").click(function() {
	if ($("#checkbox112").prop('checked')) {
		dim = 6
		$(".selectProduct").show(200)
	}
})

$(".fetchNumberBtn>span").click(function() {
	showData()
})

function showData() {
	parameterTip();
	previewData()
}
function parameterTip(){
		$(".showCondition").html('')
		if(dim==1){
			$(".showCondition").append('<div> <b>数据粒度:</b> <span>店铺</span> </div>')
		}
		if(dim==6){
			$(".showCondition").append('<div> <b>数据粒度:</b> <span>商品</span> </div>')
			$(".showCondition").append('<div> <b>选择商品ID:</b> <span>'+$("#productId").val()+'</span> </div>')
		}
		if (dateType == "day") {
		$(".showCondition").append('<div> <b>时间周期:</b> <span>按天</span> </div>')
		}
		if (dateType == "week") {
			$(".showCondition").append('<div> <b>时间周期:</b> <span>按周</span> </div>')
		}
		if (dateType == "month") {
			$(".showCondition").append('<div> <b>时间周期:</b> <span>按月</span> </div>')
		}
		tm=""
		if ($("#checkbox151").prop('checked')) {
			tm="所有终端"
		}
		if ($("#checkbox152").prop('checked')) {
			tm=tm+"/"+"PC端"
		}
		if ($("#checkbox153").prop('checked')) {
			tm=tm+"/"+"无线端"
		}
		$(".showCondition").append('<div> <b>选择终端:</b> <span>'+tm+'</span> </div>')
		
	td = ""
	if ($("#checkbox163").prop('checked')) {
		td="转化"
	}
	if ($("#checkbox164").prop('checked')) {
		td=td+"/"+"推广"
	}
	if ($("#checkbox165").prop('checked')) {
		td=td+"/"+"服务"
	}
	if ($("#checkbox166").prop('checked')) {
		td=td+"/"+"评价"
	}
	if ($("#checkbox167").prop('checked')) {
		td=td+"/"+"物流"
	}
	if ($("#checkbox168").prop('checked')) {
		td=td+"/"+"互动"
	}
	$(".showCondition").append('<div> <b>选择主题:</b> <span>'+td+'</span> </div>')
}
var dim = 1;
var download_date = [];
function previewData() {
	download_date = [];
	$("#qushu_date").html("")
	$("#qushu_title").html("")
	$("#qushu_data").html("")
	if (dim == 1) {

		if (dateType == "day") {
			getTabData_day()
		}
		if (dateType == "week") {
			getTabData_week()
		}
		if (dateType == "month") {
			getTabData_month()
		}
	}
	if (dim == 6) {
		if (dateType == "day") {
			getTabData_day_item()
		}
		if (dateType == "week") {
			getTabData_week_item()
		}
		if (dateType == "month") {
			getTabData_month_item()
		}
	}
}

function addDate(date, days) {

    var date = new Date(date);
    date.setDate(date.getDate() + days);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return date.getFullYear() + '-' + getFormatDate(month) + '-' + getFormatDate(day);
}
function getFormatDate(arg) {
    if (arg == undefined || arg == '') {
        return '';
    }

    var re = arg + '';
    if (re.length < 2) {
        re = '0' + re;
    }

    return re;
}

var index=0;
function getTabData_day(){
	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType
			},
			url:server[0]._server_port+(server[0].mappings)[10]._interface,
			success:function(value){
				index++;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								preview_index_data_shop_whole(addDate(startDate, j),endDate)
								download_date.push(addDate(startDate,  j));
							}
							
						}
						
					}
				}
			}
		})

	}
	
}

function getIntervalMonth(startDate,endStart){
    var startMonth = startDate.getMonth();
    var endMonth = endStart.getMonth();
    var intervalMonth = (endStart.getFullYear()*12+endMonth) - (startDate.getFullYear()*12+startMonth);
    return intervalMonth;
}

function getTabData_month(){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))
var boolean=true;
	for(var i=0;i<=count;i++){
		var tr_id=getMonth(startDate,i);
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType
			},
			url:server[0]._server_port+(server[0].mappings)[10]._interface,
			success:function(value){index++;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index+1>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								var tr_id=getMonth(startDate,j);
								preview_index_data_shop_whole(tr_id,endDate)
								download_date.push(tr_id);
							}
						}
						
					}
				}

			}
		})
	}
}

function preview_index_data_shop_whole(sd,ed){
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			dim:dim,
			terminalId:tongji_terminal(),
			themeId:tongji_theme()
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[18]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				var th=""
				var tr=""
				var date=""
				$.each(data.data[0],function(name,value) {
					if(name =='startDate'){
						if(dateType=='day'){
							$("#qushu_date").append('<tr> <td>'+value+'</td> </tr>');
						}else{
							$("#qushu_date").append('<tr> <td>'+data.data[0].startDate+'~'+data.data[0].endDate+'</td> </tr>');
						}
					}else if(name!='endDate' && name !='startDate' && name!="shopName"&& name!="start_end_Date"){
						th=th+'<th>'+name+'</th>';
						tr=tr+'<td>'+	
						Number(value.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>';
					}
				});
				$("#qushu_title").html("")
				$("#qushu_title").append('<tr>'+th+'</tr>');
				$("#qushu_data").append('<tr>'+tr+'</tr>');
				$(".fetchNumber1").hide();
				$(".fetchNumber2").show();
			}
		}
	})
}

function getTabData_week(){
	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}
	var boolean=true;
	for(var i=0;i<count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType
			},
			url:server[0]._server_port+(server[0].mappings)[10]._interface,
			success:function(value){
				index++;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})

					if(index+1>count){index=0;
						if(boolean){
							for(var j=0;j<count;j++){
								preview_index_data_shop_whole(addDate(startDate,  7*j),endDate)
								download_date.push(addDate(startDate,  7*j));
							}
							
						}
						
					}
				}
				
			}
		})
	}
	
}

function getTabData_day_item(){
	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){

		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				productId:$("#productId").val(),
			},
			url:server[0]._server_port+(server[0].mappings)[11]._interface,
			success:function(value){index++;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								preview_index_data_goods_whole(addDate(startDate, j),endDate)
								download_date.push(addDate(startDate, j));
							}
						}
						
					}
				}

			}
		})
	}
}


function preview_index_data_goods_whole(sd,ed){
	//download_date.push(sd);
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			dim:dim,
			terminalId:tongji_terminal(),
			themeId:tongji_theme(),
			productId:$("#productId").val()
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[19]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				var th=""
				var tr=""
				var date=""
				$.each(data.data[0],function(name,value) {
					if(name =='startDate'){
						if(dateType=='day'){
							$("#qushu_date").append('<tr> <td>'+value+'</td> </tr>');
						}else{
							$("#qushu_date").append('<tr> <td>'+data.data[0].startDate+'~'+data.data[0].endDate+'</td> </tr>');
						}
					}else if(name=='endDate' || name =='startDate' || name=="shopName"|| name=="start_end_Date"){
					
					}else if(name=='product_Name' || name =='product_Id'){
						th=(name=='product_Name'?'<th>产品名称':'<th>产品id'+'</th>')+th;
						tr='<td>'+value+'</td>'+tr;
					}else{
						th=th+'<th>'+name+'</th>';
						tr=tr+'<td>'+	
						Number(value.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>';
					}
				});
				$("#qushu_title").html("")
				$("#qushu_title").append('<tr>'+th+'</tr>');
				$("#qushu_data").append('<tr>'+tr+'</tr>');
				$(".fetchNumber1").hide();
				$(".fetchNumber2").show();
			}
		}
	})
}


function getTabData_week_item(){
	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}
	var boolean=true;
	for(var i=0;i<count;i++){

		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType,
				productId:$("#productId").val(),
			},
			url:server[0]._server_port+(server[0].mappings)[11]._interface,
			success:function(value){index++;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index+1>count){index=0;
						if(boolean){
							for(var j=0;j<count;j++){
								preview_index_data_goods_whole(addDate(startDate,  7*j),endDate)
								download_date.push(addDate(startDate,  7*j));
							}
						}
						
					}
				}

			}
		})
	}
}
function getMonth(startDate,i){
	var year=parseInt(startDate.split('-')[0]);
	var month=parseInt(startDate.split('-')[1]);
	if(month+i>12){
		var count=	parseInt((month+i)/12)
		month=(month+i)-12*count;
		if(month==0){
			year=year+count-1;
			month=12;
			return year+"-"+month+"-01"
		}else{
			year=year+count;
			return year+"-"+(month>9?month:"0"+month)+"-01";
		}
		
	}else{
		month=month+i
		return year+"-"+(month>9?month:"0"+month)+"-01";
	}
}
function getTabData_month_item(){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))
	var boolean=true;
	for(var i=0;i<=count;i++){
		var tr_id=getMonth(startDate,i);
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType,
				productId:$("#productId").val(),
			},
			url:server[0]._server_port+(server[0].mappings)[11]._interface,
			success:function(value){index++;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								var tr_id=getMonth(startDate,j);
								preview_index_data_goods_whole(tr_id,endDate)
								download_date.push(tr_id);
							}
						}
					}
				}

			}
		})
	}
}

$("#qushu_download").click(function(){
	downLoad()
})
function downLoad(){
	if(dim==1){
		window.location.href=server[0]._server_port+"/option/preview_index_data_shop_wholedownLoad?dates="+download_date
		+"&dateType="+dateType+"&dim="+dim+"&terminalId="+tongji_terminal()+"&themeId="+tongji_theme();
	}
	
	if(dim==6){
		window.location.href=server[0]._server_port+"/option/preview_index_data_goods_whole_download?dates="+download_date
		+"&dateType="+dateType+"&dim="+dim+"&terminalId="+tongji_terminal()+"&themeId="+tongji_theme()+"&productId="+$("#productId").val();
	}
}