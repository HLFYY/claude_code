$.ajaxSetup({crossDomain: true, xhrFields: {withCredentials: true}});
$(".exit").click(function(){
	$.ajax({
		type:'post',
		url:server[0]._server_port+(server[0].mappings)[9]._interface,
		success:function(value){
			var data=JSON.parse(value);
			if(data.status==1){
				chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
			}
		}
	})
})
$(document).ready(function(){
	$("#checkbox001").click()
	init_top_category();
	init_report_index();
	getKeyWord()
});

function init_top_category(){
	$.ajax({
		type:"post",
		xhrFields:{withCredentials:true},
		url:server[0]._server_port+(server[0].mappings)[17]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$.each(data.data,function(index){
					if(index==0)category_id=this.cid
				$(".category1").append('<li value="'+this.cid+'" status="T"><span title="'+this.name+'">'+this.name+'</span></li>')
			})
			}
		}
	})
}
$(".selectCategory").on("mouseover", "li", function() {
	var obj=$(this);
	var name=$(this).text();
	var cg=$(this).parent().attr('class');
	$.ajax({
		type:"post",
		data:{categoryId:$(this).attr("value")},
		url:server[0]._server_port+(server[0].mappings)[15]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				if(data.data.length>0){
					obj.html("");
					obj.append('<span title="'+name+'">'+name+'</span><i class="iconfont icon-youjiantou pull-right"></i>');
				}
				if(cg=="category1"){
					$(".category2").html("")
					$.each(data.data,function(index){
						$(".category2").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
					})
				}
				if(cg=="category2"){
					$(".category3").html("")
					$.each(data.data,function(index){
						$(".category3").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
					})
				}
			}
		}
	})
});
$(".selectCategory>span").click(function(e){
	$(".selectCategory>div").show(500);
	e.stopPropagation();
    $(document,".fa-times").click(function(){
      $(".selectCategory>div").hide(500);
    })
})
var category_id='';
var report_status=true;
$("#categoryDiv").on("mouseup", "li", function() {
	if($(this).attr("status")=='T'){
		report_status=true
	}else{
		report_status=false
	}
	_switch();
	$(".selectCategory>div").hide(500);
	category_id=$(this).attr("value");
	$(".selectCategory>span").text($(this).text());
	$(this).addClass("active").siblings("li").removeClass("active");
	//showData()
});
var dp_index=0;
/*数据粒度*/
$("#checkbox111").click(function(){dp_index=0
	$("#checkbox112").prop("checked",false);
	$(".selectProduct").hide();
})
$("#checkbox112").click(function(){dp_index=1
	$("#checkbox111").prop("checked",false);
	$(".selectProduct").show();
})

function tongji_terminal(){
		var terminal_id=""
		if($("#checkbox151").prop('checked')){
			terminal_id=terminal_id==""?terminal_id+'0':terminal_id+',0'
		}
		if($("#checkbox152").prop('checked')){
			terminal_id=terminal_id==""?terminal_id+'1':terminal_id+',1'
		}
		if($("#checkbox153").prop('checked')){
			terminal_id=terminal_id==""?terminal_id+'2':terminal_id+',2'
		}
		return terminal_id;
}

function tongji_theme(){
		var theme_id=""
		if($("#checkbox163").prop('checked')){
			theme_id=theme_id==""?theme_id+'3':theme_id+',3'
		}
		if($("#checkbox164").prop('checked')){
			theme_id=theme_id==""?theme_id+'4':theme_id+',4'
		}
		if($("#checkbox165").prop('checked')){
			theme_id=theme_id==""?theme_id+'5':theme_id+',5'
		}
		if($("#checkbox166").prop('checked')){
			theme_id=theme_id==""?theme_id+'6':theme_id+',6'
		}
		if($("#checkbox167").prop('checked')){
			theme_id=theme_id==""?theme_id+'7':theme_id+',7'
		}
		if($("#checkbox168").prop('checked')){
			theme_id=theme_id==""?theme_id+'10':theme_id+',10'
		}
		return theme_id;
}

var dateType='day';
// 选择日期
$("#checkbox131").click(function(){
	$("#checkbox132,#checkbox133").prop("checked",false);
	$(".monthBox,.weekBox,.dateBox").hide();
	$(".dateBox").show();
	dateType='day';
})
$("#checkbox132").click(function(){
	$("#checkbox131,#checkbox133").prop("checked",false);
	$(".monthBox,.weekBox,.dateBox").hide();
	$(".weekBox").show();
	dateType='week';
})
$("#checkbox133").click(function(){
	$("#checkbox132,#checkbox131").prop("checked",false);
	$(".monthBox,.weekBox,.dateBox").hide();
	$(".monthBox").show();
	dateType='month';
})
 var header_tabId=0;
 $(".tabTitle>span").click(function(){
    var index=$(this).index();
    header_tabId=index;
    $(this).addClass("active").siblings("span").removeClass("active");
    $(".detailData:eq("+index+")").show().siblings(".detailData").hide();
});
$(".selectCategory").click(function(){
	$(".selectCategory>div").show();
})

$(".fetchNumberBtn>span").click(function(){
	checkAll()
})
$(".market_Btn>span").click(function(){
	checkAll()
})
$(".fetchNumber2 .reSearch").click(function(){
	$(".fetchNumber2").hide();
	$(".fetchNumber1").show();
})


$(".market2 .reSearch").click(function(){
	$(".market2").hide();
	$(".market1").show();
})
var backgroundPage = chrome.extension.getBackgroundPage();
var server=backgroundPage.getServer();

$(".header").on("click", "li", function() {
	$(this).siblings().removeClass("active");
	$(this).addClass("active");
	$(".liActive:eq("+$(this).index()+")").show().siblings(".liActive").hide();
	if($(this).text()=="下载"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/downLoad.html')});
	}else if($(this).text()=="市场"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/market_BigPlate.html')});
	}else if($(this).text()=="取数"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/options.html')});
	}
});
$("#qushu_download").click(function(){
	downLoad()
})
function downLoad(){
	if(dim==1){
		window.location.href=server[0]._server_port+"/option/preview_index_data_shop_whole_downLoad.htm?dates="+download_date
		+"&dateType="+dateType+"&dim="+dim+"&terminalId="+tongji_terminal()+"&themeId="+tongji_theme();
	}
	
	if(dim==6){
		window.location.href=server[0]._server_port+"/option/preview_index_data_goods_whole_downLoad.htm?dates="+download_date
		+"&dateType="+dateType+"&dim="+dim+"&terminalId="+tongji_terminal()+"&themeId="+tongji_theme()+"&productId="+$("#productId").val();
	}
}


var first_title=true;
var download_date=[];
function preview_index_data_shop_whole(sd,ed){
	download_date.push(sd);
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			dim:dim,
			terminalId:tongji_terminal(),
			themeId:tongji_theme()
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[18]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				var th=""
				var tr=""
				var date=""
				$.each(data.data[0],function(name,value) {
					if(name =='startDate'){
						if(dateType=='day'){
							$("#qushu_date").append('<tr> <td>'+value+'</td> </tr>');
						}else{
							$("#qushu_date").append('<tr> <td>'+data.data[0].startDate+'~'+data.data[0].endDate+'</td> </tr>');
						}
					}else if(name!='endDate' && name !='startDate' && name!="shopName"&& name!="start_end_Date"){
						th=th+'<th>'+name+'</th>';
						tr=tr+'<td>'+	
						Number(value.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>';
					}
				});
				$("#qushu_title").html("")
				$("#qushu_title").append('<tr>'+th+'</tr>');
				$("#qushu_data").append('<tr>'+tr+'</tr>');
				$(".fetchNumber1").hide();
				$(".fetchNumber2").show();
			}
		}
	})
}


function preview_index_data_goods_whole(sd,ed){
	download_date.push(sd);
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			dim:dim,
			terminalId:tongji_terminal(),
			themeId:tongji_theme(),
			productId:$("#productId").val()
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[19]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				var th=""
				var tr=""
				var date=""
				$.each(data.data[0],function(name,value) {
					if(name =='startDate'){
						if(dateType=='day'){
							$("#qushu_date").append('<tr> <td>'+value+'</td> </tr>');
						}else{
							$("#qushu_date").append('<tr> <td>'+data.data[0].startDate+'~'+data.data[0].endDate+'</td> </tr>');
						}
					}else if(name=='endDate' || name =='startDate' || name=="shopName"|| name=="start_end_Date"){
					
					}else if(name=='product_Name' || name =='product_Id'){
						th=th+(name=='product_Name'?'<th>产品名称':'<th>产品id'+'</th>');
						tr=tr+'<td>'+value+'</td>';
					}else{
						th=th+'<th>'+name+'</th>';
						tr=tr+'<td>'+	
						Number(value.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>';
					}
				});
				$("#qushu_title").html("")
				$("#qushu_title").append('<tr>'+th+'</tr>');
				$("#qushu_data").append('<tr>'+tr+'</tr>');
				$(".fetchNumber1").hide();
				$(".fetchNumber2").show();
			}
		}
	})
}

var dim=1;
function checkAll(){
	download_date=[];
	if(header_tabId==0){
		$("#qushu_date").html("")
		$("#qushu_title").html("")
		$("#qushu_data").html("")
	if(dp_index==0){dim=1;
	
		if(dateType=="day"){
			getTabData_day()
		}
		if(dateType=="week"){
			getTabData_week()
		}
		if(dateType=="month"){
			getTabData_month()
		}
	}
	if(dp_index==1){dim=6
		
		if(dateType=="day"){
			getTabData_day_item()
		}
		if(dateType=="week"){
			getTabData_week_item()
		}
		if(dateType=="month"){
			getTabData_month_item()
		}
	}
	
	}
	if(header_tabId==1){
		$("#scph_date").html("")
		$("#scph_title").html("")
		$("#scph_data").html("")
		if(btn_type==1){
			tjcheckBox();
			getDate_sc_hydp_day()
		}
		if(btn_type==2){
			market_keyword(30)
		}
		if(btn_type==3){
			market_keyword(32)
		}
		if(btn_type==4){
			market_keyword(31)
		}
		if(btn_type==5){
			market_keyword(31)
		}
		if(btn_type==6){
			market_keyword(31)
		}
		if(btn_type==7){
			market_keyword(31)
		}
	}

}
var _index_code=[]
function tjcheckBox(){
	_index_code=[];
	$.each($("#report_index").find('input'),function(index){
		if(this.checked){
			_index_code.push('['+$(this).next().text()+']')
		}
	})
}


function addDate(date, days) {

    var date = new Date(date);
    date.setDate(date.getDate() + days);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return date.getFullYear() + '-' + getFormatDate(month) + '-' + getFormatDate(day);
}
function getFormatDate(arg) {
    if (arg == undefined || arg == '') {
        return '';
    }

    var re = arg + '';
    if (re.length < 2) {
        re = '0' + re;
    }

    return re;
}
var index=0;
function getTabData_day(){
	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType
			},
			url:server[0]._server_port+(server[0].mappings)[10]._interface,
			success:function(value){
				index++;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								preview_index_data_shop_whole(addDate(startDate, j),endDate)
							}
							
						}
						
					}
				}
			}
		})

	}
	
}

function getTabData_week(){
	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7;
	}
	var boolean=true;
	for(var i=0;i<count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType
			},
			url:server[0]._server_port+(server[0].mappings)[10]._interface,
			success:function(value){
				index++;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})

					if(index+1>count){index=0;
						if(boolean){
							for(var j=0;j<count;j++){
								preview_index_data_shop_whole(addDate(startDate,  7*j),endDate)
							}
							
						}
						
					}
				}
				
			}
		})
	}
	
}

function getIntervalMonth(startDate,endStart){
    var startMonth = startDate.getMonth();
    var endMonth = endStart.getMonth();
    var intervalMonth = (endStart.getFullYear()*12+endMonth) - (startDate.getFullYear()*12+startMonth);
    return intervalMonth;
}
function getTabData_month(){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))
var boolean=true;
	for(var i=0;i<=count;i++){
		var tr_id=getMonth(startDate,i);
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType
			},
			url:server[0]._server_port+(server[0].mappings)[10]._interface,
			success:function(value){index++;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index+1>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								var tr_id=startDate.split('-')[0]+'-'+((parseInt(startDate.split('-')[1])+j)>9?(parseInt(startDate.split('-')[1])+j):'0'+(parseInt(startDate.split('-')[1])+j).toString())+'-01';
								preview_index_data_shop_whole(tr_id,endDate)
							}
						}
						
					}
				}

			}
		})
	}
}
function getTabData_day_item(){
	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){

		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				productId:$("#productId").val(),
			},
			url:server[0]._server_port+(server[0].mappings)[11]._interface,
			success:function(value){index++;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								preview_index_data_goods_whole(addDate(startDate, j),endDate)
							}
						}
						
					}
				}

			}
		})
	}
}

function getTabData_week_item(){
	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}
	var boolean=true;
	for(var i=0;i<count;i++){

		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType,
				productId:$("#productId").val(),
			},
			url:server[0]._server_port+(server[0].mappings)[11]._interface,
			success:function(value){index++;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index+1>count){index=0;
						if(boolean){
							for(var j=0;j<count;j++){
								preview_index_data_goods_whole(addDate(startDate,  7*j),endDate)
							}
						}
						
					}
				}

			}
		})
	}
}
function getMonth(startDate,i){
	var year=parseInt(startDate.split('-')[0]);
	var month=parseInt(startDate.split('-')[1]);
	if(month+i>12){
		var count=	parseInt((month+i)/12)
		month=(month+i)-12*count;
		if(month==0){
			year=year+count-1;
			month=12;
			return year+"-"+month+"-01"
		}else{
			year=year+count;
			return year+"-"+(month>9?month:"0"+month)+"-01";
		}
		
	}else{
		month=month+i
		return year+"-"+(month>9?month:"0"+month)+"-01";
	}
}
function getTabData_month_item(){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))
	var boolean=true;
	for(var i=0;i<=count;i++){
		var tr_id=getMonth(startDate,i);
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType,
				productId:$("#productId").val(),
			},
			url:server[0]._server_port+(server[0].mappings)[11]._interface,
			success:function(value){index++;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								var tr_id=startDate.split('-')[0]+'-'+((parseInt(startDate.split('-')[1])+j)>9?(parseInt(startDate.split('-')[1])+j):'0'+(parseInt(startDate.split('-')[1])+j).toString())+'-01';
								preview_index_data_goods_whole(tr_id,endDate)
							}
						}
					}
				}

			}
		})
	}
}

function getDate_sc_hydp_day(){
	var startDate;
	var endDate;
	startDate=$("#date_day_1").find("input")[0].value.trim()
	endDate=$("#date_day_1").find("input")[1].value.trim()
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:'day',
				categoryId:category_id,
				sellerId:seller_id,
				terminalId:terminal_id
			},
			url:server[0]._server_port+(server[0].mappings)[16]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								preview_report_index_data(addDate(startDate,j),endDate)
							}
						}
					}
				}

			}
		})
	}
}


function init_report_index(){
	$.ajax({
		type:'post',
		url:server[0]._server_port+(server[0].mappings)[21]._interface,
		success:function(value){
			var data=JSON.parse(value);
			if(data.status==1){
				$.each(data.data,function(index){
					if(index==0){
						report_index.push(this.indexCode);
						$("#report_index").append('<div > <input type="checkbox" class="magic-radio" id="checkbox_'+this.indexCode+'" checked="checked"> <label for="checkbox_'+this.indexCode+'" >'+this.name+'</label> </div>');
					}else{
						$("#report_index").append('<div > <input type="checkbox" class="magic-radio" id="checkbox_'+this.indexCode+'" > <label for="checkbox_'+this.indexCode+'" >'+this.name+'</label> </div>');
					}
				})
			}
		}
	})
}

var report_index=[];
$("#report_index").on("click", "input", function() {
	if($(this).attr('id').split(",")[1]=='payByrCntIndex' ||$(this).attr('id').split(",")[1]=='seIpvUvHits'||$(this).attr('id').split(",")[1]=='sePvIndex'||$(this).attr('id').split(",")[1]=='tradeIndex'){
		if(!report_status){
			report_index.push($(this).attr('id').split(",")[1])
		}
	}else{
		report_index.push($(this).attr('id').split(",")[1])
	}
})

function _switch(){
	if(report_status){
		$("#checkbox_payByrCntIndex").parent().hide()
		$("#checkbox_payByrCntIndex").prop("checked",false);
		$("#checkbox_seIpvUvHits").parent().hide()
		$("#checkbox_seIpvUvHits").prop("checked",false);
		$("#checkbox_sePvIndex").parent().hide()
		$("#checkbox_sePvIndex").prop("checked",false);
		$("#checkbox_tradeIndex").parent().hide()
		$("#checkbox_tradeIndex").prop("checked",false);
	}else{
		$("#checkbox_payByrCntIndex").parent().show()
		$("#checkbox_seIpvUvHits").parent().show()
		$("#checkbox_sePvIndex").parent().show()
		$("#checkbox_tradeIndex").parent().show()
	}
}

var seller_id=-1;
$("#checkbox221").click(function(){seller_id=-1;
	$("#checkbox222").prop("checked",false);
	$("#checkbox223").prop("checked",false);
})
$("#checkbox222").click(function(){seller_id=0;
	$("#checkbox221").prop("checked",false);
	$("#checkbox223").prop("checked",false);
})
$("#checkbox223").click(function(){seller_id=1;
	$("#checkbox221").prop("checked",false);
	$("#checkbox222").prop("checked",false);
})

var terminal_id=0;
$("#checkbox241").click(function(){terminal_id=0;
	$("#checkbox242").prop("checked",false);
	$("#checkbox243").prop("checked",false);
})
$("#checkbox242").click(function(){terminal_id=1;
	$("#checkbox241").prop("checked",false);
	$("#checkbox243").prop("checked",false);
})
$("#checkbox243").click(function(){terminal_id=2;
	$("#checkbox241").prop("checked",false);
	$("#checkbox242").prop("checked",false);
})
function preview_report_index_data(sd,ed){
	download_date.push(sd);
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:'day',
			categoryId:category_id,
			sellerId:seller_id,
			terminalId:terminal_id,
			indexCode:_index_code.toString()
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[37]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				var th=""
				var tr=""
				var date=""
				$.each(data.data[0],function(name,value) {
					if(name =='startDate'){
						if(dateType=='day'){
							$("#scph_date").append('<tr> <td>'+value+'</td> </tr>');
						}else{
							$("#scph_date").append('<tr> <td>'+data.data[0].startDate+'~'+data.data[0].endDate+'</td> </tr>');
						}
					}else if(name=='endDate' || name =='startDate' || name=="shopName"|| name=="start_end_Date"|| name=="dateType"){
						
					}else if(name=='product_Name' || name =='product_Id'){
						th=th+(name=='product_Name'?'<th>产品名称':'<th>产品id'+'</th>');
						tr=tr+'<td>'+value+'</td>';
					}else if(name=='cartByrCnt' || name =='cartTimes' || name=='cltByrCnt'||name=='cltTimes'||name=='payByrCntIndex'||name=='pv'||name=='seIpvUvHits'||name=='sePvIndex'||name=='tradeIndex'||name=='uv'){
						th=th+(name=='cartByrCnt'?"<th>加购人数":name=='cartTimes'?"<th>加购次数":name=='cltByrCnt'?"<th>收藏人数":name=='cltTimes'?"<th>收藏次数":name=='payByrCntIndex'?"<th>客群指数":
							name=='pv'?"<th>浏览量":name=='seIpvUvHits'?"<th>搜索人气":name=='sePvIndex'?"<th>搜索热度":name=='tradeIndex'?"<th>交易指数":name=='uv'?"<th>访客数":""
							+'</th>');
						tr=tr+'<td>'+	
						Number(value.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>';
					}else{
						th=th+'<th>'+name+'</th>';
						tr=tr+'<td>'+	
						Number(value.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>';
					}
				});
				$("#scph_title").html("")
				$("#scph_title").append('<tr>'+th+'</tr>');
				$("#scph_data").append('<tr>'+tr+'</tr>');
				$(".market1").hide();
				$(".market2").show();
			}
		}
	})
}

function getKeyWord(){
	$.ajax({
		type:'get',
		async:false,
		url:server[0]._server_port+(server[0].mappings)[25]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$("#keyWord_select").html('')//<option value="">全部关键词</option>
				$.each(data.data,function(){
					$("#keyWord_select").append('<option value="'+this.keyword+'">'+this.keyword+'</option>')
				})
			}else
				if(data.status==-1){
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
				}else{
					alert(data.msg)
				}
		}
	})
}

$("#keyWord_select").change(function(){
	getParent_category()
})
function getParent_category(){
	$.ajax({
		type:'post',
		async:false,
		data:{
			startDate:$("#date_day_1").find("input")[0].value.trim(),
			dateType:dateType,
			keyword:$("#keyWord_select").val(),
			device:terminal_id
			},
		url:server[0]._server_port+(server[0].mappings)[33]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$("#parent_cateId").html('')
				if(data.data.length>0){
					$.each(data.data,function(){
						$("#parent_cateId").append('<option value="'+this.cateId+'">'+this.cateName+'</option>')
					})
				}else{
					$("#parent_cateId").append('<option value="">'+$("#date_day_1").find("input")[0].value.trim()+'号未抓类目</option>')
				}
				
			}else if(data.status==-1){
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
			}else{
					alert(data.msg)
			}
		}
	})

}

$($("#date_day_1").find("input")[0]).change(function(){
	getParent_category()
})

var btn_type=1;

$("#checkbox001").click(function(){btn_type=1
	if($("#checkbox001").prop('checked')){
		$("#erji").hide(100)
		$("#sanji").hide(100)
		$("#keyWord_catagory").hide(100)
		$("#categoryDiv").parent().show(200)
		$("#report_index").parent().show(200)
		$("#checkbox222").parent().parent().show(200)
	}
})
$("#checkbox002").click(function(){
	if($("#checkbox002").prop('checked')){
		$("#erji").show(200)
		$("#categoryDiv").parent().hide(100)
		$("#report_index").parent().hide(100)
		$("#keyWord_catagory").hide(100)
		$("#sanji").hide(100)
		$("#keyWord_catagory").show(200)
		$("#parent_cateId").parent().hide(100)
		$("#checkbox222").parent().parent().hide(100)
		if($("#checkbox011").prop('checked')){
			btn_type=2
		}
		if($("#checkbox012").prop('checked')){
			$("#sanji").show(200)
		}
		if($("#checkbox013").prop('checked')){btn_type=3
			$("#keyWord_catagory").show(200)
			$("#parent_cateId").parent().show(200)
		}
		
	}
})
$("#checkbox011").click(function(){btn_type=2
	if($("#checkbox011").prop('checked')){
		$("#sanji").hide(100)
		$("#keyWord_catagory").show(200)
		$("#parent_cateId").parent().hide(100)
	}
})
$("#checkbox012").click(function(){
	if($("#checkbox012").prop('checked')){
		$("#sanji").show(200)
		$("#keyWord_catagory").show(200)
		$("#parent_cateId").parent().hide(100)
		if($("#checkbox021").prop('checked')){
			btn_type=4
		}
	}
})
$("#checkbox013").click(function(){btn_type=3
	if($("#checkbox013").prop('checked')){
		$("#sanji").hide(100)
		$("#keyWord_catagory").show(200)
		$("#parent_cateId").parent().show(200)
	}
})

$("#checkbox021").click(function(){
	btn_type=4
})
$("#checkbox022").click(function(){
	btn_type=5
})
$("#checkbox023").click(function(){
	btn_type=6
})
$("#checkbox024").click(function(){
	btn_type=7
})


function market_keyword(val){
	var startDate;
	var endDate;
	startDate=$("#date_day_1").find("input")[0].value.trim()
	endDate=$("#date_day_1").find("input")[1].value.trim()
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:'day',
				keyword:$("#keyWord_select").val(),
				device:terminal_id,
				parentcateId:$("#parent_cateId").val(),
				relatedWordsType:btn_type==4?0:btn_type==5?1:btn_type==6?2:btn_type==7?3:0
			},
			url:server[0]._server_port+(server[0].mappings)[val]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index>count){index=0;
						if(boolean){
							for(var j=0;j<=count;j++){
								Pangolin_searchword_relatedword_preview(addDate(startDate,j),endDate)
							}
						}
					}
				}
			}
		})
	}
}

function Pangolin_searchword_relatedword_preview(sd,ed){
	download_date.push(sd);
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:'day',
			keyword:$("#keyWord_select").val(),
			device:terminal_id,
			parentcateId:$("#parent_cateId").val(),
			relatedWordsType:btn_type==4?0:btn_type==5?1:btn_type==6?2:btn_type==7?3:0
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[btn_type==2?38:38]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				var th=""
				var tr=""
				var date=""
				$.each(data.data[0],function(name,value) {
					if(name =='startDate'){
						if(dateType=='day'){
							$("#scph_date").append('<tr> <td>'+value+'</td> </tr>');
						}else{
							$("#scph_date").append('<tr> <td>'+data.data[0].startDate+'~'+data.data[0].endDate+'</td> </tr>');
						}
					}else if(name=='endDate' || name =='startDate' || name=="shopName"|| name=="start_end_Date"|| name=="dateType"){
						
					}else if(name=='product_Name' || name =='product_Id'|| name =='keyword'){
					
					}else{
						th=th+'<th>'+name+'</th>';
						tr=tr+'<td>'+	
						Number(value.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>';
					}
				});
				$("#scph_title").html("")
				$("#scph_title").append('<tr>'+th+'</tr>');
				$("#scph_data").append('<tr>'+tr+'</tr>');
				$(".market1").hide();
				$(".market2").show();
			}
		}
	})
}


$("#shichang_download").click(function(){
	if(btn_type==1){
		window.location.href=server[0]._server_port+"/option/Pangolin_ShiChang_hangyedapang_preview_downLoad?dates="+download_date
		+"&dateType=day"+"&categoryId="+category_id+"&sellerId="+seller_id+"&terminalId="+terminal_id+"&indexCode="+_index_code.toString();
	}
	if(btn_type==2){
		window.location.href=server[0]._server_port+"/option/Pangolin_keyword_trend_preview_downLoad?dates="+download_date
		+"&dateType=day"+"&keyword="+$("#keyWord_select").val()+"&device="+terminal_id+"&parentcateId="+$("#parent_cateId").val()
	}
})