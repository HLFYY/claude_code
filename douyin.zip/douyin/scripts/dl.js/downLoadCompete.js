function init_top_category(){
	$.ajax({
		type:"post",
		xhrFields:{withCredentials:true},
		url:server[0]._server_port+(server[0].mappings)[17]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$.each(data.data,function(index){
					if(index==0)category_id=this.cid
				$(".category1").append('<li value="'+this.cid+'" status="T"><span title="'+this.name+'">'+this.name+'</span></li>')
			})
			}
		}
	})
}
$(".selectCategory").on("mouseover", "li", function() {
	var obj=$(this);
	var name=$(this).text();
	var cg=$(this).parent().attr('class');
	$.ajax({
		type:"post",
		data:{categoryId:$(this).attr("value")},
		url:server[0]._server_port+(server[0].mappings)[15]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				if(data.data.length>0){
					obj.html("");
					obj.append('<span title="'+name+'">'+name+'</span><i class="iconfont icon-youjiantou pull-right"></i>');
				}
				if(cg=="category1"){
					$(".category2").html("")
					$.each(data.data,function(index){
						$(".category2").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
					})
				}
				if(cg=="category2"){
					$(".category3").html("")
					$.each(data.data,function(index){
						$(".category3").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
					})
				}
			}
		}
	})
});
$(".selectCategory>span").click(function(e){
	$(".selectCategory>div").show(500);
	e.stopPropagation();
    $(document,".fa-times").click(function(){
      $(".selectCategory>div").hide(500);
    })
})
var category_id='';
var category_name="";
var report_status=true;
$("#categoryDiv").on("mouseup", "li", function() {
	if($(this).attr("status")=='T'){
		report_status=true
	}else{
		report_status=false
	}
	_switch();
	$(".selectCategory>div").hide(500);
	category_id=$(this).attr("value");
	category_name=$(this).text()
	$(".selectCategory>span").text($(this).text());
	$(this).addClass("active").siblings("li").removeClass("active");
	//showData()
});
function _switch(){
	if(report_status){
		$("#checkbox_payByrCntIndex").parent().hide()
		$("#checkbox_payByrCntIndex").prop("checked",false);
		$("#checkbox_seIpvUvHits").parent().hide()
		$("#checkbox_seIpvUvHits").prop("checked",false);
		$("#checkbox_sePvIndex").parent().hide()
		$("#checkbox_sePvIndex").prop("checked",false);
		$("#checkbox_tradeIndex").parent().hide()
		$("#checkbox_tradeIndex").prop("checked",false);
	}else{
		$("#checkbox_payByrCntIndex").parent().show()
		$("#checkbox_seIpvUvHits").parent().show()
		$("#checkbox_sePvIndex").parent().show()
		$("#checkbox_tradeIndex").parent().show()
	}
}

$(".marketBtn").click(function(){
	showTip()
	showData()
})

function showTip(){
	$(".showCondition").html("")
	if(tab==0){
		$(".showCondition").append('<div>\
	              <b>一级类目:</b>\
	              <span>竞品分析</span>\
	            </div>')
	            
	            $.each($("#keyIndicators").parent().parent().find('input'),function(index){
	            	if(this.checked){
	            		$(".showCondition").append('<div>\
	          	              <b>二级分类:</b>\
	          	              <span>'+$(this).next().text()+'</span>\
	          	            </div>')
	            	}
	            })
	            
	            if($("#entrySearch").prop('checked')){
	            	$.each($("#drainageKeywords").parent().parent().find('input'),function(index){
		            	if(this.checked){
		            		$(".showCondition").append('<div>\
		          	              <b>三级分类:</b>\
		          	              <span>'+$(this).next().text()+'</span>\
		          	            </div>')
		            	}
		            })
	            }
		$.each($("#wirelessEnd").parent().parent().find('input'),function(index){
        	if(this.checked){
        		$(".showCondition").append('<div>\
      	              <b>选择终端:</b>\
      	              <span>'+$(this).next().text()+'</span>\
      	            </div>')
        	}
        })
		$.each($("#tmall").parent().parent().find('input'),function(index){
        	if(this.checked){
        		$(".showCondition").append('<div>\
      	              <b>选择平台:</b>\
      	              <span>'+$(this).next().text()+'</span>\
      	            </div>')
        	}
        })
	}
	if(tab==1){
		$(".showCondition").append('<div>\
	              <b>一级类目:</b>\
	              <span>竞品识别</span>\
	            </div>')
	            
	            $.each($("#customer").parent().parent().find('input'),function(index){
	            	if(this.checked){
	            		$(".showCondition").append('<div>\
	          	              <b>二级分类:</b>\
	          	              <span>'+$(this).next().text()+'</span>\
	          	            </div>')
	            	}
	            })
	            
	            if($("#search").prop('checked')){
	            	$.each($("#sj1").parent().parent().find('input'),function(index){
		            	if(this.checked){
		            		$(".showCondition").append('<div>\
		          	              <b>三级分类:</b>\
		          	              <span>'+$(this).next().text()+'</span>\
		          	            </div>')
		            	}
		            })
	            }
		$.each($("#wirelessEnd").parent().parent().find('input'),function(index){
        	if(this.checked){
        		$(".showCondition").append('<div>\
      	              <b>选择终端:</b>\
      	              <span>'+$(this).next().text()+'</span>\
      	            </div>')
        	}
        })
		$(".showCondition").append('<div>\
      	              <b>选择类目:</b>\
      	              <span>'+category_name+'</span>\
      	            </div>')
	}
}
$(".reSearch").click(function(){
	$(".market2").hide();
	$(".market1").show();
})
var dateType = 'day';
$(document).ready(function() {
	checkDiv();
	init_top_category();
});

var tab=0;
function checkDiv(){
	$.each($("#competitionAnalysis").parent().parent().find('input'),function(index){
		if(this.checked)tab=index
	})
	showDiv();
}

function clearDiv(){
	$("#itemId").parent().parent().remove();
	$("#keyIndicators").parent().parent().remove();
	$("#customer").parent().parent().remove();
	$("#sj1").parent().parent().remove();
	$("#drainageKeywords").parent().parent().remove();
	$("#taobao").parent().parent().hide();
	$("#categoryDiv").parent().hide();
	$("#allTerminals").parent().parent().parent().hide();
}

function showDiv(){
	clearDiv();
	if(tab==0){
		$("#allTerminals").parent().parent().parent().show(200);
		$("#competitionAnalysis").parent().parent().after('<div class="selectProduct" style="display: block;">\
                <span>商品</span>\
                <div>\
                  <input type="text" placeholder="请输入商品ID" id="itemId">\
                </div>\
              </div>')
              
              $("#competitionAnalysis").parent().parent().next().after('<div>\
                      <span>二级分类</span>\
                      <div>\
                        <input type="radio" class="magic-radio" id="keyIndicators" name="radio2" checked="">\
                        <label for="keyIndicators" >关键指标对比</label>\
                      </div>\
                      <div>\
                        <input type="radio" class="magic-radio" id="entrySearch" name="radio2">\
                        <label for="entrySearch" >入店搜索词</label>\
                      </div>\
                      <div>\
                        <input type="radio" class="magic-radio" id="sourceEntry" name="radio2">\
                        <label for="sourceEntry" >入店来源</label>\
                      </div>\
                    </div>')
                    
                     $("#keyIndicators").parent().parent().after('<div style="display: none;">\
                             <span>三级分类</span>\
                             <div>\
                               <input type="radio" class="magic-radio" id="drainageKeywords" name="radio3"  ckecked="">\
                               <label for="drainageKeywords" >引流关键词</label>\
                             </div>\
                             <div>\
                               <input type="radio" class="magic-radio" id="closingKeywords" name="radio3">\
                               <label for="closingKeywords">成交关键词</label>\
                             </div>\
                           </div>')
	}
	if(tab==1){
		$("#categoryDiv").parent().show();
		$("#allTerminals").parent().show(200);
		$("#competitionAnalysis").parent().parent().after('<div>\
                <span>二级分类</span>\
                <div>\
                  <input type="radio" class="magic-radio" id="customer" name="radio2" checked="">\
                  <label for="customer" >顾客流失竞品推荐</label>\
                </div>\
                <div>\
                  <input type="radio" class="magic-radio" id="search" name="radio2">\
                  <label for="search" >搜索流失竞品推荐</label>\
                </div>\
              </div>')
          $("#competitionAnalysis").parent().parent().next().after('<div style="display: none;">\
                <span>三级分类</span>\
                <div>\
                  <input type="radio" class="magic-radio" id="sj1" name="radio3" checked="">\
                  <label for="sj1" >搜索引导访客数</label>\
                </div>\
                <div>\
                  <input type="radio" class="magic-radio" id="sj2" name="radio3">\
                  <label for="sj2" >搜索引导加购人数</label>\
                </div>\
        		  <div>\
                  <input type="radio" class="magic-radio" id="sj3" name="radio3" >\
                  <label for="sj3" >搜索引导支付买家数</label>\
                </div>\
                <div>\
                  <input type="radio" class="magic-radio" id="sj4" name="radio3">\
                  <label for="sj4" >搜索引导支付转化率</label>\
                </div>\
              </div>')    
              
	}
	bind();
}

function bind(){
	$("#keyIndicators").parent().parent().find('input').unbind();
	$("#keyIndicators").parent().parent().find('input').click(function(){
		if($(this).next().text()=='入店搜索词'){
			$("#drainageKeywords").parent().parent().show(200);
			$("#taobao").parent().parent().show();
		}else{
			$("#drainageKeywords").parent().parent().hide(200)
			$("#taobao").parent().parent().hide();
		}
		if($(this).next().text()=='关键指标对比'){
			$("#allTerminals").parent().show(200);
		}else{
			$("#allTerminals").parent().hide(200)
		}
		if($(this).next().text()=='入店来源'){
			$("#taobao").parent().show(200);
		}else{
			$("#taobao").parent().show(200);
		}
	})
	$("#customer").parent().parent().find('input').unbind();
	$("#customer").parent().parent().find('input').click(function(){
		if($(this).next().text()=='顾客流失竞品推荐'){
			$("#sj1").parent().parent().hide(200);
			$("#allTerminals").parent().parent().parent().hide(200);
		}else{
			$("#sj1").parent().parent().show(200);
			$("#allTerminals").parent().parent().parent().show(200);
		}
	})
}

document.addEventListener('DOMContentLoaded', function(){
	bind();
	$("#competitionAnalysis").parent().parent().find('input').click(function(){
		checkDiv()
	})
});


var download_date=[];
function showData(){
	page=1;
	pageSize=10;
	download_date=[];
	checkCondition();
	if(tab==0){
		checkVisitorDistribution()
	}
	if(tab==1){
		if(tab_1_0==0){
			checkcompetitioncustomer()
		}
		if(tab_1_0==1){
			checkcompetitionsearch()
		}
	}
}


var tab_0_0=0;
var tab_0_1=0;
var tab_0_device_text="";
var tab_0_seller_text="";
var tab_1_0=0;
var tab_1_1=0;
var tab_1_device_text="";
function checkCondition(){
	if(tab==0){
		$.each($("#keyIndicators").parent().parent().find('input'),function(index){
			if(this.checked)tab_0_0=index
		})
		$.each($("#drainageKeywords").parent().parent().find('input'),function(index){
			if(this.checked)tab_0_1=index
		})
		$.each($("#pcTerminals").parent().parent().find('input'),function(index){
			if(this.checked)tab_0_device_text=$(this).next().text()
		})
		$.each($("#taobao").parent().parent().find('input'),function(index){
			if(this.checked)tab_0_seller_text=$(this).next().text()
		})
	}
	if(tab==1){
		$.each($("#customer").parent().parent().find('input'),function(index){
			if(this.checked)tab_1_0=index
		})
		$.each($("#sj1").parent().parent().find('input'),function(index){
			if(this.checked)tab_1_1=index
		})
		$.each($("#pcTerminals").parent().parent().find('input'),function(index){
			if(this.checked)tab_1_device_text=$(this).next().text()
		})
	}
}

function checkcompetitioncustomer(){
	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				categoryId:category_id
			},
			url:server[0]._server_port+(server[0].mappings)[99]._interface,
			success:function(value){index++
				var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){

				$.each(data.data,function(index){
					if(this.status==3){
						if(boolean){
							alert(this.startDate+"号未抓取！")
							boolean=false;
						}
					}
					if(this.status==2){
						if(boolean){
							alert(this.startDate+"号数据不完整！")
							boolean=false;
						}					
					}
				})
				
				if(index>count){index=0;
				if(boolean){
					$(".timeSelect").html('')
					for(var j=0;j<=count;j++){
						download_date.push(addDate(startDate,j));
						if(j==0){
							Pangolin_checkCompetitionGoodsCustomer_preview(addDate(startDate,j),endDate);
							$(".timeSelect").append('<span class="active" value="'+addDate(startDate,j)+'">'+addDate(startDate,j)+'</span>');
						}else{
							$(".timeSelect").append('<span value="'+addDate(startDate,  j)+'">'+addDate(startDate,j)+'</span>');
						}
					}
				}
			}
			}

		}
		})
	}
}

function checkcompetitionsearch(){
	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				categoryId:category_id,
				device:tab_1_device_text=="所有终端"?0:tab_1_device_text=="PC端"?1:2,
				type:tab_1_1==0?'Uv':tab_1_1==1?'CartByrCnt':tab_1_1==2?'PayByrCnt':tab_1_1==3?'PayRate':'Uv'
			},
			url:server[0]._server_port+(server[0].mappings)[102]._interface,
			success:function(value){index++
				var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){

				$.each(data.data,function(index){
					if(this.status==3){
						if(boolean){
							alert(this.startDate+"号未抓取！")
							boolean=false;
						}
					}
					if(this.status==2){
						if(boolean){
							alert(this.startDate+"号数据不完整！")
							boolean=false;
						}					
					}
				})
				
				if(index>count){index=0;
				if(boolean){
					$(".timeSelect").html('')
					for(var j=0;j<=count;j++){
						download_date.push(addDate(startDate,j));
						if(j==0){
							Pangolin_checkcompetitionsearch_preview(addDate(startDate,j),endDate);
							$(".timeSelect").append('<span class="active" value="'+addDate(startDate,j)+'">'+addDate(startDate,j)+'</span>');
						}else{
							$(".timeSelect").append('<span value="'+addDate(startDate,  j)+'">'+addDate(startDate,j)+'</span>');
						}
					}
				}
			}
			}

		}
		})
	}
}

var index=0;
function checkVisitorDistribution(){

	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				tab:tab_0_0,
				tabOne:tab_0_1,
				topType:tab_0_1==0?"flow":"trade",
				device:tab_0_device_text=="所有终端"?0:tab_0_device_text=="PC端"?1:2,
				seller:tab_0_seller_text=="淘宝"?0:1,
				cateId:"",
				itemId:$("#itemId").val(),
			},
			url:server[0]._server_port+(server[0].mappings)[75]._interface,
			success:function(value){index++
				var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){

				$.each(data.data,function(index){
					if(this.status==3){
						if(boolean){
							alert(this.startDate+"号未抓取！")
							boolean=false;
						}
					}
					if(this.status==2){
						if(boolean){
							alert(this.startDate+"号数据不完整！")
							boolean=false;
						}					
					}
				})
				
				if(index>count){index=0;
				if(boolean){
					$(".timeSelect").html('')
					for(var j=0;j<=count;j++){
						download_date.push(addDate(startDate,j));
						if(j==0){
							Pangolin_compete_competitorAnalysis_preview(addDate(startDate,j),endDate);
							$(".timeSelect").append('<span class="active" value="'+addDate(startDate,j)+'">'+addDate(startDate,j)+'</span>');
						}else{
							$(".timeSelect").append('<span value="'+addDate(startDate,  j)+'">'+addDate(startDate,j)+'</span>');
						}
					}
				}
			}
			}

		}
		})
	}
}
$(".timeSelect").on("click","span",function(){
	$("#_date").html("")
	$("#_title").html("")
	$("#_data").html("")
	$(this).addClass("active").siblings("span").removeClass("active");
	if(tab==0){
		Pangolin_compete_competitorAnalysis_preview($(this).attr("value"),$(this).attr("value"))
	}
	if(tab==1){
		if(tab_1_0==0){
			Pangolin_checkCompetitionGoodsCustomer_preview($(this).attr("value"),$(this).attr("value"))
		}
		if(tab_1_0==1){
			Pangolin_checkcompetitionsearch_preview($(this).attr("value"),$(this).attr("value"))
		}
		
	}
})

function Pangolin_checkCompetitionGoodsCustomer_preview(sd,ed){
	startDate=sd;
	endDate=ed;
	$.ajax({
		type:'post',
		data:{
			startDate:addDate(startDate, i),
			endDate:endDate,
			dateType:dateType,
			categoryId:category_id
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[100]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			$("#_date").html('')
			$("#_title").html('')
			$("#_data").html('')
			if(data.status==1){
				if(data.data.length>0){
					$("#page").hide()
					$(".timeSelect").show()
					$("#_date").prev().html('');
					$(".timeSelect").show();
					$("#_date").prev().append('<tr>\
			                    <th>商品名称</th>\
			                    </tr>')
					$.each(data.data,function(index){
							$("#_date").append('<tr> <td>'+this.title+'</td> </tr>')
							if(index==0){
								$("#_title").append('<tr>\
										<th>流失金额</th>\
										<th>流失人数</th>\
										<th>流失率</th>\
										<th>收藏后流失人数</th>\
										<th>加购后流失人数</th>\
										<th>收藏后跳失人数</th>\
										<th>加购后跳失人数</th>\
										<th>直接跳失人数</th>\
										<th>引起流失的商品数</th>\
										<th>引起流失的店铺数</th>\
										</tr>')
							}
							$("#_data").append('<tr>\
									<td>'+Number(this.payLostAmt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.losByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.losRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.cltLosByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.cartLosByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.cltJmpByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.cartJmpByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.directLosCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.losItmCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.losShopCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									</tr>')
						})
					
				$(".market1").hide();
				$(".market2").show();
				}else{
					$("#_title").append('<tr><th conspan="100">没查到数据！请确定该时间条件下是否抓取了数据！<a href="../html/market_analysis.html" target="_blank">跳转查询！</a></th></tr>')
				}
			}
		}
	})
}


function Pangolin_checkcompetitionsearch_preview(sd,ed){
	startDate=sd;
	endDate=ed;
	$.ajax({
		type:'post',
		data:{
			startDate:addDate(startDate, i),
			endDate:endDate,
			dateType:dateType,
			categoryId:category_id,
			device:tab_1_device_text=="所有终端"?0:tab_1_device_text=="PC端"?1:2,
			type:tab_1_1==0?'Uv':tab_1_1==1?'CartByrCnt':tab_1_1==2?'PayByrCnt':tab_1_1==3?'PayRate':'Uv',
			pageIndex:page,
			pageSize:pageSize*2
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[103]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			$("#_date").html('')
			$("#_title").html('')
			$("#_data").html('')
			if(data.status==1){
				if(data.data.length>0){
					$("#page").hide()
					$(".timeSelect").show()
					$("#_date").prev().html('');
					$(".timeSelect").show();
					$("#_date").prev().append('<tr>\
			                    <th>商品名称</th>\
			                    </tr>')
					$.each(data.data,function(index){
						if(index==0){
							$("#page").show()
							$("#page").paging({
							      pageNo:page,
							      totalPage: Math.ceil(this.recordCount/(2*pageSize)),
							      totalSize: this.recordCount,
							      callback:function(value){
							    	  page=value;
							    	  Pangolin_checkcompetitionsearch_preview(startDate,endDate)
							      }
							    })
						}
							$("#_date").append('<tr> <td>'+this.title+'</td> </tr>')
							if(tab_1_1==0){
								if(index==0){
									$("#_title").append('<tr>\
											<th>搜索竞争商品数</th>\
											<th>本店商品搜索引导访客数</th>\
											<th>竞品平均搜索引导访客数</th>\
											</tr>')
								}
								$("#_data").append('<tr>\
										<td>'+Number(this.seRivalItmCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
										<td>'+Number(this.seGuideUv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
										<td>'+Number(this.rivalItmAvgSeGuideUv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
										</tr>')
							}
							if(tab_1_1==1){
								if(index==0){
									$("#_title").append('<tr>\
											<th>搜索竞争商品数</th>\
											<th>本店商品搜索引导加购人数</th>\
											<th>竞品平均搜索引导加购人数</th>\
											</tr>')
								}
								$("#_data").append('<tr>\
										<td>'+Number(this.seRivalItmCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
										<td>'+Number(this.seGuideCartByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
										<td>'+Number(this.rivalItmAvgSeGuideCartByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
										</tr>')
							}
							if(tab_1_1==2){
								if(index==0){
									$("#_title").append('<tr>\
											<th>搜索竞争商品数</th>\
											<th>本店商品搜索引导支付买家数</th>\
											<th>竞品平均搜索引导支付买家数</th>\
											</tr>')
								}
								$("#_data").append('<tr>\
										<td>'+Number(this.seRivalItmCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
										<td>'+Number(this.seGuidePayByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
										<td>'+Number(this.rivalItmAvgSeGuidePayByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
										</tr>')
							}
							if(tab_1_1==3){
								if(index==0){
									$("#_title").append('<tr>\
											<th>搜索竞争商品数</th>\
											<th>本店商品搜索引导支付转化率</th>\
											<th>竞品平均搜索引导支付转化率</th>\
											</tr>')
								}
								$("#_data").append('<tr>\
										<td>'+Number(this.seRivalItmCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
										<td>'+Number(this.seGuidePayRat.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
										<td>'+Number(this.rivalItmAvgSeGuidePayRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
										</tr>')
							}
						})
					
				$(".market1").hide();
				$(".market2").show();
				}else{
					$("#_title").append('<tr><th conspan="100">没查到数据！请确定该时间条件下是否抓取了数据！<a href="../html/market_analysis.html" target="_blank">跳转查询！</a></th></tr>')
				}
			}
		}
	})
}

var page=1;
var pageSize=10;
var startDate='';
var endDate='';
function Pangolin_compete_competitorAnalysis_preview(sd,ed){
	startDate=sd;
	endDate=ed;
	$.ajax({
		type:'post',
		data:{
			startDate:addDate(startDate, i),
			endDate:endDate,
			dateType:dateType,
			tab:tab_0_0,
			tabOne:tab_0_1,
			topType:tab_0_1==0?"flow":"trade",
			device:tab_0_device_text=="所有终端"?0:tab_0_device_text=="PC端"?1:2,
			seller:tab_0_seller_text=="淘宝"?0:1,
			cateId:"",
			itemId:$("#itemId").val(),
			pageIndex:page,
			pageSize:pageSize,
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[76]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			$("#_date").html('')
			$("#_title").html('')
			$("#_data").html('')
			if(data.status==1){
				if(data.data.length>0){
					
					$("#page").hide()
					$(".timeSelect").hide()
					$("#_date").prev().html('')
					if(tab_0_0==0){
						$(".timeSelect").show()
						$("#_date").prev().append('<tr>\
				                    <th>商品</th>\
				                    </tr>')
						$.each(data.data,function(index){

							$("#_date").append('<tr> <td style="max-width:140px;white-space: nowrap;text-overflow: ellipsis;overflow: hidden;padding-left:2px;" title="'+(data.item.name==undefined?data.item.title:data.item.name)+'">'+(data.item.name==undefined?data.item.title:data.item.name)+'</td> </tr>')
							if(index==0){
								$("#_title").append('<tr><th>类别</th> <th>流量指数</th><th>交易指数</th><th>搜索人气</th><th>收藏人气</th><th>加购人气</th><th>支付转化指数</th><th>支付商品数</th></tr>')
							}
							$("#_data").append('<tr><td>'+(this.itemType=="rival"?"竞品":"我的")+'</td><td>'+Number(this.uvIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.tradeIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.seIpvUvHits.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.cltHits.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.cartHits.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.payRateIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.payItemCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
		    	   
						})
					}
					
					if(tab_0_0==1){
						$(".timeSelect").show()
						$("#_date").prev().append('<tr>\
				                    <th>商品</th>\
				                    </tr>')
						$.each(data.data,function(index){

							$("#_date").append('<tr> <td style="max-width:140px;white-space: nowrap;text-overflow: ellipsis;overflow: hidden;padding-left:2px;" title="'+(data.item.name==undefined?data.item.title:data.item.name)+'">'+(data.item.name==undefined?data.item.title:data.item.name)+'</td> </tr>')
							if(index==0){
								$("#_title").append('<tr><th>类别</th> <th>关键词</th><th>访客数</th></tr>')
							}
							$("#_data").append('<tr><td>'+(this.itemType=="rival"?"竞品":"我的")+'</td><td>'+this.keyword+'</td><td>'+Number(this.num.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
		    	   
						})
					}
					if(tab_0_0==2){
						$(".timeSelect").show()
						$("#page").show()
						$("#page").paging({
						      pageNo:page,
						      totalPage: Math.ceil(data.total[0].num/(pageSize)),
						      totalSize: data.total[0].num,
						      callback:function(value){
						    	  page=value;
						    	  Pangolin_compete_competitorAnalysis_preview(startDate,endDate)
						      }
						    })
						    
						    $.each(data.data,function(index){

						    	$("#_date").append('<tr> <td style="max-width:140px;white-space: nowrap;text-overflow: ellipsis;overflow: hidden;padding-left:2px;" title="'+(data.item.name==undefined?data.item.title:data.item.name)+'">'+(data.item.name==undefined?data.item.title:data.item.name)+'</td> </tr>')
							if(index==0){
								$("#_title").append('<tr><th>类别</th> <th>指标</th><th>访客数</th><th>客群指数</th><th>支付转化指数</th><th>交易指数</th></tr>')
							}
							$("#_data").append('<tr><td>'+(this.itemType=="rival"?"竞品":"我的")+'</td><td>'+this.pageName+'</td><td>'+Number(this.Uv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.PayByrCntIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.PayRateIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'<td>'+Number(this.TradeIndex.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
		    	   
						})
					}
					    
					
				$(".market1").hide();
				$(".market2").show();
				}else{
					$("#_title").append('<tr><th conspan="100">没查到数据！请确定该时间条件下是否抓取了数据！<a href="../html/market_analysis.html" target="_blank">跳转查询！</a></th></tr>')
				}
			}
		}
	})
}

$("#download").click(function(){
	if(tab==0){
		window.location.href=server[0]._server_port+"/option/Pangolin_compete_competitorAnalysis_preview_download?startDate="+startDate+"&dates="+download_date
		+"&endDate="+endDate
		+"&dateType="+dateType+"&tab="+tab_0_0+"&tabOne="+tab_0_1+"&topType="+(tab_0_1==0?"flow":"trade")+"&device="+(tab_0_device_text=="所有终端"?0:tab_0_device_text=="PC端"?1:2)
		+"&seller="+(tab_0_seller_text=="淘宝"?0:1)
		+"&cateId="+""
		+"&itemId="+$("#itemId").val()
	}
	if(tab==1){
		if(tab_1_0==0){
			window.location.href=server[0]._server_port+"/option/Pangolin_checkCompetitionGoodsCustomer_download?startDate="+startDate+"&dates="+download_date
			+"&endDate="+endDate
			+"&dateType="+dateType+"&categoryId="+category_id
		}
		if(tab_1_0==1){
			window.location.href=server[0]._server_port+"/option/Pangolin_checkCompetitionGoodsSearch_preview_download?startDate="+startDate+"&dates="+download_date
			+"&endDate="+endDate
			+"&dateType="+dateType+"&categoryId="+category_id+"&device="+(tab_1_device_text=="所有终端"?0:tab_1_device_text=="PC端"?1:2)
			+"&type="+(tab_1_1==0?'Uv':tab_1_1==1?'CartByrCnt':tab_1_1==2?'PayByrCnt':tab_1_1==3?'PayRate':'Uv')
		}
	}
})