$(".marketBtn").click(function(){
	showTip()
	showData()
})

function showTip(){
	$(".showCondition").html("")
	if(tab==0){
		$(".showCondition").append('<div>\
	              <b>一级类目:</b>\
	              <span>宏观监控</span>\
	            </div>')
	            $.each($("#checkbox011").parent().parent().find('input'),function(index){
	            	if(this.checked){
	            		$(".showCondition").append('<div>\
	          	              <b>二级分类:</b>\
	          	              <span>'+$(this).next().text()+'</span>\
	          	            </div>')
	            	}
	            })
	}
}
$(".reSearch").click(function(){
	$(".market2").hide();
	$(".market1").show();
})
var dateType = 'day';
$(document).ready(function() {
	checkDiv()
});

var tab=0;
function checkDiv(){
	$.each($("#checkbox001").parent().parent().find('input'),function(index){
		if(this.checked)tab=index
	})
	showDiv();
}

function showDiv(){
	if(tab==0){
		$("#checkbox011").parent().parent().remove();
		$("#checkbox001").parent().parent().after('<div>\
                <span>二级分类</span>\
                <div>\
                  <input type="radio" class="magic-radio" id="checkbox011" name="radio2"  checked="checked" >\
                  <label for="checkbox011" >核心指标监控</label>\
                </div>\
                <div>\
                  <input type="radio" class="magic-radio" id="checkbox012" name="radio2">\
                  <label for="checkbox012">全量商品排行</label>\
                </div>\
              </div>')
              //$("#checkbox012").parent().hide();
              $("#checkbox221").parent().parent().hide(200);
	}
}



document.addEventListener('DOMContentLoaded', function(){
	$("#checkbox011").parent().parent().find('input').click(function(){
		if($(this).next().text()=='全量商品排行'){
			$("#checkbox221").parent().parent().show(200);
		}else{
			$("#checkbox221").parent().parent().hide(200)
		}
	})
	
	$("#checkbox001").parent().parent().find('input').click(function(){
		checkDiv()
	})
	$("#checkbox131").parent().parent().find('input').click(function(){
		if(this.checked){
			if($(this).next().text()=="按日"){
				dateType="day"
				$(".monthBox,.weekBox,.dateBox").hide();
				$(".dateBox").show();
			}
			if($(this).next().text()=="按周"){
				dateType="week"
				$(".monthBox,.weekBox,.dateBox").hide();
				$(".weekBox").show();
			}
			if($(this).next().text()=="按月"){
				$(".monthBox,.weekBox,.dateBox").hide();
				$(".monthBox").show();
				dateType="month"
			}
		}
	})
});


var download_date=[];
function showData(){
	page=1;
	pageSize=10;
	download_date=[];
	checkCondition();
	if(tab==0){
		if (dateType == "day") {
			data_day()
		}
		if (dateType == "week") {
			data_week()
		}
		if (dateType == "month") {
			data_month()
		}
		
	}
}


var tab_0_0=0;
var tab_0_1=0;
var tab_0_device_text="";

function checkCondition(){
	if(tab==0){
		$.each($("#checkbox001").parent().parent().find('input'),function(index){
			if(this.checked)tab_0_0=index
		})
		$.each($("#checkbox011").parent().parent().find('input'),function(index){
			if(this.checked)tab_0_1=index
		})
		$.each($("#checkbox221").parent().parent().find('input'),function(index){
			if(this.checked)tab_0_device_text=$(this).next().text()
		})
		$.each($("#checkbox131").parent().parent().find('input'),function(index){
			if(this.checked){
				if($(this).next().text()=="按日"){
					dateType="day"
				}
				if($(this).next().text()=="按周"){
					dateType="week"
				}
				if($(this).next().text()=="按月"){
					dateType="month"
				}
			}
		})
	}
	
}

function data_month(val){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))
	var boolean=true;
	for(var i=0;i<=count;i++){
		var tr_id=getMonth(startDate,i);
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType,
				tab:tab_0_1,
				device:tab_0_device_text=="所有终端"?0:tab_0_device_text=="PC端"?1:2,
			},
			url:server[0]._server_port+(server[0].mappings)[86/2]._interface,
			success:function(value){index++
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})
					
					if(index+1>count){index=0;
						if(boolean){
							$(".timeSelect").html('')
							for(var j=0;j<=count;j++){
								var tr_id=getMonth(startDate,j);
								download_date.push(tr_id);
								if(j==0){
									Pangolin_category_core_index_data_preview(tr_id,endDate);
									$(".timeSelect").append('<span class="active" value="'+tr_id+'">'+tr_id.split('-')[0]+'年'+tr_id.split('-')[1]+'月</span>');
								}else{
									$(".timeSelect").append('<span value="'+tr_id+'">'+tr_id.split('-')[0]+'年'+tr_id.split('-')[1]+'月</span>');
								}
							}
						}
						
					}
				}
			}
		})
	}
}

function data_week(){
	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}
	var boolean=true;
	for(var i=0;i<count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType,
				tab:tab_0_1,
				device:tab_0_device_text=="所有终端"?0:tab_0_device_text=="PC端"?1:2,
			},
			url:server[0]._server_port+(server[0].mappings)[86/2]._interface,
			success:function(value){
				index++;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==1){

					$.each(data.data,function(index){
						if(this.status==3){
							if(boolean){
								alert(this.startDate+"号未抓取！")
								boolean=false;
							}
						}
						if(this.status==2){
							if(boolean){
								alert(this.startDate+"号数据不完整！")
								boolean=false;
							}					
						}
					})

					if(index+1>count){index=0;
					if(boolean){
						$(".timeSelect").html('')
						for(var j=0;j<count;j++){
							download_date.push(addDate(startDate, 7*j));
							if(j==0){
								Pangolin_category_core_index_data_preview(addDate(startDate,  7*j),endDate);
								$(".timeSelect").append('<span class="active" value="'+addDate(startDate,  7*j)+'">第'+($(".timeSelect").find("span").length+1)+'周</span>');
							}else{
								$(".timeSelect").append('<span value="'+addDate(startDate,  7*j)+'">第'+($(".timeSelect").find("span").length+1)+'周</span>');
							}
						}
						//$(".timeSelect").find("span:last").remove()
					}
				}
				}
				
			}
		})
	}
	
}

var index=0;
function data_day(){

	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				tab:tab_0_1,
				device:tab_0_device_text=="所有终端"?0:tab_0_device_text=="PC端"?1:2,
			},
			url:server[0]._server_port+(server[0].mappings)[86/2]._interface,
			success:function(value){index++
				var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){

				$.each(data.data,function(index){
					if(this.status==3){
						if(boolean){
							alert(this.startDate+"号未抓取！")
							boolean=false;
						}
					}
					if(this.status==2){
						if(boolean){
							alert(this.startDate+"号数据不完整！")
							boolean=false;
						}					
					}
				})
				
				if(index>count){index=0;
				if(boolean){
					$(".timeSelect").html('')
					for(var j=0;j<=count;j++){
						download_date.push(addDate(startDate,j));
						if(j==0){
							Pangolin_category_core_index_data_preview(addDate(startDate,j),endDate);
							$(".timeSelect").append('<span class="active" value="'+addDate(startDate,j)+'">'+addDate(startDate,j)+'</span>');
						}else{
							$(".timeSelect").append('<span value="'+addDate(startDate,  j)+'">'+addDate(startDate,j)+'</span>');
						}
					}
				}
			}
			}

		}
		})
	}
}
$(".timeSelect").on("click","span",function(){
	$("#_date").html("")
	$("#_title").html("")
	$("#_data").html("")
	$(this).addClass("active").siblings("span").removeClass("active");
	if(tab==0){
		Pangolin_category_core_index_data_preview($(this).attr("value"),$(this).attr("value"))
	}
})

var page=1;
var pageSize=10;
var startDate='';
var endDate='';
function Pangolin_category_core_index_data_preview(sd,ed){
	startDate=sd;
	endDate=ed;
	$.ajax({
		type:'post',
		data:{
			startDate:addDate(startDate, i),
			endDate:endDate,
			dateType:dateType,
			tab:tab_0_1,
			device:tab_0_device_text=="所有终端"?0:tab_0_device_text=="PC端"?1:2,
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[82]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			$("#_date").html('')
			$("#_title").html('')
			$("#_data").html('')
			if(data.status==1){
				if(data.data.length>0){
					
					$("#page").hide()
					$(".timeSelect").hide()
					$("#_date").prev().html('')
					if(tab_0_1==0){
						$(".timeSelect").show()
						$("#_date").prev().append('<tr>\
				                    <th>时间</th>\
				                    </tr>')
						$.each(data.data,function(index){

							$("#_date").append('<tr> <td>'+this.startDate+(this.dateType!="day"?"~"+this.endDate:"")+'</td></tr>')
							if(index==0){
								$("#_title").append('<tr>\
										<th>下单金额</th>\
										<th>下单买家数</th>\
										<th>下单件数</th>\
										<th>下单转化率</th>\
										<th>商品加购人数</th>\
										<th>商品加购件数</th>\
										<th>商品收藏人数</th>\
										<th>商品详情页跳出率</th>\
										<th>商品浏览量</th>\
										<th>商品平均停留时长</th>\
										<th>商品访客数</th>\
										<th>支付新买家数</th>\
										<th>老买家支付金额</th>\
										<th>有支付商品数</th>\
										<th>支付金额</th>\
										<th>支付买家数</th>\
										<th>支付件数</th>\
										<th>支付老买家数</th>\
										<th>客单价</th>\
										<th>支付转化率</th>\
										<th>成功退货退款金额</th>\
										<th>访问加购转化率</th>\
										<th>访问收藏转化率</th>\
										<th>有访问商品数</th>\
										</tr>')
							}
							$("#_data").append('<tr>\
									<td>'+Number(this.crtAmt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.crtByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.crtItmQty.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.crtRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.itemCartByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.itemCartCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.itemCltByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.itmBounceRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.itmPv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.itmStayTime.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.itmUv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.newPayByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.olderPayAmt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.paidItemCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.payAmt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.payByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.payItmCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.payOldByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.payPct.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.payRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.rfdSucGoodsAmt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.visitCartRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.visitCltRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.visitedItemCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									</tr>')
		    	   
						})
					}
					if(tab_0_1==1){
						$(".timeSelect").show()
						$("#_date").prev().append('<tr>\
				                    <th>产品</th>\
				                    </tr>')
						$.each(data.data,function(index){

							$("#_date").append('<tr> <td style="max-width:140px;white-space: nowrap;text-overflow: ellipsis;overflow: hidden;padding-left:2px; title="'+this.title+'">'+this.title+'</td></tr>')
							if(index==0){
								$("#_title").append('<tr>\
										<th>itemId</th>\
										<th>下单金额</th>\
										<th>下单件数</th>\
										<th>下单转化率</th>\
										<th>商品加购人数</th>\
										<th>商品加购件数</th>\
										<th>itemCltByrCnt</th>\
										<th>商品收藏人数</th>\
										<th>商品浏览量</th>\
										<th>商品访客数</th>\
										</tr>')
							}
							$("#_data").append('<tr>\
									<td>'+this.itemId+'</td>\
									<th>'+Number(this.crtAmt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</th>\
									<th>'+Number(this.crtItmQty.toString().match(/^\d+(?:\.\d{0,4})?/))+'</th>\
									<th>'+Number(this.crtRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</th>\
									<th>'+Number(this.itemCartByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</th>\
									<th>'+Number(this.itemCartCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</th>\
									<th>'+Number(this.itemCltByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</th>\
									<th>'+Number(this.itmBounceRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</th>\
									<th>'+Number(this.itmPv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</th>\
									<td>'+Number(this.itmUv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									</tr>')
		    	   
						})
					}
				$(".market1").hide();
				$(".market2").show();
				}else{
					$("#_title").append('<tr><th conspan="100">没查到数据！请确定该时间条件下是否抓取了数据！<a href="../html/market_analysis.html" target="_blank">跳转查询！</a></th></tr>')
				}
			}
		}
	})
}



$("#download").click(function(){
	if(tab==0){
		window.location.href=server[0]._server_port+"/option/Pangolin_category_core_index_data_preview_download?startDate="+startDate+"&dates="+download_date
		+"&dateType="+dateType+"&tab="+tab_0_1+"&device="+(tab_0_device_text=="所有终端"?0:tab_0_device_text=="PC端"?1:2)
	}
})