$.ajaxSetup({
	crossDomain : true,
	xhrFields : {
		withCredentials : true
	}
});

$(".marketBtn").click(function(){
	showTip()
	showData()
})
$(".reSearch").click(function(){
	$(".market2").hide();
	$(".market1").show();
})
var dateType = 'day';
$(document).ready(function() {
	checkDiv()
});

var tab=0;
function checkDiv(){
	$.each($("#visitorAnalysis").parent().parent().find('input'),function(index){
		if(this.checked)tab=index
	})
	showDiv();
}
function clearDiv(){
	$("#timeDistribution").parent().parent().remove();
	$("#everyTime").parent().parent().remove();
	$("#taobao").parent().parent().remove();
	$("#shopPath").parent().parent().remove();
	$("#itemId").parent().parent().remove();
}

function showDiv(){
	clearDiv()
	if(tab==0){
		//<!-- 二级分类 -->
		$("#visitorAnalysis").parent().parent().after('<div>\
                <span>二级分类</span>\
                <div>\
                  <input type="radio" class="magic-radio" id="timeDistribution" name="radio_2" checked="checked">\
                  <label for="timeDistribution" >时段分布</label>\
                </div>\
                <div>\
                  <input type="radio" class="magic-radio" id="geographicalDistribution" name="radio_2">\
                  <label for="geographicalDistribution">地域分布</label>\
                </div>\
                <div>\
                  <input type="radio" class="magic-radio" id="characteristicDistribution" name="radio_2">\
                  <label for="characteristicDistribution" >特征分布</label>\
                </div>\
                <div>\
                  <input type="radio" class="magic-radio" id="behaviorDistribution" name="radio_2">\
                  <label for="behaviorDistribution">行为分布</label>\
                </div>\
              </div>')
        if($("#geographicalDistribution").prop('checked')){
        
		$("#visitorAnalysis").parent().parent().next().after('<div>\
                <span>地域分类</span>\
                <div>\
                  <input type="radio" class="magic-radio" id="visitorsRank" name="radio_3" checked="checked">\
                  <label for="visitorsRank" >访客数占比排行TOP10</label>\
                </div>\
                <div>\
                  <input type="radio" class="magic-radio" id="buyerRank" name="radio_3">\
                  <label for="buyerRank">下单买家数排行TOP10</label>\
                </div>\
              </div>')
          	
        }
	}
	
	if(tab==1){
		$("#visitorAnalysis").parent().parent().after('<div>\
	            <span>选择次数</span>\
	            <div>\
	              <input type="radio" class="magic-radio" id="everyTime" checked="checked" name="radioTime">\
	              <label for="everyTime" >每一次</label>\
	            </div>\
	            <div>\
	              <input type="radio" class="magic-radio" id="firstTime"  name="radioTime">\
	              <label for="firstTime">第一次</label>\
	            </div>\
	            <div>\
	              <input  type="radio" class="magic-radio" id="lastTime"  name="radioTime">\
	              <label for="lastTime">最后一次</label>\
	            </div>\
	          </div>')
		
	}
	if(tab==2){
		$("#visitorAnalysis").parent().parent().after('<div>\
	            <span>选择次数</span>\
	            <div>\
	              <input type="radio" class="magic-radio" id="everyTime" checked="checked" name="radioTime">\
	              <label for="everyTime" >每一次</label>\
	            </div>\
	            <div>\
	              <input type="radio" class="magic-radio" id="firstTime"  name="radioTime">\
	              <label for="firstTime">第一次</label>\
	            </div>\
	            <div>\
	              <input  type="radio" class="magic-radio" id="lastTime"  name="radioTime">\
	              <label for="lastTime">最后一次</label>\
	            </div>\
	          </div>')
	          $("#visitorAnalysis").parent().parent().after('<div class="selectProduct" style="display: block;">\
	                  <span>选择产品</span>\
	                  <div>\
	                    <input type="text" placeholder="请输入商品ID" id="itemId">\
	                  </div>\
	                </div>')
		
	}
	
	if(tab==3){
//		$("#visitorAnalysis").parent().parent().after('<div>\
//	            <span>选择平台</span>\
//	            <div>\
//	              <input type="radio" class="magic-radio" id="taobao" checked="checked" name="radio_pt">\
//	              <label for="taobao" >淘宝app</label>\
//	            </div>\
//	            <div>\
//	              <input type="radio" class="magic-radio" id="tmall" name="radio_pt">\
//	              <label for="tmall">天猫app</label>\
//	            </div>\
//	            <div>\
//	              <input  type="radio" class="magic-radio" id="wline" name="radio_pt">\
//	              <label for="wline">无线</label>\
//	            </div>\
//	          </div>')
		$("#visitorAnalysis").parent().parent().after('<div>\
                <span>二级分类</span>\
                <div>\
                  <input type="radio" class="magic-radio" id="shopPath" name="radio2" checked="checked">\
                  <label for="shopPath">店内路径</label>\
                </div>\
                <div>\
                  <input type="radio" class="magic-radio" id="pageAccessRanking" name="radio2">\
                  <label for="pageAccessRanking">页面访问排行</label>\
                </div>\
              </div>')
		
		
	}
}

function showTip(){
	$(".showCondition").html("")
	if(tab==0){
		$(".showCondition").append('<div>\
	              <b>一级类目:</b>\
	              <span>访客分析</span>\
	            </div>')
	            
	            $.each($("#timeDistribution").parent().parent().find('input'),function(index){
	            	if(this.checked){
	            		$(".showCondition").append('<div>\
	          	              <b>二级分类:</b>\
	          	              <span>'+$(this).next().text()+'</span>\
	          	            </div>')
	            	}
	            })
	            
	            if($("#geographicalDistribution").prop('checked')){
	            	$.each($("#visitorsRank").parent().parent().find('input'),function(index){
		            	if(this.checked){
		            		$(".showCondition").append('<div>\
		          	              <b>地域分类:</b>\
		          	              <span>'+$(this).next().text()+'</span>\
		          	            </div>')
		            	}
		            })
	            }
	}
	
	if(tab==1){
		$(".showCondition").append('<div>\
	              <b>一级类目:</b>\
	              <span>店铺来源</span>\
	            </div>')
	            
	            $.each($("#everyTime").parent().parent().find('input'),function(index){
	            	if(this.checked){
	            		$(".showCondition").append('<div>\
	          	              <b>二级分类:</b>\
	          	              <span>'+$(this).next().text()+'</span>\
	          	            </div>')
	            	}
	            })
	            
	}
	if(tab==2){
		$(".showCondition").append('<div>\
	              <b>一级类目:</b>\
	              <span>商品来源</span>\
	            </div>')
	            
	            $.each($("#everyTime").parent().parent().find('input'),function(index){
	            	if(this.checked){
	            		$(".showCondition").append('<div>\
	          	              <b>二级分类:</b>\
	          	              <span>'+$(this).next().text()+'</span>\
	          	            </div>')
	            	}
	            })
	            
	}
	if(tab==3){
		$(".showCondition").append('<div>\
	              <b>一级类目:</b>\
	              <span>店内路径</span>\
	            </div>')
	            
	            $.each($("#shopPath").parent().parent().find('input'),function(index){
	            	if(this.checked){
	            		$(".showCondition").append('<div>\
	          	              <b>二级分类:</b>\
	          	              <span>'+$(this).next().text()+'</span>\
	          	            </div>')
	            	}
	            })
	            $.each($("#taobao").parent().parent().find('input'),function(index){
	            	if(this.checked){
	            		$(".showCondition").append('<div>\
	          	              <b>选择平台:</b>\
	          	              <span>'+$(this).next().text()+'</span>\
	          	            </div>')
	            	}
	            })
	}
	
	if(tab==4){
		$(".showCondition").append('<div>\
	              <b>一级类目:</b>\
	              <span>选词助手</span>\
	            </div>')
		
	}
}


document.addEventListener('DOMContentLoaded', function(){
	$("#timeDistribution").parent().parent().find('input').click(function(){
		$("#visitorsRank").parent().parent().remove();
		if($(this).next().text()=='地域分布'){
			$("#visitorAnalysis").parent().parent().next().after('<div>\
	                <span>地域分类</span>\
	                <div>\
	                  <input type="radio" class="magic-radio" id="visitorsRank" name="radio_3" checked="checked">\
	                  <label for="visitorsRank" >访客数占比排行TOP10</label>\
	                </div>\
	                <div>\
	                  <input type="radio" class="magic-radio" id="buyerRank" name="radio_3">\
	                  <label for="buyerRank">下单买家数排行TOP10</label>\
	                </div>\
	              </div>')
		}
		if($("#visitorContrast").prop('checked')){
			$("#radio221").parent().parent().hide(200);
		}else{
			$("#radio221").parent().parent().show(200);
		}
		
	})
	
	$("#visitorAnalysis").parent().parent().find('input').click(function(){
		checkDiv()
	})
	
});

var VisitorDistribution_tab=0;
var VisitorDistribution_tabOne=0;
var device=0;
var belong='all';
var device_1=4;
var tab_2=0;
function checkCondition(){
	$.each($("#timeDistribution").parent().parent().find('input'),function(index){
		if(this.checked)VisitorDistribution_tab=index
	})
	$.each($("#visitorsRank").parent().parent().find('input'),function(index){
		if(this.checked)VisitorDistribution_tabOne=index
	})
	$.each($("#radio221").parent().parent().find('input'),function(index){
		if(this.checked)device=index
	})
	$.each($("#everyTime").parent().parent().find('input'),function(index){
		if(this.checked){
			if(index==0)belong='all';
			if(index==1)belong='nearest';
			if(index==2)belong='farthest';
		}
	})
	$.each($("#shopPath").parent().parent().find('input'),function(index){
		if(this.checked){
			tab_2=index;
		}
	})
	$.each($("#taobao").parent().parent().find('input'),function(index){
		if(this.checked){
			if(index==0)device_1=4;
			if(index==1)device_1=5;
			if(index==2)device_1=3;
		}
	})
}

var download_date=[];
function showData(){
	page=1;
	pageSize=10;
	download_date=[];
	checkCondition();
	if(tab==0){
		checkVisitorDistribution()
	}
	if(tab==1){
		checkFlowShopData()
	}
	if(tab==2){
		checkFlowProductSourceData()
	}
	if(tab==3){
		checkFlowShopPathData()
	}
	if(tab==4){
		checkFlowDictionAssistantDrainageKeyword()
	}
	
}

function checkFlowDictionAssistantDrainageKeyword(){
	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				device:device
			},
			url:server[0]._server_port+(server[0].mappings)[97]._interface,
			success:function(value){index++
				var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){

				$.each(data.data,function(index){
					if(this.status==3){
						if(boolean){
							alert(this.startDate+"号未抓取！")
							boolean=false;
						}
					}
					if(this.status==2){
						if(boolean){
							alert(this.startDate+"号数据不完整！")
							boolean=false;
						}					
					}
				})
				
				if(index>count){index=0;
				if(boolean){
					$(".timeSelect").html('')
					for(var j=0;j<=count;j++){
						download_date.push(addDate(startDate,j));
						if(j==0){
							Pangolin_checkFlowDictionAssistantDrainageKeyword_preview(addDate(startDate,j),endDate);
							$(".timeSelect").append('<span class="active" value="'+addDate(startDate,j)+'">'+addDate(startDate,j)+'</span>');
						}else{
							$(".timeSelect").append('<span value="'+addDate(startDate,  j)+'">'+addDate(startDate,j)+'</span>');
						}
					}
				}
			}
			}

		}
		})
	}
}

function Pangolin_checkFlowDictionAssistantDrainageKeyword_preview(sd,ed){
	startDate=sd;
	endDate=ed;
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			device:device,
			pageIndex:page,
			pageSize:pageSize*2
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[98]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			$("#_date").html('')
			$("#_title").html('')
			$("#_data").html('')
			if(data.status==1){
				if(data.data.length>0){
					$("#page").show()
					$(".timeSelect").hide()
					$("#_date").prev().html('')
					$("#_date").parent().parent().parent().show()
					//$(".visitorContrast").hide()
					if(true){
						$("#page").show()
						$("#page").paging({
						      pageNo:page,
						      totalPage: Math.ceil(data.total[0].num/(2*pageSize)),
						      totalSize: data.total[0].num,
						      callback:function(value){
						    	  page=value;
						    	  Pangolin_checkFlowDictionAssistantDrainageKeyword_preview(startDate,endDate)
						      }
						    })
						
						$(".timeSelect").show()
						$("#_date").prev().append('<tr>\
				                    <th>搜索词</th>\
				                    </tr>')
						var sd='';
						$.each(data.data,function(index){
							$("#_date").append('<tr> <td>'+this.keyword+'</td> </tr>')
							if(index==0){
								$("#_title").append('<tr>\
										<th>带来的访客数</th>\
										<th>引导下单转化率</th>\
										<th>全网搜索热度</th>\
										<th>全网点击率</th>\
										<th>全网商品数</th>\
										</tr>')
							}
							$("#_data").append('<tr>\
									<td>'+Number(this.seDuv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.seLeOrderRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.gbSpv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.gbClickRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.gbItemCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									</tr>')
						})
					}
					
				$(".market1").hide();
				$(".market2").show();
				}else{
					$("#_title").append('<tr><th conspan="100">没查到数据！请确定该时间条件下是否抓取了数据！<a href="../html/market_analysis.html" target="_blank">跳转查询！</a></th></tr>')
				}
			}
		}
	})
}

function checkFlowProductSourceData(){

	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				belong:belong,
				device:device,
				itemId:$("#itemId").val()
			},
			url:server[0]._server_port+(server[0].mappings)[90]._interface,
			success:function(value){index++
				var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){

				$.each(data.data,function(index){
					if(this.status==3){
						if(boolean){
							alert(this.startDate+"号未抓取！")
							boolean=false;
						}
					}
					if(this.status==2){
						if(boolean){
							alert(this.startDate+"号数据不完整！")
							boolean=false;
						}					
					}
				})
				
				if(index>count){index=0;
				if(boolean){
					$(".timeSelect").html('')
					for(var j=0;j<=count;j++){
						download_date.push(addDate(startDate,j));
						if(j==0){
							Pangolin_checkproductSourceData_preview(addDate(startDate,j),endDate);
							$(".timeSelect").append('<span class="active" value="'+addDate(startDate,j)+'">'+addDate(startDate,j)+'</span>');
						}else{
							$(".timeSelect").append('<span value="'+addDate(startDate,  j)+'">'+addDate(startDate,j)+'</span>');
						}
					}
				}
			}
			}

		}
		})
	}
}


function Pangolin_checkproductSourceData_preview(sd,ed){
	startDate=sd;
	endDate=ed;
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			belong:belong,
			device:device,
			itemId:$("#itemId").val(),
			pageIndex:page,
			pageSize:pageSize*2
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[91]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			$("#_date").html('')
			$("#_title").html('')
			$("#_data").html('')
			if(data.status==1){
				if(data.data.length>0){
					
					$("#page").hide()
					$(".timeSelect").hide()
					$("#_date").prev().html('')
					$("#_date").parent().parent().parent().show()
					//$(".visitorContrast").hide()
					if(true){
						$(".timeSelect").show()
						$("#_date").prev().append('<tr>\
				                    <th>流量来源</th>\
				                    </tr>')
						var sd='';
						$.each(data.data,function(index){
							$("#_date").append('<tr> <td>'+this.pageName+'</td> </tr>')
							if(index==0){
								$("#_title").append('<tr>\
										<th>加购人数</th>\
										<th>收藏人数</th>\
										<th>收藏商品-支付买家数</th>\
										<th>下单买家数</th>\
										<th>下单转化率</th>\
										<th>直接支付买家数</th>\
										<th>曝光人数</th>\
										<th>粉丝支付买家数</th>\
										<th>店内跳转人数</th>\
										<th>跳出本店人数</th>\
										<th>加购商品-支付买家数</th>\
										<th>支付买家数</th>\
										<th>支付件数</th>\
										<th>支付转化率</th>\
										<th>浏览量</th>\
										<th>访客数</th>\
										</tr>')
							}
							$("#_data").append('<tr>\
									<td>'+Number(this.cartByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.cltCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.cltItmPayByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.crtByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.crtRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.directPayByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.expUv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.fansPayByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.jpSelfUv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.jpUv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.ordItmPayByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.payByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.payItmCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.payRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.pv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.uv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									</tr>')
						})
					}
					
				$(".market1").hide();
				$(".market2").show();
				}else{
					$("#_title").append('<tr><th conspan="100">没查到数据！请确定该时间条件下是否抓取了数据！<a href="../html/market_analysis.html" target="_blank">跳转查询！</a></th></tr>')
				}
			}
		}
	})
}

function addDate(date, days) {

    var date = new Date(date);
    date.setDate(date.getDate() + days);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return date.getFullYear() + '-' + getFormatDate(month) + '-' + getFormatDate(day);
}
//日期月份/天的显示，如果是1位数，则在前面加上'0'
function getFormatDate(arg) {
    if (arg == undefined || arg == '') {
        return '';
    }

    var re = arg + '';
    if (re.length < 2) {
        re = '0' + re;
    }

    return re;
}
var index=0;
function checkFlowShopPathData(){

	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				device:device,
				tab:tab_2,
				deviceLogicType:device==1?1:device==2?20:device
			},
			url:server[0]._server_port+(server[0].mappings)[86]._interface,
			success:function(value){index++
				var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){

				$.each(data.data,function(index){
					if(this.status==3){
						if(boolean){
							alert(this.startDate+"号未抓取！")
							boolean=false;
						}
					}
					if(this.status==2){
						if(boolean){
							alert(this.startDate+"号数据不完整！")
							boolean=false;
						}					
					}
				})
				
				if(index>count){index=0;
				if(boolean){
					$(".timeSelect").html('')
					for(var j=0;j<=count;j++){
						download_date.push(addDate(startDate,j));
						if(j==0){
							Pangolin_checkshopPathData_preview(addDate(startDate,j),endDate);
							$(".timeSelect").append('<span class="active" value="'+addDate(startDate,j)+'">'+addDate(startDate,j)+'</span>');
						}else{
							$(".timeSelect").append('<span value="'+addDate(startDate,  j)+'">'+addDate(startDate,j)+'</span>');
						}
					}
				}
			}
			}
		}
		})
	}
}


function Pangolin_checkshopPathData_preview(sd,ed){
	startDate=sd;
	endDate=ed;
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			device:device,
			tab:tab_2,
			deviceLogicType:device==1?1:device==2?20:device
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[92]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			$("#_date").html('')
			$("#_title").html('')
			$("#_data").html('')
			if(data.status==1){
				if(data.data.length>0){
					
					$("#page").hide()
					$(".timeSelect").hide()
					$("#_date").prev().html('')
					$("#_date").parent().parent().parent().show()
					if(true){
						$(".timeSelect").show()
						$("#_date").prev().append('<tr>\
				                    <th>类别</th>\
				                    </tr>')
				        if(tab_2==0){
						var pid='';
						$.each(data.data,function(index){
							$("#_date").append('<tr> <td>'+this.p_name+'</td> </tr>')
							if(index==0){
								$("#_title").append('<tr>\
										<th>来源/去向</th>\
										<th>名称</th>\
										<th>访客数</th>\
										<th>支付金额</th>\
										</tr>')
							}
							$("#_data").append('<tr>\
									<td>'+(this.type=="from"?"来源":"去向")+'</td>\
									<td>'+(this.name)+'</td>\
									<td>'+this.uv+'</td>\
									<td>'+(this.payAmt==undefined?"/":this.payAmt)+'</td>\
									</tr>')
						})
				        }else{
				        	$.each(data.data,function(index){
								$("#_date").append('<tr> <td>'+this.p_name+'</td> </tr>')
								if(index==0){
									$("#_title").append('<tr>\
											<th>名称</th>\
											<th>访客数</th>\
											<th>浏览量</th>\
											<th>平均停留时长</th>\
											</tr>')
								}
								$("#_data").append('<tr>\
										<td>'+this.title+'</td>\
										<td>'+this.uv+'</td>\
										<td>'+this.pv+'</td>\
										<td>'+Number(this.stayTime.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
										</tr>')
							})
				        }
					}
					
				$(".market1").hide();
				$(".market2").show();
				}else{
					$("#_title").append('<tr><th conspan="100">没查到数据！请确定该时间条件下是否抓取了数据！<a href="../html/market_analysis.html" target="_blank">跳转查询！</a></th></tr>')
				}
			}
		}
	})
}

var index=0;
function checkFlowShopData(){

	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				belong:belong,
				device:device
			},
			url:server[0]._server_port+(server[0].mappings)[83]._interface,
			success:function(value){index++
				var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){

				$.each(data.data,function(index){
					if(this.status==3){
						if(boolean){
							alert(this.startDate+"号未抓取！")
							boolean=false;
						}
					}
					if(this.status==2){
						if(boolean){
							alert(this.startDate+"号数据不完整！")
							boolean=false;
						}					
					}
				})
				
				if(index>count){index=0;
				if(boolean){
					$(".timeSelect").html('')
					for(var j=0;j<=count;j++){
						download_date.push(addDate(startDate,j));
						if(j==0){
							Pangolin_checkFlowShopData_preview(addDate(startDate,j),endDate);
							$(".timeSelect").append('<span class="active" value="'+addDate(startDate,j)+'">'+addDate(startDate,j)+'</span>');
						}else{
							$(".timeSelect").append('<span value="'+addDate(startDate,  j)+'">'+addDate(startDate,j)+'</span>');
						}
					}
				}
			}
			}

		}
		})
	}
}

var index=0;
function checkVisitorDistribution(){

	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	var boolean=true;
	for(var i=0;i<=count;i++){
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				tab:VisitorDistribution_tab,
				tabOne:VisitorDistribution_tabOne,
				device:device
			},
			url:server[0]._server_port+(server[0].mappings)[65]._interface,
			success:function(value){index++
				var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){

				$.each(data.data,function(index){
					if(this.status==3){
						if(boolean){
							alert(this.startDate+"号未抓取！")
							boolean=false;
						}
					}
					if(this.status==2){
						if(boolean){
							alert(this.startDate+"号数据不完整！")
							boolean=false;
						}					
					}
				})
				
				if(index>count){index=0;
				if(boolean){
					$(".timeSelect").html('')
					for(var j=0;j<=count;j++){
						download_date.push(addDate(startDate,j));
						if(j==0){
							Pangolin_flow_visitorAnalysis_preview(addDate(startDate,j),endDate);
							$(".timeSelect").append('<span class="active" value="'+addDate(startDate,j)+'">'+addDate(startDate,j)+'</span>');
						}else{
							$(".timeSelect").append('<span value="'+addDate(startDate,  j)+'">'+addDate(startDate,j)+'</span>');
						}
					}
				}
			}
			}
		}
		})
	}
}



$(".timeSelect").on("click","span",function(){
	page=1;
	pageSize=10;
	startDate='';
	endDate='';
	$("#_date").html("")
	$("#_title").html("")
	$("#_data").html("")
	$(this).addClass("active").siblings("span").removeClass("active");
	if(tab==0){
		Pangolin_flow_visitorAnalysis_preview($(this).attr("value"),$(this).attr("value"))
	}
	if(tab==1){
		Pangolin_checkFlowShopData_preview($(this).attr("value"),$(this).attr("value"))
	}
	if(tab==2){
		Pangolin_checkproductSourceData_preview($(this).attr("value"),$(this).attr("value"))
	}
	if(tab==3){
		Pangolin_checkshopPathData_preview($(this).attr("value"),$(this).attr("value"))
	}
	if(tab==4){
		Pangolin_checkFlowDictionAssistantDrainageKeyword_preview($(this).attr("value"),$(this).attr("value"))
	}
})

var page=1;
var pageSize=10;
var startDate='';
var endDate='';
function Pangolin_flow_visitorAnalysis_preview(sd,ed){
	startDate=sd;
	endDate=ed;
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			tab:VisitorDistribution_tab,
			tabOne:VisitorDistribution_tabOne,
			device:device,
			pageIndex:page,
			pageSize:pageSize
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[66]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			$("#_date").html('')
			$("#_title").html('')
			$("#_data").html('')
			if(data.status==1){
				if(data.data.length>0){
					
					$("#page").hide()
					$(".timeSelect").hide()
					$("#_date").prev().html('')
					$("#_date").parent().parent().parent().show()
					$(".visitorContrast").hide()
					if(VisitorDistribution_tab==0){
						
						$("#page").show()
						$("#page").paging({
						      pageNo:page,
						      totalPage: Math.ceil(data.total[0].num/(2*pageSize)),
						      totalSize: data.total[0].num,
						      callback:function(value){
						    	  page=value;
						    	  Pangolin_flow_visitorAnalysis_preview(startDate,endDate)
						      }
						    })
						
						$("#_date").prev().append('<tr>\
				                    <th>日期</th>\
				                    </tr>')
						var sd='';
						$.each(data.data,function(index){
							if(sd!=this.startDate){
								sd=this.startDate;
								$("#_date").append('<tr>\
					                    <td rowspan="2" style="height: 72px;min-width: 150px;">'+this.startDate+'</td>\
					                    </tr>')
							}
							if(index==0){
								$("#_title").append('<tr>\
										<th>类别</th>\
					                    <th>0点</th>\
					                    <th>1点</th>\
										<th>2点</th>\
					                    <th>3点</th>\
					                    <th>4点</th>\
					                    <th>5点</th>\
					                    <th>6点</th>\
					                    <th>7点</th>\
					                    <th>8点</th>\
					                    <th>9点</th>\
					                    <th>10点</th>\
					                    <th>11点</th>\
					                    <th>12点</th>\
					                    <th>13点</th>\
					                    <th>14点</th>\
					                    <th>15点</th>\
					                    <th>16点</th>\
					                    <th>17点</th>\
					                    <th>18点</th>\
					                    <th>19点</th>\
					                    <th>20点</th>\
					                    <th>21点</th>\
					                    <th>22点</th>\
					                    <th>23点</th>\
					                  </tr>')
							}
							$("#_data").append('<tr>\
									<td>\
				                      <span>'+this.index_code_name+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[0]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[1]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[2]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[3]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[4]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[5]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[6]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[7]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[8]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[9]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[10]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[11]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[12]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[13]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[14]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[15]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[16]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[17]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[18]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[19]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[20]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[21]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[22]+'</span>\
				                    </td>\
				                    <td>\
				                      <span>'+this[23]+'</span>\
				                    </td>\
				                    <tr>')
			    		})
					}
					    
					if(VisitorDistribution_tab==1){
						$(".timeSelect").show()
						$("#_date").prev().append('<tr>\
				                    <th>地域</th>\
				                    </tr>')
				       if(VisitorDistribution_tabOne==0){ 
				    	   $.each(data.data,function(index){
									$("#_date").append('<tr> <td>'+this.cityName+'</td> </tr>')
									if(index==0){
										$("#_title").append('<tr> <th>访客数</th><th>下单转化率</th></tr>')
									}
									$("#_data").append('<tr><td>'+this.uv+'</td><td>'+Number(this.orderRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
				    	   })
				        }else{
					    	   $.each(data.data,function(index){
										$("#_date").append('<tr> <td>'+this.cityName+'</td> </tr>')
										if(index==0){
											$("#_title").append('<tr> <th>下单买家数</th><th>下单转化率</th></tr>')
										}
										$("#_data").append('<tr><td>'+this.orderBuyerCnt+'</td><td>'+Number(this.orderRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
					    	   })
				        }
					}
					
					if(VisitorDistribution_tab==2){
						$(".timeSelect").show()
						$("#_date").prev().append('<tr>\
				                    <th>类型</th>\
				                    </tr>')
				        var feature_type="";
						var color="#f5f5f5";
						$.each(data.data,function(index){

							if(feature_type!=this.feature_type){
								feature_type=this.feature_type;
								if(index!=0)color=color=="#fff"?"#f5f5f5":"#fff"
								if(this.feature_type=='consumerLvls'){
									$("#_date").append('<tr> <td style="height:216px;">消费层级</td> </tr>')
								}
								if(this.feature_type=='memberLvls'){
									$("#_date").append('<tr > <td style="height:216px;">淘气值分布</td> </tr>')
								}
								if(this.feature_type=='sexs'){
									$("#_date").append('<tr> <td   style="height:120px;">性别</td> </tr>')
								}
								if(this.feature_type=='customs'){
									$("#_date").append('<tr> <td  style="height:72px;">店铺新老访客</td> </tr>')
								}
								$("#_data").append('<tr style="background:'+color+';"><td>'+this.name+'</td><td>'+this.uv+'</td><td>'+this.ratio+'</td><td>'+Number(this.orderRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
								
							}else{
								$("#_data").append('<tr style="background:'+color+';"><td>'+this.name+'</td><td>'+this.uv+'</td><td>'+this.ratio+'</td><td>'+Number(this.orderRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
							}
							
							if(index==0){
								$("#_title").append('<tr><th>名称</th><th>访客数</th><th>占比</th><th>下单转化率</th></tr>')
							}
							
		    	   })
					}
					
					if(VisitorDistribution_tab==3){
						$(".timeSelect").show()
						$("#_date").prev().append('<tr>\
				                    <th>类型</th>\
				                    </tr>')
				        var behavior_type="";
						var color="#f5f5f5";
						$.each(data.data,function(index){

							if(behavior_type!=this.behavior_type){
								behavior_type=this.behavior_type;
								if(index!=0)color=color=="#fff"?"#f5f5f5":"#fff"
								if(this.behavior_type=='keywords'){
									$("#_date").append('<tr> <td style="height:180px;">来源关键词TOP5</td> </tr>')
								}
								if(this.behavior_type=='pages'){
									$("#_date").append('<tr > <td style="height:180px;">浏览量分布</td> </tr>')
								}
								
								$("#_data").append('<tr style="background:'+color+';"><td>'+this.name+'</td><td>'+this.uv+'</td><td>'+Number(this.ratio.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.orderRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
								
							}else{
								$("#_data").append('<tr style="background:'+color+';"><td>'+this.name+'</td><td>'+this.uv+'</td><td>'+Number(this.ratio.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td><td>'+Number(this.orderRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td></tr>')
							}
							
							if(index==0){
								$("#_title").append('<tr><th>名称</th><th>访客数</th><th>占比</th><th>下单转化率</th></tr>')
							}
							
		    	   })
					}
					
					if(VisitorDistribution_tab==4){
						$("#_date").parent().parent().parent().hide()
						$(".visitorContrast").show()
						$(".timeSelect").show()
						var column_Type="";
						var td_str="";
						var c1=0,c2=0,c3=0;
						$.each(data.data,function(index){
							if(this.column_Type=="noBuyer"){
								$('#'+this.row_Type+'>td:eq(0)').find("span").html('(属于'+(this.explain_value==undefined?this.row_Type=="sexs"?this.explain_id=="300004"?"女人知音":"男人知音":this.explain_value:this.explain_value)+")")
									$('#'+this.row_Type+'>td:eq(1)').append('<p><span>'+this.name+'</span><b>占比：<i>'+Number(this.ratio.toString().match(/^\d+(?:\.\d{0,4})?/))+'</i></b></p>');
									c1=c1+this.total;
							}
							if(this.column_Type=="newBuyer"){
								$('#'+this.row_Type+'>td:eq(0)').find("span").html('(属于'+(this.explain_value==undefined?this.row_Type=="sexs"?this.explain_id=="300004"?"女人知音":"男人知音":this.explain_value:this.explain_value)+")")
								$('#'+this.row_Type+'>td:eq(2)').append('<p><span>'+this.name+'</span><b>占比：<i>'+Number(this.ratio.toString().match(/^\d+(?:\.\d{0,4})?/))+'</i></b></p>');
								c2=c2+this.total;
							}
							if(this.column_Type=="oldBuyer"){
								$('#'+this.row_Type+'>td:eq(0)').find("span").html('(属于'+(this.explain_value==undefined?this.row_Type=="sexs"?this.explain_id=="300004"?"女人知音":"男人知音":this.explain_value:this.explain_value)+")")
								$('#'+this.row_Type+'>td:eq(3)').append('<p><span>'+this.name+'</span><b>占比：<i>'+Number(this.ratio.toString().match(/^\d+(?:\.\d{0,4})?/))+'</i></b></p>');
								c3=c3+this.total;
							}
						})
						$(".visitorContrast thead").html('<tr>\
			                      <th style="width: 16%"></th>\
			                      <th style="width: 28%;text-align:center;">未支付访客(<span>'+c1+'</span>人)</th>\
			                      <th style="width: 28%;text-align:center;">支付新买家(<span>'+c2+'</span>人)</th>\
			                      <th style="width: 28%;text-align:center;">支付老买家(<span>'+c3+'</span>人)</th>\
			                    </tr>')
					}
				$(".market1").hide();
				$(".market2").show();
				}else{
					$("#_title").append('<tr><th conspan="100">没查到数据！请确定该时间条件下是否抓取了数据！<a href="../html/market_analysis.html" target="_blank">跳转查询！</a></th></tr>')
				}
			}
		}
	})
}

var page=1;
var pageSize=10;
var startDate='';
var endDate='';
function Pangolin_checkFlowShopData_preview(sd,ed){
	startDate=sd;
	endDate=ed;
	$.ajax({
		type:'post',
		data:{
			startDate:sd,
			endDate:ed,
			dateType:dateType,
			belong:belong,
			device:device,
			pageIndex:page,
			pageSize:pageSize*2
		},
		async:false,
		url:server[0]._server_port+(server[0].mappings)[84]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			$("#_date").html('')
			$("#_title").html('')
			$("#_data").html('')
			if(data.status==1){
				if(data.data.length>0){
					
					$("#page").hide()
					$(".timeSelect").hide()
					$("#_date").prev().html('')
					$("#_date").parent().parent().parent().show()
					if(VisitorDistribution_tab==0){
						$("#page").show()
						$(".timeSelect").show()
						$("#page").paging({
						      pageNo:page,
						      totalPage: Math.ceil(data.total[0].num/(2*pageSize)),
						      totalSize: data.total[0].num,
						      callback:function(value){
						    	  page=value;
						    	  Pangolin_checkFlowShopData_preview(startDate,endDate)
						      }
						    })
						
						$("#_date").prev().append('<tr>\
				                    <th>流量来源</th>\
				                    </tr>')
						var sd='';
						$.each(data.data,function(index){
							$("#_date").append('<tr> <td>'+this.pageName+'</td> </tr>')
							if(index==0){
								$("#_title").append('<tr>\
										<th>加购人数</th>\
										<th>收藏商品-支付买家数</th>\
										<th>下单买家数</th>\
										<th>下单转化率</th>\
										<th>下单金额</th>\
										<th>直接支付买家数</th>\
										<th>曝光人数</th>\
										<th>粉丝支付买家数</th>\
										<th>新访客数</th>\
										<th>加购商品-支付买家数</th>\
										<th>支付金额</th>\
										<th>支付买家数</th>\
										<th>客单价</th>\
										<th>支付转化率</th>\
										<th>访客数</th>\
										<th>UV价值</th>\
										</tr>')
							}
							$("#_data").append('<tr>\
									<td>'+Number(this.cartByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.cltItmPayByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.crtByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.crtRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.crtVldAmt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.directPayByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.expUv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.fansPayByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.newUv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.ordItmPayByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.payAmt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.payByrCnt.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.payPct.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.payRate.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.uv.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									<td>'+Number(this.uvValue.toString().match(/^\d+(?:\.\d{0,4})?/))+'</td>\
									</tr>')
						})
					}
					
				$(".market1").hide();
				$(".market2").show();
				}else{
					$("#_title").append('<tr><th conspan="100">没查到数据！请确定该时间条件下是否抓取了数据！<a href="../html/market_analysis.html" target="_blank">跳转查询！</a></th></tr>')
				}
			}
		}
	})
}

$("#download").click(function(){
	if(tab==0){
		window.location.href=server[0]._server_port+"/option/Pangolin_flow_visitorAnalysis_preview_download?startDate="+startDate+"&dates="+download_date
		+"&endDate="+endDate
		+"&dateType="+dateType+"&tab="+VisitorDistribution_tab+"&tabOne="+VisitorDistribution_tabOne+"&device="+device
	}
	if(tab==1){
		window.location.href=server[0]._server_port+"/option/Pangolin_checkFlowShopData_preview_download?startDate="+startDate+"&dates="+download_date
		+"&endDate="+endDate
		+"&dateType="+dateType+"&belong="+belong+"&device="+device
	}
	if(tab==2){
		window.location.href=server[0]._server_port+"/option/Pangolin_checkproductSourceData_preview_download?startDate="+startDate+"&dates="+download_date
		+"&endDate="+endDate
		+"&dateType="+dateType+"&belong="+belong+"&device="+device+"&itemId="+$("#itemId").val()
	}
	if(tab==3){
		window.location.href=server[0]._server_port+"/option/Pangolin_checkshopPathData_preview_download?startDate="+startDate+"&dates="+download_date
		+"&tab="+tab_2
		+"&dateType="+dateType+"&belong="+belong+"&device="+device+"&deviceLogicType="+(device==1?1:device==2?20:device)
	}
	if(tab==4){
		window.location.href=server[0]._server_port+"/option/Pangolin_checkFlowDictionAssistantDrainageKeyword_preview_download?startDate="+startDate+"&dates="+download_date
		+"&tab="+tab_2
		+"&dateType="+dateType+"&device="+device
	}
})