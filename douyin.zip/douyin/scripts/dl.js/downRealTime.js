$.ajaxSetup({
	crossDomain : true,
	xhrFields : {
		withCredentials : true
	}
});

$(".marketBtn").click(function(){
	showTip()
	showData()
})
$(".reSearch").click(function(){
	$(".market2").hide();
	$(".market1").show();
})

document.addEventListener('DOMContentLoaded', function(){
	
});

$(document).ready(function() {
	
});
var tab=0;
function showTip(){
	$(".showCondition").html("")
	if(tab==0){
		$(".showCondition").append('<div>\
	              <b>一级类目:</b>\
	              <span>实时概况</span>\
	            </div>')
	            
	            $(".showCondition").append('<div>\
	              <b>时间:</b>\
	              <span>'+$(".dateBox").find("input")[0].value.trim()+" ~ "+$(".dateBox").find("input")[1].value.trim()+'</span>\
	            </div>')
	            
	}
	            
}

function showData(){
	page=1;
	Pangolin_realTime_survey_overview_preview();
}
var page=1;
var pageSize=10;
function Pangolin_realTime_survey_overview_preview() {
	$.ajax({
		type : 'post',
		data : {
			startDate : $(".dateBox").find("input")[0].value.trim(),
			endDate : $(".dateBox").find("input")[1].value.trim(),
			pageIndex : page,
			pageSize : 2 * pageSize
		},
		async : false,
		url : server[0]._server_port + (server[0].mappings)[72]._interface,
		success : function(value) {
			var data = {};
			if (Object.prototype.toString.call(value) == "[object String]") {
				data = JSON.parse(value);
			}
			if (Object.prototype.toString.call(value) == "[object Object]") {
				data = value;
			}

			$("#_date").html('')
			$("#_data").html('')
			if (data.status == 1) {
				if (data.data.length > 0) {
					$("#page").show()
					$("#page").paging(
							{
								pageNo : page,
								totalPage : Math.ceil(data.total[0].num
										/ (2 * pageSize)),
								totalSize : data.total[0].num,
								callback : function(value) {
									page = value;
									Pangolin_realTime_survey_overview_preview()
								}
							})

					$.each(data.data, function(index) {
						$("#_date").append(
								'<tr>\
                    <td>'
										+ this.dateTime
										+ '</td>\
                  </tr>');
						$("#_data").append(
								'<tr>\
	                    <td>' + this.uv
										+ '</td>\
	                    <td>'
										+ this.pv
										+ '</td>\
	                    <td>'
										+ this.payAmt
										+ '</td>\
	                    <td>'
										+ this.payOrderCnt
										+ '</td>\
	                    <td>'
										+ this.payBuyerCnt
										+ '</td>\
	                  </tr>');
					})
					$(".market1").hide();
					$(".market2").show();
				} else {
					$("#page").hide()
					$("#_data").append('<tr><td colspan="100">无数据！</td></tr>')
				}
			}
		}
	})
}


$("#downLoad").click(function(){
	startDate=$(".dateBox").find("input")[0].value.trim(),
	endDate=$(".dateBox").find("input")[1].value.trim(),
	window.location.href=server[0]._server_port+"/option/Pangolin_realTime_survey_overview_preview_download?startDate="+startDate
	+"&endDate="+endDate
})