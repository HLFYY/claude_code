window.onload = function () {

    document.querySelector("li.ant-pagination-next").click();
    console.log( document.querySelector("li.ant-pagination-next"));

}