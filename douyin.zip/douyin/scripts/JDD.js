
window.onload = function () {
    setTimeout(function () {

        var name = document.querySelector('.KrelmIr7') || document.querySelector('.OcCvtZ2a') || document.querySelector('.TVGQz3SI') || document.querySelector('.NtumbRDj');
        if (name) {
          var textContent = name.textContent || name.innerText; // 获取元素的文本内容
          var match = textContent.match(/抖音号：(.*?)$/); // 使用正则表达式匹配抖音号
          if (match && match[1]) {
            var nameid = match[1].trim(); // 提取并去除首尾空白字符
            console.log(nameid); // 输出结果
    
    
            chrome.runtime.sendMessage({
              type: 'nameid',
              nameid: nameid
            }, function (response) {
    
            });
    
          } else {
            console.log('未找到抖音号');
          }
        } else {
          console.log('元素未找到');
        }
    
    
      }, 3000); // 延迟1秒（1000毫秒）
	
	setTimeout(() => {
		window.location.reload()
	}, 300000);

}