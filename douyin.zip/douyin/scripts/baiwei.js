chrome.tabs.executeScript(chrome.devtools.tabId, {
    code: `console.clear();console.log("✅网页请求收集器已开启✅");`,
    });
    // chrome extension 中不能使用 console.log
    // 所以，需要通过发送请求给后台脚本的方式来打印日志
    const log = (...args) => chrome.extension.sendRequest({tabId: chrome.devtools.tabId, args,});
    
    chrome.devtools.network.onRequestFinished.addListener(
    function(request) {
    var data = {}
    data['method'] = request.request.method
    if(data['method'] == "POST"){
    data['postData'] = request.request.postData.params
    }else{
    data['postData'] = {}
    }
    data['url'] = request.request.url
    data['headers'] = request.request.headers
    data['queryString'] = request.request.queryString
    data['status'] = request.response.status
    data['mimeType'] = request.response.content.mimeType
    if(data['mimeType'] == "text/html" && data['status'] != 404){
    if(data['method'] == 'GET' && data['queryString'] == ''){
    
    }else{
    log(data['method'], data['status'], data['url'], data['mimeType'])
    var xhr = new XMLHttpRequest();
    xhr.open("post", "http://127.0.0.1/", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;");
    xhr.send(JSON.stringify(data));
    }
    }
    
    Object.keys(request).forEach(function(key){
    
    log(key,request[key]);
    });
    });