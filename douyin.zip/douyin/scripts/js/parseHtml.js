var targetExtensionId = "ohhobbhpcigpmafdahoidiagfmhkgfai";

//var targetExtensionId = "kmajmkmkhhpmjeifgielbniofkgalmmo";
//var targetExtensionId = "omngpalomokicigfegochhkfepgnadmm";

function choose(data,date){
	if (window.location.href.match("h5.m.taobao.com")) {
		chrome.runtime.sendMessage(targetExtensionId, {type: 'flow_configuration_page_picture',data:data,date:date}, function(response) {
			alert(response);
		});
    }
}
function eachhtml(){
	//var date=$(".calc-date",parent.document).text().split("：")[1];
	var date=getURLParameter('recodeDate',window.location.href);
	var data=[];
	var count=0;
	var boolean=true;
	$.each($('div[data-spm-module]'),function(index){
		if(!boolean)return ;
		let md=$(this).attr("data-spm-module");
		let ind=$(this).parent().attr("index");
		if(md.indexOf("shop_head") != -1||ind==0){
			let row={};
			row.name=md;
			row.pic="";
			data.push(row);
		}
		if(md.indexOf("banner_head") != -1||ind==1){
			$.each($(this).find('div[class*="childWrap"]'),function(count){
				//console.log($(this).attr("class")+">"+$(this).children(":first").attr('data-spmd')+">"+$(this).children(":first").children(":first").attr("title")+","+$(this).children(":first").find("img").attr("src"));
				let row={};
				row.name=$(this).children(":first").attr('data-spmd');
				if($(this).find('img').attr("src").match("data:image")){
					alert("检测到某些图片没有加载！请滑动检查一下！");
					boolean=false;
					return false;
				}
				row.pic=$(this).find('img').attr("src");
				row.name=$(this).find('img').parent().next().attr('data-spmd')
				data.push(row);
			})
		}
		if(md.indexOf("designer") != -1){
			$.each($(this).find('div[data-spmd]'),function(count){
				//console.log($(this).attr("class")+">"+$(this).children(":first").attr('data-spmd')+">"+$(this).children(":first").children(":first").attr("title")+","+$(this).children(":first").find("img").attr("src"));
				let row={};
				row.name=$(this).attr('data-spmd');
				if($(this).parent().find('img').attr("src").match("data:image")){
					alert("检测到某些图片没有加载！请滑动检查一下！");
					boolean=false;
					return false;
				}
				row.pic=$(this).parent().find('img').attr("src");
				data.push(row);
			})
		}
		count=index;
	})
	if(count==$('div[data-spm-module]').length-1){
		choose(data,date)
	}
}

function getURLParameter(name,url) { 
	var url=url.replace('?', "?a=a&");
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = url.substr(1).match(reg); 
    if (r != null) return decodeURI(r[2]); 
    return null; 
}

function bottomButton(){
	var ele = document.createElement('div');
	ele.className = 'chrome-plugin-simple-tip slideInLeft';
	ele.style.top = '0px';
	ele.style.left = '180px';
	ele.style.cursor='pointer'; 
	ele.style.zIndex  = 9999;
	ele.innerHTML = 'get';
	ele.onclick = eachhtml;
	document.body.appendChild(ele);
}

function flowButton(){
	var ele = document.createElement('div');
	ele.className = 'chrome-plugin-simple-tip slideInLeft btn_page';
	ele.style.top = '200px';
	ele.style.left = '380px';
	ele.style.cursor='pointer'; 
	ele.style.zIndex  = 9999;
	ele.innerHTML = 'get';
	ele.onclick = eachhtml;
	document.body.appendChild(ele);
}
/*var pboolean=true;
window.onload = function(){
	if (window.location.href.match("h5.m.taobao.com")) {
		bottomButton();
	}
	
}*/

setInterval(function(){
	if (window.location.href.match("h5.m.taobao.com")) {
		if($('.chrome-plugin-simple-tip').length==0){
			bottomButton();
		}
	}
	if (window.location.href.match("/flow/monitor/itemsource")) {
		if($('#tip_p')[0]==undefined){
			$(".oui-date-picker-current-date").after('<button type="button" class="ant-btn ant-btn-primary ant-btn-sm" onClick="supplementItemid()" id="verify"><span>补全</span></button><button type="button" class="ant-btn ant-btn-dashed ant-btn-sm"><span id="tip_p">剩余:--</span></button><input style="width: 100px;" placeholder="时间间隔秒" class="ant-input ant-input-sm" id="secondtime" onChange="resetInterval(this.value)" type="text" value="30"><input style="width: 100px;"  class="ant-input ant-input-sm" id="ly"  type="text" value="1">')
		}
	}
},100);