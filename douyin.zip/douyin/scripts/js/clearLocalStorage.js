var targetExtensionId = "kmajmkmkhhpmjeifgielbniofkgalmmo";
//var targetExtensionId = "omngpalomokicigfegochhkfepgnadmm";

var topangolin=function(){
	//将targetId发送给后台网页
	chrome.runtime.sendMessage(targetExtensionId, {type: 'login'}, function(response) {
		
		});
}
setInterval(function() {
	var storage = window.localStorage;
	//拿到本地存储
	for (var i = 0; i < storage.length; i++) {
		//如果本地存储中的key包含该字符，则清除
		console.log(storage.key(i));
		if (storage.key(i).match("//sycm.taobao.com/" || storage.key(i).match(".json?"))) {
			storage.removeItem(storage.key(i))
		}
		// if () {
		// 	storage.removeItem(storage.key(i))
		// }
	}
}, 20)
