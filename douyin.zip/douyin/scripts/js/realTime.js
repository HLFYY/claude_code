var targetExtensionId = "kmajmkmkhhpmjeifgielbniofkgalmmo";
//var targetExtensionId = "omngpalomokicigfegochhkfepgnadmm";

var url;
var url1;
setInterval(function(){
	url=window.location.href;
	if(url1!=url){
		choose()
	}
}, 20);
var init=0;
var min=60;
var keyWords;
var myVar;

function setTime(){
	if(sessionStorage.getItem("scfx_min")==null||sessionStorage.getItem("scfx_min")=="null"){
		min = window.prompt("请输入多长时间(分钟)抓取一次！","60");
		if(isNaN(min)){
			alert("请输入准确数字！");
			setTime()
			return ;
		}
		if(min==null){
			return;
		}
		sessionStorage.setItem("scfx_min", min);
	}
	min=sessionStorage.getItem("scfx_min");
	clearInterval(myVar);
	myVar=setInterval('GrabData()',parseInt(min)*100)
}

var login_Status=false;
function choose(){
	if (url.match("/mc/mq/search_analyze")) {url1=window.location.href;return ;
		chrome.runtime.sendMessage(targetExtensionId, {type: 'keyWords'}, function(response) {
			keyWords=response;
			setTime();
			});
    }
	if (url.match("/ipoll/index.htm")) {url1=window.location.href;
		setInterval(function() {
			/*if(undefined==$(".menuList .nameWrapper")[0])return;
			$(".menuList .nameWrapper")[0].click()*/
			if(null==$(".sub-title button"))return;
			$(".sub-title button").click();
		}, 10000)
	}
	if (url.match("/custom/login.htm")) {return ;
		url1 = window.location.href;
		setInterval(function() {
			location.reload();
		}, 7000)
	}
	
	if (url.match("/ipoll/itemmonitor.htm")) {
		url1 = window.location.href;
		setInterval(function() {
			timing();
		}, 2500);
		let t=15*60*1000;
		let m=Math.ceil(Math.random()*10)*60*1000;
		console.log(t+m);
		let timeMinute=t+m;
		setInterval(function() {
			if (getTarget(new Date().getHours()) && new Date().getMinutes()<4) {
				
			}else{
				location.reload();
			}
		}, timeMinute);
	
	}
	
	if (url.match("/brand/realTime/realTop.html")) {
		url1 = window.location.href;
		setInterval(function() {
			timingjd();
		}, 5000);
		let t=20*60*1000;
		let m=Math.ceil(Math.random()*10)*60*1000;
		console.log(t+m);
		let timeMinute=t+m;
		setInterval(function() {
			if (getTarget(new Date().getHours()) && new Date().getMinutes()<4) {
				
			}else{
				location.reload();
			}
		}, timeMinute);
	}
	
	if (url.match("/brand/realTime/realSummary.html")) {
		url1 = window.location.href;
		setInterval(function() {
			timingjdArea();
		}, 5000);
		let t=20*60*1000;
		let m=Math.ceil(Math.random()*10)*60*1000;
		console.log(t+m);
		let timeMinute=t+m;
		setInterval(function() {
			if (getTarget(new Date().getHours()) && new Date().getMinutes()<4) {
				
			}else{
				location.reload();
			}
		}, timeMinute);
	}
	
	if (url.match("/member/login.jhtml")) {return ;
		url1 = window.location.href;
		setTimeout(function(){
			if(sessionStorage.getItem("sycm_UserName")==null||sessionStorage.getItem("sycm_UserName")=="null"){
				if(confirm("是否设置掉线自动登录！")){
					login_Status=true;
					if(sessionStorage.getItem("sycm_UserName")==null||sessionStorage.getItem("sycm_UserName")=="null"){
						sycm_UserName = window.prompt("设置自动登录账户！","");
						if (sycm_UserName!=null && sycm_UserName!=""){ 
							sessionStorage.setItem("sycm_UserName",sycm_UserName);
						}
					}
					if(sessionStorage.getItem("sycm_UserPwd")==null||sessionStorage.getItem("sycm_UserPwd")=="null"){
						sycm_UserPwd = window.prompt("设置密码！","");
						if (sycm_UserPwd!=null && sycm_UserPwd!=""){ 
							sessionStorage.setItem("sycm_UserPwd",sycm_UserPwd);
						}
					}
				}
			}else{
				login_Status=true;
			}
		},20)
		
		setInterval(function() {
			/*if(!login_Status){
				return;
			}*/
			$("#app").click();
			$("#TPL_username_1").val(sessionStorage.getItem("sycm_UserName"));
			$("#TPL_password_1").val(sessionStorage.getItem("sycm_UserPwd"));
//			$("#TPL_username_1").val("万达广场888");
//			$("#TPL_password_1").val("qweqwe8625");
			/*var drag = document.getElementById('nc_1_n1z');
			darg(drag);
			$("#nc_1_n1z").mousedown();*/
//			$("#nc_1_n1z").attr("style","left: 206px;")
//			$("#nc_1__scale_text").parent().after('<script>$("#nc_1__scale_text").click()</script>');
			
//			event = document.createEvent('MouseEvents');
//			event.initEvent('mousedown', true, false);
//			document.querySelector("#nc_1_n1z").dispatchEvent(event);
//			event = document.createEvent('MouseEvents');
//			event.initEvent('mousemove', true, false);
//			Object.defineProperty(event,'clientX',{get(){return 260;}})
//			document.querySelector("#nc_1_n1z").dispatchEvent(event);
			
			$("#J_SubmitStatic").focus()
			$("#J_SubmitStatic").parent().after('<script>$("#J_SubmitStatic").click()</script>');
		}, 10000)
		
		setInterval(function() {
			event = document.createEvent('MouseEvents');
			event.initEvent('mousedown', true, false);
			document.querySelector("#nc_1_n1z").dispatchEvent(event);
			event = document.createEvent('MouseEvents');
			event.initEvent('mousemove', true, false);
			Object.defineProperty(event,'clientX',{get(){return 260;}})
			document.querySelector("#nc_1_n1z").dispatchEvent(event);
		}, 100)
	}
	
	
	if (url.match("/flow/monitor/itemsource")) {
		url1 = window.location.href;
		/*setTimeout(function() {
			$(".sycm-common-select-empty-board").click();
	        testss =$(".ant-input")[0];
	        fireKeyEvent1(testss, "input", 13,"536027498869");
	        $(".oui-typeahead-dropdown").children("div").get(0).click();
		}, 10000);*/
		
	}
	
}

function sleep(numberMillis) {
	var now = new Date(); 
	var exitTime = now.getTime() + numberMillis; 
	while (true) {
		now = new Date(); 
		if (now.getTime() > exitTime){
			BBoolean=true;
			return; 
		}
		
	} 
}
var prolist;
var count=0;
function queueObject(obj){
	let v=obj[0];
	obj.splice(0,1);
	return v;
}
var belong;
function supplementItemid(){
	$('#verify').attr("disabled","");
	if(!$(".oui-date-picker-particle-button button:eq(4)").hasClass('ant-btn-primary')){
		$("#tip_p").html('只针对日自动抓取！');
		$('#verify').removeAttr('disabled');
		return ;
	}
	if($($(".ant-select-selection-selected-value")[0]).text()=='无线端' || $($(".ant-select-selection-selected-value")[0]).text()=='PC端'){
		$("#tip_p").html('请先输入个商品到详情页！然后再点击补全！');
		$('#verify').removeAttr('disabled');
		return ;
	}
	belong=$($(".ant-select-selection-selected-value")[0]).text()=='每一次访问来源'?'all':$($(".ant-select-selection-selected-value")[0]).text()=='第一次访问来源'?'nearest':'farthest';
	//$(".sycm-common-select-selected-clear").click();
	//$(".oui-typeahead-del-icon").click();
	$("#tip_p").html('正在获取缺失ITEM....');
	chrome.runtime.sendMessage(targetExtensionId, {type: 'getproductList',date:$(".oui-date-picker-current-date").text().split(" ")[1],device:2,belong:belong}, function(response) {
		if(response==undefined){
			$("#tip_p").html('确保穿山甲账号登录！');
			return ;
		}
		if(response.data[0]==undefined){
			$("#tip_p").html('已补全！');
			$('#verify').removeAttr('disabled');
			return ;
		}
		if(response.data[0].status==undefined){
			prolist=response.data;
			getItemIdData(queueObject(prolist).itemId);
		}else{
//			$(".sycm-common-select-selected-clear").click();
//			$(".oui-typeahead-del-icon").click();
			$("#tip_p").html(response.data[0].msg);
			$('#verify').removeAttr('disabled');
			return ;
		}
		});
}
var interval_1=0;
var second=30;
function timingTool(c){
	if(c==1){
		if(prolist.length>-1 && interval_1==0){
			interval_1=setInterval(function() {
				$("#tip_p").html('剩余:'+prolist.length);
				if($(".oui-typeahead-dropdown").children("div").size()==1){
					if(BBoolean){
						$(".oui-typeahead-dropdown").children("div").get(0).click();
						BBoolean=false;
					}else{
						if(prolist.length==0){
							$('#verify').removeAttr('disabled');
							clearInterval(interval_1);
							interval_1=0;
						}else{
//							$(".sycm-common-select-selected-clear").click();
//							$(".oui-typeahead-del-icon").click();
							getItemIdData(queueObject(prolist).itemId);
						}
						BBoolean=true;
						//if($(".sycm-common-select-selected-board").size()==1){}
					}
				}else{
//					$(".sycm-common-select-selected-clear").click();
//					$(".oui-typeahead-del-icon").click();
					getItemIdData(queueObject(prolist).itemId);
				}
			}, second*1000/2);
		}
	}
}

function resetInterval(v){
	var reg = /^[0-9]*$/;
	if (!reg.test(v)) {
	$('#secondtime').val('');
	$('#secondtime').attr('placeholder','只能输入数字！')
	return ;
	}
	second=v;
	clearInterval(interval_1);
	interval_1=0;
	if(prolist==undefined){
		return ;
	}
	timingTool(1);
}
function getParams(str) {
	let url = str;
	let obj = {}
	let reg = /[?&][^?&]+=[^?&]+/g
	let arr = url.match(reg)
	// ['?id=12345','&a=b']
	if (arr) {
	arr.forEach((item) => {
	let tempArr = item.substr(1).split('=')
	let key = decodeURIComponent(tempArr[0])
	let val = decodeURIComponent(tempArr[1])
	obj[key] = val
	})
	}
	return obj
}

function cutaffiliation(){
	$(".oui-select-no-border").click();
	$(".ant-select-dropdown-menu-vertical li:eq(1)").click();
//	sleep(1000);
//	$(".oui-select-no-border").click();
//	$(".ant-select-dropdown-menu-vertical li:eq(2)").click();
	BBoolean=false;
}

var BBoolean=true;
function getItemIdData(id){
//	$(".alife-dt-card-sycm-common-select span:eq(0)").click();
//    testss =$(".ant-input-affix-wrapper input")[0];
//    fireKeyEvent1(testss, "input", 13,id);
//    timingTool(1);
	autoQuery(id);
	timingTool(1);
}

function autoQuery(id) {
	var evtObj = document.createEvent('UIEvents');
	evtObj.initUIEvent('input', true, true, window, 1);
	$(".alife-dt-card-sycm-common-select span:eq(0)").click();
	var ele = $(".ant-input-affix-wrapper input")[0]
	console.log(ele)
	ele.value = id;
	ele.dispatchEvent(evtObj);
	setTimeout(function() {
		$('.sycm-common-select-name')[0].click()
	}, 500)
}


function fireKeyEvent1(el, evtType, keyCode,itemid) {
	if(el==undefined){
		if(prolist.length>-1){
			//supplementItemid();
		}else{
			getItemIdData(queueObject(prolist).itemId);
		}
		
		return ;
	}
	el.focus();
	el.value=itemid;
    var evtObj;
    if (document.createEvent) {
        if (window.KeyEvent) {//firefox 浏览器下模拟事件
            evtObj = document.createEvent('KeyEvents');
            evtObj.initKeyEvent(evtType, true, true, window, true, false, false, false, keyCode, 0);
        } else {//chrome 浏览器下模拟事件
            evtObj = document.createEvent('UIEvents');
            evtObj.initUIEvent(evtType, true, true, window, 1);
            delete evtObj.keyCode;
            if (typeof evtObj.keyCode === "undefined") {//为了模拟keycode
                Object.defineProperty(evtObj, "value", {
                	value: '536027498869'
                });
                Object.defineProperty(evtObj, "key", {
                	value: '536027498869'
                });
            } else {
                evtObj.key = String.fromCharCode(keyCode);
            }

            if (typeof evtObj.ctrlKey === 'undefined') {//为了模拟ctrl键
                Object.defineProperty(evtObj, "ctrlKey", { value: true });
            } else {
                evtObj.ctrlKey = true;
            }
        }
        el.dispatchEvent(evtObj);
    } else if (document.createEventObject) {//IE 浏览器下模拟事件
        evtObj = document.createEventObject();
        evtObj.keyCode = keyCode
        el.fireEvent('on' + evtType, evtObj);
    }
}


function GrabData(){
	$.each(keyWords,function(){
	if(undefined==$(".op-mc-search-analyze-search-area").find("input")[0])return;
	$(".op-mc-search-analyze-search-area").find("input").val(this.keyword)
	$(".op-mc-search-analyze-search-area").find("input").attr("value", this.keyword)
	$(".op-mc-search-analyze-search-area").find("input").focus()
	fireKeyEvent($(".op-mc-search-analyze-search-area").find("input")[0], 'keydown', 13);  //第一个参数时html元素
	})
}

function fireKeyEvent(el, evtType, keyCode){  
    var doc = el.ownerDocument,  
        win = doc.defaultView || doc.parentWindow,  
        evtObj;  
    if(doc.createEvent){  
        if(win.KeyEvent) {  
            evtObj = doc.createEvent('KeyEvents');  
            evtObj.initKeyEvent( evtType, true, true, win, false, false, false, false, keyCode, 0 );  
        }  
        else {  
            evtObj = doc.createEvent('UIEvents');  
            Object.defineProperty(evtObj, 'keyCode', {  
                get : function() { return this.keyCodeVal; }  
            });       
            Object.defineProperty(evtObj, 'which', {  
                get : function() { return this.keyCodeVal; }  
            });  
            evtObj.initUIEvent( evtType, true, true, win, 1 );  
            evtObj.keyCodeVal = keyCode;  
            if (evtObj.keyCode !== keyCode) {  
                console.log("keyCode " + evtObj.keyCode + " 和 (" + evtObj.which + ") 不匹配");  
            }  
        }  
        el.dispatchEvent(evtObj);  
    }   
    else if(doc.createEventObject){  
        evtObj = doc.createEventObject();  
        evtObj.keyCode = keyCode;  
        el.fireEvent('on' + evtType, evtObj);  
    }  
}  
//var TIMES=[9,12,15,18,21,23];
var TIMES=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23];
function timing(){
	if (new Date().getHours()==23) {
		if (getTarget(new Date().getHours())) {
			if(50<new Date().getMinutes() && new Date().getMinutes()<60){
				if($(".ui-pagination-next").size()==0){
					location.reload();
				}else{
					$(".symbol-next").click();
				}
			}
		}
		if (getTarget(new Date().getHours())) {
			if(0<new Date().getMinutes() && new Date().getMinutes()<10){
				if($(".ui-pagination-next").size()==0){
					location.reload();
				}else{
					$(".symbol-next").click();
				}
			}
		}
	}else{
		if (getTarget(new Date().getHours())) {
			if(0<new Date().getMinutes() && new Date().getMinutes()<10){
				if($(".ui-pagination-next").size()==0){
					location.reload();
				}else{
					$(".symbol-next").click();
				}
			}
		}
	}
	
}

function timingjd(){
	if (new Date().getHours()==23) {
		if (getTarget(new Date().getHours())) {
			if(50<new Date().getMinutes() && new Date().getMinutes()<60){
				$($('.grace-common-switch span').get(1)).trigger("click")
				setTimeout(function(){
					location.reload();
				},60000);
			}
		}
		if (getTarget(new Date().getHours())) {
			if(0<new Date().getMinutes() && new Date().getMinutes()<10){
				$($('.grace-common-switch span').get(1)).trigger("click")
				setTimeout(function(){
					location.reload();
				},60000);
			}
		}
	}else{
		if (getTarget(new Date().getHours())) {
			if(0<new Date().getMinutes() && new Date().getMinutes()<10){
				$($('.grace-common-switch span').get(1)).trigger("click")
				setTimeout(function(){
					location.reload();
				},60000);
			}
		}
	}
}

function timingjdArea(){
	let starttime = new Date(Date.parse(new Date().getFullYear()+"-"+(new Date().getMonth()+1)+"-"+new Date().getDate()+" 23:30"));
	let endtime = new Date(Date.parse(new Date().getFullYear()+"-"+(new Date().getMonth()+1)+"-"+new Date().getDate()+" 23:59"));
	if(new Date()>=starttime && new Date()<=endtime){
		$($('.grace-common-switch span').get(1)).trigger("click")
		setTimeout(function(){
			location.reload();
		},60000);
	}
}


function getTarget(h) {
	try {
		let b=false;
		   $.each(TIMES,function(index){
			   if(TIMES[index]==h){
				   b=true;
			   }
		   })
		   return b;
	} catch (e) {
		location.reload();
	}
}


function darg(obj){
    //鼠标按下 
    obj.onmousedown = function(ev){

       //IE直接用event或者window.event得到事件本身,而在其他浏览器函数要获取到事件本身需要从函数中传入
    　　var oevent = ev || event;

    　　var distanceX = oevent.clientX - this.offsetLeft;
    　　var distanceY = oevent.clientY - this.offsetTop;

        //鼠标移动
    　　document.onmousemove = function(ev){
    　　　　var oevent = ev || event;
    　　　　obj.style.left = 206 + 'px';
    　　　　//obj.style.top = 1000 + 'px'; 
    　　};
        //鼠标放开
    　　document.onmouseup = function(){
    　　　　document.onmousemove = null;
    　　　　document.onmouseup = null;
    　　};
    };  
}