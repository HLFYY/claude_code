
window.onload = function () {
	
	setTimeout(() => {
		window.location.reload()
	}, 12000);

}