
function currentTime(){
  var date = new Date(new Date()-24*60*60*1000);
  var nextdate = new Date(new Date().getTime()+24*60*60*1000)
  date=format(date);
  nextdate=format(nextdate);
  $(".date,.week").val(date);
  $(".nextdate").val(nextdate);


  var date = new Date();
  var currentFirstDay=new Date(date.getFullYear(),date.getMonth()-1,1);
  currentFirstDay=format(currentFirstDay);
  $(".month:eq(0)").val(currentFirstDay);


  var nextMonthFirstDay=new Date(date.getFullYear(),date.getMonth(),1);
  var dis=nextMonthFirstDay.getTime()-24*60*60*1000;
  var lastDay=new Date(dis);
  lastDay=format(lastDay);
  $(".month:eq(1)").val(lastDay);

  var week=new Date();
  week=FirstDayOfWeek(week);
  $(".week:eq(0)").val(week);

  var week1=new Date();
  week1=LastDayOfWeek(week1);
  $(".week:eq(1)").val(week1);
}
currentTime();


function FirstDayOfWeek (date) {
    var weekday = date.getDay()||7; 
    date.setDate(date.getDate()-weekday+1-7);
    date=format(date);
    return date;
}

function LastDayOfWeek(date) {
    var weekday = date.getDay()||7; 
    date.setDate(date.getDate()+(7-weekday)-7);
    date=format(date);
    return date;
}


function format(obj){
	var year=obj.getFullYear();
	var month=obj.getMonth() + 1<10 ? "0" + (obj.getMonth() + 1) : obj.getMonth() + 1;
	var date=obj.getDate()<10 ? "0" + obj.getDate() : obj.getDate();
	return year+"-"+month+"-"+date;
}

function endtime(){
  var endtime= new Date(new Date()-24*60*60*1000);
  endtime=format(endtime);
  return endtime;
  alert(endtime);
}


function init_daterangepicker_single_day() {
	$('.date').each(function(){
		var obj = $(this);
		$(obj).datetimepicker({
            language:'zh-CN',
            format: 'yyyy-mm-dd',
            startView: 2, 
            minView: 2,
            maxView:2,
            pickerPosition:"bottom-left",
            endDate:new Date(new Date()-24*60*60*1000),
        });
        $('.date').on('changeDate', function(ev){
          $(".datetimepicker").hide();
          var starttime=$(".date:eq(0)").val();
          $(".date:eq(1)").datetimepicker('setStartDate',starttime);
          
        });
	})
}
init_daterangepicker_single_day();


function init_daterangepicker_single_nextday() {
  $('.nextdate').each(function(){
    var obj = $(this);
    $(obj).datetimepicker({
            language:'zh-CN',
            format: 'yyyy-mm-dd',
            startView: 2, 
            minView: 2, 
            maxView:2,
            pickerPosition:"bottom-left",
            endDate:new Date(new Date().getTime()+24*60*60*1000),
        });
        $('.nextdate').on('changeDate', function(ev){
          $(".datetimepicker").hide();
          var starttime=$(".nextdate:eq(0)").val();
          $(".nextdate:eq(1)").datetimepicker('setStartDate',starttime);
          
        });
  })
}
init_daterangepicker_single_nextday();

function init_daterangepicker_single_week() {
	$('.week').each(function(){
		var obj = $(this);
		$(obj).datetimepicker({
            language:'zh-CN',
            format: 'yyyy-mm-dd',
            startView: 2,
            minView: 2, 
            maxView:2,
            pickerPosition:"bottom-left",
            endDate:new Date(new Date()-24*60*60*1000),
        });
        
	})
}
init_daterangepicker_single_week();


function getFirstDayOfWeek (date) {
    var weekday = date.getDay()||7; 
    date.setDate(date.getDate()-weekday+1);
    date=format(date);
    return date;
}

function getLastDayOfWeek(date) {
    var weekday = date.getDay()||7; 
    date.setDate(date.getDate()+(7-weekday));
    date=format(date);
    return date;
}

$('.week:eq(0)').on('changeDate', function(ev){
	$(".datetimepicker").hide();
	ev=getFirstDayOfWeek (ev.date);
	$(this).datetimepicker("update",ev);
	var starttime=$(".week:eq(0)").val();
    $(".week:eq(1)").datetimepicker('setStartDate',starttime);
    
          
});
$('.week:eq(1)').on('changeDate', function(ev){
	$(".datetimepicker").hide();
	ev=getLastDayOfWeek (ev.date);
	$(this).datetimepicker("update",ev);
	var endtime=$(".week:eq(1)").val();
  $(".week:eq(0)").datetimepicker('setEndDate',endtime);
	
});


function init_daterangepicker_single_month() {
	$('.month').each(function(){
		var obj = $(this);
		$(obj).datetimepicker({
            language:'zh-CN',
            format: 'yyyy-mm-dd',
            startView: 3, 
            minView: 3, 
            maxView:3,
            pickerPosition:"bottom-left",
            endDate:new Date(new Date().getFullYear(),new Date().getMonth()-1),
        });
        
	})
}
init_daterangepicker_single_month();
$('.month:eq(0)').on('changeDate', function(ev){
          $(".datetimepicker").hide();
          var starttime=$(".month:eq(0)").val();
          $(".month:eq(1)").datetimepicker('setStartDate',starttime);
          
});
$('.month:eq(1)').on('changeDate', function(ev){
          $(".datetimepicker").hide();
          ev=format(ev.date);
          var year=ev.slice(0,4);
          var month=ev.slice(5,7);
          ev=getMonthFirstLastDay(year,month);
          $(this).datetimepicker("update",ev);
          var endtime=$(".month:eq(1)").val();
    		$(".month:eq(0)").datetimepicker('setEndDate',endtime);

          
});

function getMonthFirstLastDay(year,month){
    var firstDay=new Date(year,month-1,1);
    var currentMonth=firstDay.getMonth();
    var nextMonthFirstDay=new Date(firstDay.getFullYear(),currentMonth+1,1);
    var dis=nextMonthFirstDay.getTime()-24*60*60*1000;
    var lastDay=new Date(dis);
    console.log(firstDay,lastDay);
    firstDay=format(firstDay);
    lastDay=format(lastDay)
    return lastDay;
}
	

