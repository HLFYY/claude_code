﻿var server = [{
  _server_port: "http://221.228.94.26:9999",
  //_server_port:"http://221.228.94.29:9999",
  //_server_port:"https://jkc.ckgjx.cn",
  //_server_port:"http://180.97.75.232:8888",
  mappings: [
    { index: 0, _interface: "/direct/getVersion", desc: "" },
    { index: 1, _interface: "/direct/download", desc: "" },
    { index: 2, _interface: "/login", desc: "" },
    { index: 3, _interface: "/user/checkLogin", desc: "" },
    { index: 4, _interface: "/user/checkShop", desc: "" },
  ],
  mappingsjd: [

  ]
}];

function getServer () {
  return server;
}


console.log(11111111)

var TARGETS = [

  { index: 21, url: '/webcast/web/feed/follow/', desc: 'add' },
  { index: 22, url: 'user/following/list', desc: 'add' },
  { index: 23, url: '/live/promotions/pop/v3/', desc: 'add' }


];

var TARGETSJD = [

];

const _JS = [

];
function injectCustomJs (url) {
  for (var i in _JS) {
    var target = _JS[i];
    if (url.match(target.url)) {
      return target;
    }
  }
}


var shop_data = "";
var token = "";
var user = {};
var ExtensionInfo = {};

$.ajaxSetup({ crossDomain: true, xhrFields: { withCredentials: true } });


//返回所有已安装的扩展
chrome.management.getAll(function (ExInfo) {
  $.each(ExInfo, function (index) {
    if (this.id == "ifodlkghjnbmpppnfkpejoghipajmbfi") {
      //if(this.id=="omngpalomokicigfegochhkfepgnadmm"){
      ExtensionInfo = ExInfo[index];
    }
  })
})
var nameid = ''
//消息的监听
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {

  if (request.type === 'nameid') {
    nameid = request.nameid;
    localStorage.setItem('nameid', nameid)
    console.log(nameid)
  }

});

function getService (request) {
  if (request.data.servicename == "shuaxinshopinfo") {
    tmall_loginName = request.data.shopInfo.split('-')[0] + ',' + request.data.shopInfo.split(request.data.shopInfo.split('-')[0] + '-')[1];
    return { "data": "刷新成功", "type": "shuaxinshopinfo", "status": "1" };
  }

  let resultdata;
  $.ajax({
    type: 'POST',
    url: server[0]._server_port + '/data/' + (request.data.servicename == undefined ? "service" : request.data.servicename),
    data: request.data,
    async: false,
    success: function (value) {
      console.log(value);
      alert(value.data.msg)
      // if(value.isWhole == true)
      // {
      // 	alert("已经抓取完")
      // 	// chrome.runtime.onMessage.addListener(
      // 	// 	function (request, sendResponse) {
      // 	// 		if (request.greeting == "nihao")
      // 	// 			sendResponse({ over: value.isWhole });
      // 	// 	});
      // }else{
      // 	alert("未抓完"+ value.data[0].skuId  )


      // }
      var data = {};
      if (Object.prototype.toString.call(value) == "[object String]") {
        data = JSON.parse(value);
      }
      if (Object.prototype.toString.call(value) == "[object Object]") {
        data = value;
      }
      if (data.status == 1) {
        resultdata = data;
      }
    }
  })
  return resultdata;
}

function getAllSKUIntegrity (date) {
  let resultdata;
  $.ajax({
    type: 'POST',
    url: server[0]._server_port + '/flagship/getAllSKUIntegrity',
    data: { date: date },
    async: false,
    success: function (value) {
      var data = {};
      if (Object.prototype.toString.call(value) == "[object String]") {
        data = JSON.parse(value);
      }
      if (Object.prototype.toString.call(value) == "[object Object]") {
        data = value;
      }
      if (data.status == 1) {
        resultdata = data.data;
      }
    }
  })
  return resultdata;
}

function getAllSKU (date) {
  let resultdata;
  $.ajax({
    type: 'POST',
    url: server[0]._server_port + '/flagship/getAllSKU',
    data: { date: date },
    async: false,
    success: function (value) {
      var data = {};
      if (Object.prototype.toString.call(value) == "[object String]") {
        data = JSON.parse(value);
      }
      if (Object.prototype.toString.call(value) == "[object Object]") {
        data = value;
      }
      if (data.status == 1) {
        resultdata = data.data;
      }
    }
  })
  return resultdata;
}

function getCurrentTabId (callback) {
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    if (callback) callback(tabs.length ? tabs[0].id : null);
  });
}

function getURLParameter (name, url) {
  var url = url.replace('?', "?a=a&");
  var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
  var r = url.substr(1).match(reg);
  if (r != null) return decodeURI(r[2]);
  return null;
}

var gAttached = false;
var gRequests = [];
var gObjects = [];

var _source = [];
var loginUserName = "";
var loginUserNameJD = "";
var loginUserNameJD_1 = "";
var tmall_loginName = "";

var matchName = ""


//把地址存到gObjects
chrome.debugger.onEvent.addListener(function (source, method, params) {

  _source = source;
  if (method == "Network.requestWillBeSent") {
    var rUrl = params.request.url;
    if (getTarget(rUrl) >= 0) {
      gRequests.push(rUrl);
    }

    if (getTargetJD(rUrl) >= 0) {
      gRequests.push(rUrl);
    }
  }
  if (method == "Network.responseReceived") {
    var eUrl = params.response.url;
    var target = getTarget(eUrl);
    if (target >= 0) {
      gObjects.push({
        requestId: params.requestId,
        target: target,
        url: eUrl
      });
    }

    var target = getTargetJD(eUrl);
    if (target >= 0) {
      gObjects.push({
        requestId: params.requestId,
        target: target,
        url: eUrl
      });
    }

  }
  if (method == "Network.loadingFinished" && gObjects.length > 0) {
    var requestId = params.requestId;
    var object = null;
    var targetObject = null;
    for (var o in gObjects) {
      if (requestId == gObjects[o].requestId) {
        targetObject = gObjects[o];
        object = gObjects.splice(o, 1)[0];
        break;
      }
    }
    if (object == null) {
      console.log('Failed!!');
      return;
    }
    gRequests.splice(gRequests.indexOf(object.url), 1);
    //将指定命令发送至调试目标
    chrome.debugger.sendCommand(
      source,
      "Network.getResponseBody",
      { "requestId": requestId },
      function (response) {
        if (response) {
          var data = getTargetObj(targetObject.url);
          console.log(data);
          if (data != undefined) {


            if (data.index == 21) {


              let parsedResponse = JSON.parse(response.body);


              // 获取 room 数据
              let roomData = parsedResponse.data.data.map(item => {
                return {
                  name: item.room.owner.nickname,
                  id: item.room.owner.id_str,
                  room_id: item.room.id_str,
                  sec_uid: item.room.owner.sec_uid,
                };
              });
              console.log('直播中列表', roomData);
              setTimeout(function () {
                LiveList(roomData)
              }, 4000)

            }

            if (data.index == 22) {

              let parsedResponse = JSON.parse(response.body);

              // 获取 room 数据
              let roomData = parsedResponse.followings.map(item => {
                return {
                  name: item.nickname,
                  id: item.uid,
                  sec_uid: item.sec_uid,
                };
              });
              console.log('关注列表', roomData);
              setTimeout(function () {
                InterestList(roomData)
              }, 4000)

            }


          }

          var dataJD = getTargetObjJD(targetObject.url);
          if (dataJD != undefined) {




          }

          //_i();
        } else {
          console.log("Empty response for " + object.url);
        }

        if (gRequests.length == 0) {
          return false;

          chrome.debugger.detach({
            tabId: source.tabId
          }, function () {
            chrome.debugger.attach({
              tabId: source.tabId
            }, "1.0", function () {
              chrome.debugger.sendCommand({
                tabId: source.tabId
              }, "Network.enable");
            });
          });
        }
      });
  }
}
);

var initialListener = function (details) {
  if (gAttached) return;
  var tabId = details.tabId;

  if (tabId > 0) {
    gAttached = true;
    chrome.debugger.attach({
      tabId: tabId
    }, "1.0", function () {
      chrome.debugger.sendCommand({
        tabId: tabId
      }, "Network.enable");
    });
    chrome.webRequest.onBeforeRequest.removeListener(initialListener);
  }
};

function _i () {
  $.ajax({
    type: 'POST',
    url: server[0]._server_port + '/option/datainterface',
    success: function (value) {
      var data = {};
      if (Object.prototype.toString.call(value) == "[object String]") {
        data = JSON.parse(value);
      }
      if (Object.prototype.toString.call(value) == "[object Object]") {
        data = value;
      }
      if (data.status == 1) {
        server[0].mappings = data.data
      }
    }
  })
}

function _ijd () {
  $.ajax({
    type: 'POST',
    url: server[0]._server_port + '/option/datainterfacejd',
    success: function (value) {
      var data = {};
      if (Object.prototype.toString.call(value) == "[object String]") {
        data = JSON.parse(value);
      }
      if (Object.prototype.toString.call(value) == "[object Object]") {
        data = value;
      }
      if (data.status == 1) {
        server[0].mappingsjd = data.data
      }
    }
  })
}

function _tburl () {
  $.ajax({
    type: 'POST',
    url: server[0]._server_port + '/option/filtertburl',
    success: function (value) {
      var data = {};
      if (Object.prototype.toString.call(value) == "[object String]") {
        data = JSON.parse(value);
      }
      if (Object.prototype.toString.call(value) == "[object Object]") {
        data = value;
      }
      if (data.status == 1) {
        //TARGETS=data.data
      }
    }
  })
}

function _jdurl () {
  $.ajax({
    type: 'POST',
    url: server[0]._server_port + '/option/filterjdurl',
    success: function (value) {
      var data = {};
      if (Object.prototype.toString.call(value) == "[object String]") {
        data = JSON.parse(value);
      }
      if (Object.prototype.toString.call(value) == "[object Object]") {
        data = value;
      }
      if (data.status == 1) {
        //TARGETSJD=data.data
      }
    }
  })
}

function _m (v) {
  $.ajax({
    type: 'POST',
    url: server[0]._server_port + '/option/getModule',
    async: false,
    success: function (value) {
      var data = {};
      if (Object.prototype.toString.call(value) == "[object String]") {
        data = JSON.parse(value);
      }
      if (Object.prototype.toString.call(value) == "[object Object]") {
        data = value;
      }
      if (data.status == 1) {
        return data.data;
      }
    },
    error: function (data) {

    }

  })
}

function startDebugger () {
  chrome.debugger.getTargets(function (e) {
    chrome.tabs.getAllInWindow(null, function (detail) {
      $.each(detail, function () {
        var id = this.id;
        var url = this.url;
        var boolean = true;
        if (url.match("sycm.taobao.com") || url.match("jd.com") || url.match("tmall.com") || url.match("douyin.com")) {
          $.each(e, function () {
            if (id == this.tabId && !this.attached) {

              chrome.debugger.attach({
                tabId: id
              }, "1.0", function () {
                chrome.debugger.sendCommand({
                  tabId: id
                }, "Network.enable");
              });

            }
          })
        }
      })
    })
  })

}



function onAttach (t) {
  chrome.debugger.sendCommand({
    tabId: t
  }, "Network.enable")
}

$("#xianshi1").click(function () {
  debuggerController(true)
})
function debuggerController (t) {
  chrome.debugger.getTargets(function (e) { console.log(JSON.stringify(e)) })
}


function getTarget (url) {
  for (var i in TARGETS) {
    var target = TARGETS[i];
    if (url.match(target.url)) {
      return i;
    }
  }
  return -1;
}

function getTargetJD (url) {
  for (var i in TARGETSJD) {
    var targetJD = TARGETSJD[i];
    if (url.match(targetJD.url)) {
      return i;
    }
  }
  return -1;
}

function getTargetObj (url) {
  for (var i in TARGETS) {
    var target = TARGETS[i];
    if (url.match(target.url)) {
      return target;
    }
  }
}

function getTargetObjJD (url) {
  for (var i in TARGETSJD) {
    var targetJD = TARGETSJD[i];
    if (url.match(targetJD.url)) {
      return targetJD;
    }
  }
}




function douyinGZ (val, url) {
  let list = {
    'response': val,
    'url': url
  }
  console.log(list)
  $.ajax({
    type: "post",
    data: list,
    url: 'http://crawler.ectanger.com/dy_openliveid_cache_20220719',
    success: function (value) {
      console.log(value)
    }
  })
}











chrome.tabs.onCreated.addListener(function (tab) {
  startDebugger()
});
chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  startDebugger()
});



function getQQ (count) {
  var qq = "";
  $.each(count, function () {
    qq = qq + Math.random() * 10;
  })
  return qq;
}

function generateMixed (n) {
  var chars = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
  var res = "";
  for (var i = 0; i < n; i++) {
    var id = Math.ceil(Math.random() * 35);
    res += chars[id];
  }
  return res;
}




function LiveList (roomData) {
  var data = {
    acc: nameid,
    "action": "living",
    raw_data: roomData,
  };
  console.log(data);

  $.ajax({
    type: 'post',
    url: 'http://openapi.ectanger.com/qdlp/dy_live',
    contentType: 'application/json',
    data: JSON.stringify(data),
    dataType: 'json',
    success: function (data) {
      console.log(data);
      setTimeout(() => {
        window.location.reload()
      }, 5000);
    }
  });

}



function InterestList (roomData) {

  var data = {
    acc: localStorage.getItem('nameid'),
    "action": "follow",
    raw_data: roomData,
  };
  $.ajax({
    type: 'post',
    url: 'http://openapi.ectanger.com/qdlp/dy_live',
    contentType: 'application/json',
    data: JSON.stringify(data),
    dataType: 'json',
    success: function (data) {
      console.log(data);
    }
  });
}





setTimeout(() => {
  window.location.reload()
}, 306000);











chrome.runtime.onMessageExternal.addListener(function (request, sender, sendResponse) {
  if (request.type == 'keyWords') {
    if (localStorage.keyWords == null) {
      $.ajax({
        type: 'get',
        async: false,
        url: server[0]._server_port + (server[0].mappings)[25]._interface,
        success: function (value) {
          var data = {};
          if (Object.prototype.toString.call(value) == "[object String]") {
            data = JSON.parse(value);
          }
          if (Object.prototype.toString.call(value) == "[object Object]") {
            data = value;
          }
          if (data.status == 1) {
            localStorage.setItem("keyWords", JSON.stringify(data.data));
            sendResponse(data.data);
          }
        }
      })
    } else {
      sendResponse(JSON.parse(localStorage.keyWords));
    }
  }

  if (request.type == "login") {
    window.open("../html/popupl")
  }

  if (request.type == "flow_configuration_page_picture") {
    //alert(JSON.stringify(request.data));
    $.ajax({
      type: 'post',
      async: false,
      data: {
        data: JSON.stringify(request.data),
        mainUserName: JSON.parse(JSON.parse(localStorage.tab_loginInfo)).data.loginUserName,
        startDate: request.date
      },
      url: server[0]._server_port + "/storage/flow_configuration_page_picture",
      success: function (value) {
        var data = {};
        if (Object.prototype.toString.call(value) == "[object String]") {
          data = JSON.parse(value);
        }
        if (Object.prototype.toString.call(value) == "[object Object]") {
          data = value;
        }
        if (data.status == 1) {
          sendResponse("success!");
        }
      }
    })

  }

  if (request.type == "getproductList") {
    //alert(JSON.stringify(request.data));
    $.ajax({
      type: 'post',
      async: false,
      data: {
        device: request.device,
        mainUserName: JSON.parse(JSON.parse(localStorage.tab_loginInfo)).data.loginUserName,
        startDate: request.date,
        belong: request.belong
      },
      url: server[0]._server_port + "/flagship/store/getProductList",
      success: function (value) {
        var data = {};
        if (Object.prototype.toString.call(value) == "[object String]") {
          data = JSON.parse(value);
        }
        if (Object.prototype.toString.call(value) == "[object Object]") {
          data = value;
        }
        if (data.status == 1) {
          sendResponse(value);
        }
      }
    })

  }
});
var _cpu, _storage, _display;
function sysinfo () {
  chrome.system.cpu.getInfo(function (info) {
    _cpu = info;
  });
  chrome.system.storage.getInfo(function (info) {
    _storage = info;
  });
  chrome.system.display.getInfo(function (info) {
    _display = info;
  });
}

function getSystemInfo () {
  return _storage[0].id + '-' + _display[0].id;
}
// setInterval(function () {
// 	location.reload();
// }, 60 * 60 * 1000);



chrome.webRequest.onBeforeRequest.addListener(initialListener, { urls: ["*://*.douyin.com/*"] }, ["blocking"]);
$(document).ready(function () {
  startDebugger();
  sysinfo()
  //	_i();
  //	_ijd();
  //	_jdurl();
  //	_tburl();
})





