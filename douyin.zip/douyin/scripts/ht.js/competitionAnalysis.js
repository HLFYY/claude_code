$.ajaxSetup({
	crossDomain : true,
	xhrFields : {
		withCredentials : true
	}
});

var tab=0;
$(".tabTitle>span").click(function(){
	tab=$(this).index()
	if(tab==1){
		$(".tabTitleBtn").parent().show(200);
		$("#seller").parent().show(200)
	}else{
		$(".tabTitleBtn").parent().hide(200);
		$("#seller").parent().hide(200)
	}
	
	if(tab==0){
		$("#device").html('')
		$("#device").append('<option value="0">所有终端</option>\
            <option value="1">pc端</option>\
            <option value="2">无线端</option>')
	}else{
		$("#device").html('')
		$("#device").append('<option value="1">pc端</option>\
            <option value="2">无线端</option>')
	}
	$(this).addClass("active").siblings().removeClass("active");
	showData()
})

var tab2=0;
$(".tabTitleBtn>span").click(function(){
	tab2=$(this).index()
	$(this).addClass("active").siblings().removeClass("active")
	showData()
})
$(".dateBox").change(function(){
	showData()
})
$("#device,#seller").change(function(){
	showData()
})

var dataSelect=0;
$(".dataSelect>span").click(function(){
    var index=$(this).index();
    dataSelect=index;
    $(this).addClass("active").siblings("span").removeClass("active");
    showData()
});

$("#itemId").change(function(){
	showData()
})
var dateType = 'day';
$(document).ready(function() {
	
});

var c1=c2=c3=0;
function showData(){c1=c2=c3=0;
	checkData()
	$("tr").on("click", "td", function() {
		if($(this).text()=="作废"){
			remove($(this).parent().find("td:first").text())
		}
	});
}
function remove(date){
	if(!confirm("是否要作废？")){
		return;
	}
	$.ajax({
			type:'post',
			url:server[0]._server_port+"/option/Pangolin_compete_competitorAnalysis_delete.htm",
			data:{
				startDate:date.split("~")[0],
				endDate:date.split("~")[1],
				dateType:dateType,
				tab:tab,
				tabOne:tab2,
				device:$("#device").val(),
				seller:$("#seller").val(),
				itemId:$("#itemId").val(),
				topType:tab2==0?"flow":"trade",
				cateId:"",
			},
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==-2){
					alert(data.msg);
				}
				if(data.status==-1){
					alert(data.msg);
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
				}
				if(data.status==2){}
				if(data.status==3){
					alert(data.msg);
				}
				if(data.status==1){
					showData()
				}
			}
			})
	
}


function checkData(){
	if($("#itemId").val()==""){
		return ;
	}
	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	$("#_table tbody").html("")
	for(var i=0;i<=count;i++){
		$("#_table tbody").append('<tr id="_table_'+addDate(startDate, i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				tab:tab,
				tabOne:tab2,
				device:$("#device").val(),
				seller:$("#seller").val(),
				itemId:$("#itemId").val(),
				topType:tab2==0?"flow":"trade",
				cateId:"",
			},
			url:server[0]._server_port+(server[0].mappings)[75]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status!=1)return ;
				if(data.data[0].status==1){
					c1++
					
				}
				$("#_span2").text(c1)
				if(data.data[0].status==2){
					c2++
					
				}
				$("#_span3").text(c2)
				if(data.data[0].status==3){
					c3++
					
				}
				$("#_span4").text(c3)
				$("#_span1").text(c1+c2+c3)
				if(data.status==1 && dataSelect==0){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#_table_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#_table_"+this.startDate).append('<td>'+this.startDate+'</td><td><img src="https:'+(data.item.picurl==undefined?data.item.picturl:data.item.picurl)+'" alt=""></td><td><div class="productName">'+(data.item.name==undefined?data.item.title:data.item.name)+'</div></td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#_table_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#_table_"+this.startDate).append('<td>'+this.startDate+'</td><td><img src="https:'+(data.item.picurl==undefined?data.item.picturl:data.item.picurl)+'" alt=""></td><td><div class="productName">'+(data.item.name==undefined?data.item.title:data.item.name)+'</div></td> <td class="state">无数据(可能该天无数据产生)</td> <td class="readData"><a href="https://sycm.taobao.com/mc/ci/item/analysis" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#_table_"+this.startDate).remove();
					})
					if(status==2){
						$("#_table_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#_table_"+startDate).append('<td>'+startDate+'</td><td><img src="https:'+(data.item.picurl==undefined?data.item.picturl:data.item.picurl)+'" alt=""></td><td><div class="productName">'+(data.item.name==undefined?data.item.title:data.item.name)+'</div></td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/ci/item/analysis" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#_table_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#_table_"+this.startDate).append('<td>'+this.startDate+'</td><td><img src="https:'+(data.item.picurl==undefined?data.item.picturl:data.item.picurl)+'" alt=""></td><td><div class="productName">'+(data.item.name==undefined?data.item.title:data.item.name)+'</div></td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#_table_"+this.startDate).remove();
					})
				}
				
				if(data.status==1 && dataSelect==2){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#_table_"+this.startDate).remove();
					})
					if(status==2){
						$("#_table_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#_table_"+startDate).append('<td>'+startDate+'</td> <td><img src="https:'+(data.item.picurl==undefined?data.item.picturl:data.item.picurl)+'" alt=""></td><td><div class="productName">'+(data.item.name==undefined?data.item.title:data.item.name)+'</div></td><td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/ci/item/analysis" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#_table_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#_table_"+this.startDate).append('<td>'+this.startDate+'</td><td><img src="https:'+(data.item.picurl==undefined?data.item.picturl:data.item.picurl)+'" alt=""></td><td><div class="productName">'+(data.item.name==undefined?data.item.title:data.item.name)+'</div></td> <td class="state">无数据(可能该天无数据产生)</td> <td class="readData"><a href="https://sycm.taobao.com/mc/ci/item/analysis" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#_table_"+this.startDate).remove();
					})

				}
			}
		})
	}
}


function addDate(date, days) {
    var date = new Date(date);
    date.setDate(date.getDate() + days);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return date.getFullYear() + '-' + getFormatDate(month) + '-' + getFormatDate(day);
}

function getFormatDate(arg) {
    if (arg == undefined || arg == '') {
        return '';
    }
    var re = arg + '';
    if (re.length < 2) {
        re = '0' + re;
    }
    return re;
}


function getIntervalMonth(startDate,endStart){
    var startMonth = startDate.getMonth();
    var endMonth = endStart.getMonth();
    var intervalMonth = (endStart.getFullYear()*12+endMonth) - (startDate.getFullYear()*12+startMonth);
    return intervalMonth;
}
function getMonth(startDate,i){
	var year=parseInt(startDate.split('-')[0]);
	var month=parseInt(startDate.split('-')[1]);
	if(month+i>12){
		var count=	parseInt((month+i)/12)
		month=(month+i)-12*count;
		if(month==0){
			year=year+count-1;
			month=12;
			return year+"-"+month+"-01"
		}else{
			year=year+count;
			return year+"-"+(month>9?month:"0"+month)+"-01";
		}
		
	}else{
		month=month+i
		return year+"-"+(month>9?month:"0"+month)+"-01";
	}
}