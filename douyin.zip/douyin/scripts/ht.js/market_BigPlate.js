var backgroundPage = chrome.extension.getBackgroundPage();
var server=backgroundPage.getServer();
$.ajaxSetup({crossDomain: true, xhrFields: {withCredentials: true}});
var header_tabId=0;
$(".ul1").on("click", "li", function() {
	header_tabId=$(this).index()
	$(this).siblings().removeClass("active");
	$(this).addClass("active");
	if($(this).text()=="下载"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/downLoad.html')});
	}else if($(this).text()=="市场"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/market_BigPlate.html')});
	}else if($(this).text()=="取数"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/options.html')});
	}
});
function init_date_div(){
	if(dateType=="day"){
		$(".monthBox").hide();
		$(".weekBox").hide();
		$(".dateBox").show();
	}
	if(dateType=="week"){
		$(".monthBox").hide();
		$(".weekBox").show();
		$(".dateBox").hide();
	}
	if(dateType=="month"){
		$(".monthBox").show();
		$(".weekBox").hide();
		$(".dateBox").hide();
	}
}
var dateType='day';
$(".selectTime>span").click(function(){
    var index=$(this).index();
    $(this).addClass("on").siblings("span").removeClass("on");
    if($(this).text()=="按日")dateType='day' 
    if($(this).text()=="按周")dateType='week' 
    if($(this).text()=="按月")dateType='month' 
    init_date_div();
    showData();
});

function addDate(date, days) {

    var date = new Date(date);
    date.setDate(date.getDate() + days);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return date.getFullYear() + '-' + getFormatDate(month) + '-' + getFormatDate(day);
}
function getFormatDate(arg) {
    if (arg == undefined || arg == '') {
        return '';
    }

    var re = arg + '';
    if (re.length < 2) {
        re = '0' + re;
    }

    return re;
}


$(document).ready(function(){
	init_top_category();
	init_date_div()
});

function init_top_category(){
	$.ajax({
		type:"post",
		xhrFields:{withCredentials:true},
		url:server[0]._server_port+(server[0].mappings)[17]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$.each(data.data,function(index){
					if(index==0){
						category_id=this.cid
						$(".selectCategory>span").text(this.name);
					}
				$(".category1").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
			})
			}
		}
	})
}
$(".selectCategory").on("mouseover", "li", function() {
	var obj=$(this);
	var name=$(this).text();
	var cg=$(this).parent().attr('class');
	$.ajax({
		type:"post",
		data:{categoryId:$(this).attr("value")},
		url:server[0]._server_port+(server[0].mappings)[15]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				if(data.data.length>0){
					obj.html("");
					obj.append('<span title="'+name+'">'+name+'</span><i class="iconfont icon-youjiantou pull-right"></i>');
				}
				if(cg=="category1"){
					$(".category2").html("")
					$.each(data.data,function(index){
						$(".category2").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
					})
				}
				if(cg=="category2"){
					$(".category3").html("")
					$.each(data.data,function(index){
						$(".category3").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
					})
				}
			}
		}
	})
});
$("#date_day_1").change(function(){
	showData()
})
$(".weekBox").change(function(){
	showData()
})
$(".monthBox").change(function(){
	showData()
})
$(".selectCategory>span").click(function(e){
	$(".selectCategory>div").show(500);
	e.stopPropagation();
    $(document,".fa-times").click(function(){
      $(".selectCategory>div").hide(500);
    })
})
var category_id='';
$("#categoryDiv").on("mouseup", "li", function() {
	$(".selectCategory>div").hide(500);
	category_id=$(this).attr("value");
	$(".selectCategory>span").text($(this).text());
	$(this).addClass("active").siblings("li").removeClass("active");
	showData()
});
var terminal_id=0;
$("#terminal").change(function(){
	terminal_id=$("#terminal").val();
	showData()
})
var seller_id=-1;
$("#seller").change(function(){
	seller_id=$("#seller").val();
	showData()
})

var dataSelect_index3=0
$("#dataSelect_3>span").click(function(){
    var index=$(this).index();
    dataSelect_index3=index;
    $(this).addClass("active").siblings("span").removeClass("active");
    showData()
});
var c1=c2=c3=0;
function showData(){
	c1=c2=c3=0;
	if(dateType=="day"){
		getDate_sc_hydp_day()
	}
	if(dateType=="week"){
		getDate_sc_hydp_week()
	}
	if(dateType=="month"){
		getDate_sc_hydp_month()
	}
	$("tr").on("click", "td", function() {
		if($(this).text()=="作废"){
			remove($(this).parent().find("td:first").text())
		}
	});
}
function remove(date){
	if(!confirm("是否要作废？")){
		return;
	}
	$.ajax({
			type:'post',
			url:server[0]._server_port+"/option/Pangolin_ShiChang_scdp_delete.htm",
			data:{
				startDate:date.split("~")[0],
				endDate:date.split("~")[1],
				dateType:dateType,
				categoryId:category_id,
				sellerId:seller_id,
				terminalId:terminal_id
			},
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==-2){
					alert(data.msg);
				}
				if(data.status==-1){
					alert(data.msg);
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
				}
				if(data.status==2){}
				if(data.status==0){
					alert(data.msg);
				}
				if(data.status==1){
					showData()
				}
			}
			})
	
}

function getIntervalMonth(startDate,endStart){
    var startMonth = startDate.getMonth();
    var endMonth = endStart.getMonth();
    var intervalMonth = (endStart.getFullYear()*12+endMonth) - (startDate.getFullYear()*12+startMonth);
    return intervalMonth;
}
function getMonth(startDate,i){
	var year=parseInt(startDate.split('-')[0]);
	var month=parseInt(startDate.split('-')[1]);
	if(month+i>12){
		var count=	parseInt((month+i)/12)
		month=(month+i)-12*count;
		if(month==0){
			year=year+count-1;
			month=12;
			return year+"-"+month+"-01"
		}else{
			year=year+count;
			return year+"-"+(month>9?month:"0"+month)+"-01";
		}
		
	}else{
		month=month+i
		return year+"-"+(month>9?month:"0"+month)+"-01";
	}
}
function getDate_sc_hydp_month(){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))
	$("#hydp tbody").html("")
	for(var i=0;i<=count;i++){
		var tr_id=getMonth(startDate,i);
		$("#hydp tbody").append('<tr id="hydp_'+tr_id+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType,
				categoryId:category_id,
				sellerId:seller_id,
				terminalId:terminal_id
			},
			url:server[0]._server_port+(server[0].mappings)[16]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
				}
				$("#hydp_count2").text(c1)
				if(data.data[0].status==2){
					c2++
				}
				$("#hydp_count3").text(c2)
				if(data.data[0].status==3){
					c3++
				}
				$("#hydp_count4").text(c3)
				$("#hydp_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect_index3==0){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#hydp_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#hydp_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#hydp_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#hydp_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/overview" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#hydp_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#hydp_"+startDate.split('~')[0]).attr("style","background: rgb(255, 216, 216);");
						$("#hydp_"+startDate.split('~')[0]).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/overview" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index3==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#hydp_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#hydp_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#hydp_"+this.startDate.split('~')[0]).remove();
					})
				}
				
				if(data.status==1 && dataSelect_index3==2){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#hydp_"+this.startDate).remove();
					})
					if(status==2){
						$("#hydp_"+startDate.split('~')[0]).attr("style","background: rgb(255, 216, 216);");
						$("#hydp_"+startDate.split('~')[0]).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/overview" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index3==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#hydp_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#hydp_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/overview" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#hydp_"+this.startDate.split('~')[0]).remove();
					})

				}
			}
		})
	}
}



function getDate_sc_hydp_week(){
	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}
	$("#hydp tbody").html("")
	for(var i=0;i<count;i++){
		$("#hydp tbody").append('<tr id="hydp_'+addDate(startDate,  7*i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType,
				categoryId:category_id,
				sellerId:seller_id,
				terminalId:terminal_id
			},
			url:server[0]._server_port+(server[0].mappings)[16]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
				}
				$("#hydp_count2").text(c1)
				if(data.data[0].status==2){
					c2++
				}
				$("#hydp_count3").text(c2)
				if(data.data[0].status==3){
					c3++
				}
				$("#hydp_count4").text(c3)
				$("#hydp_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect_index3==0){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#hydp_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#hydp_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#hydp_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#hydp_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/overview" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#hydp_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#hydp_"+startDate.split('~')[0]).attr("style","background: rgb(255, 216, 216);");
						$("#hydp_"+startDate.split('~')[0]).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/overview" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index3==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#hydp_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#hydp_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#hydp_"+this.startDate.split('~')[0]).remove();
					})
				}
				
				if(data.status==1 && dataSelect_index3==2){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#hydp_"+this.startDate).remove();
					})
					if(status==2){
						$("#hydp_"+startDate.split('~')[0]).attr("style","background: rgb(255, 216, 216);");
						$("#hydp_"+startDate.split('~')[0]).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/overview" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index3==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#hydp_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#hydp_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/overview" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#hydp_"+this.startDate.split('~')[0]).remove();
					})

				}
			}
		})
	}
}

function getDate_sc_hydp_day(){
	var startDate;
	var endDate;
	startDate=$("#date_day_1").find("input")[0].value.trim()
	endDate=$("#date_day_1").find("input")[1].value.trim()
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	$("#hydp tbody").html("")
	for(var i=0;i<=count;i++){
		$("#hydp tbody").append('<tr id="hydp_'+addDate(startDate, i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				categoryId:category_id,
				sellerId:seller_id,
				terminalId:terminal_id
			},
			url:server[0]._server_port+(server[0].mappings)[16]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
				}
				$("#hydp_count2").text(c1)
				if(data.data[0].status==2){
					c2++
				}
				$("#hydp_count3").text(c2)
				if(data.data[0].status==3){
					c3++
				}
				$("#hydp_count4").text(c3)
				$("#hydp_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect_index3==0){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#hydp_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#hydp_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#hydp_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#hydp_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/overview" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#hydp_"+this.startDate).remove();
					})
					if(status==2){
						$("#hydp_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#hydp_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/overview" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index3==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#hydp_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#hydp_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#hydp_"+this.startDate).remove();
					})
				}
				
				if(data.status==1 && dataSelect_index3==2){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#hydp_"+this.startDate).remove();
					})
					if(status==2){
						$("#hydp_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#hydp_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/overview" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index3==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#hydp_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#hydp_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/overview" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#hydp_"+this.startDate).remove();
					})

				}
			}
		})
	}
}