$(document).ready(function(){
	init_top_category()
});
var category_id='';
$("#categoryDiv").on("mouseup", "li", function() {
	$(".selectCategory>div").hide(500);
	category_id=$(this).attr("value");
	$(".selectCategory>span").text($(this).text());
	$(this).addClass("active").siblings("li").removeClass("active");
	showData()
});
$(".selectCategory>span").click(function(e){
	$(".selectCategory>div").show(500);
	e.stopPropagation();
    $(document,".fa-times").click(function(){
      $(".selectCategory>div").hide(500);
    })
})
$(".selectCategory").on("mouseover", "li", function() {
	//if($(this).parent().attr('class')=="category1")
	var obj=$(this);
	var name=$(this).text();
	var cg=$(this).parent().attr('class');
	$.ajax({
		type:"post",
		data:{categoryId:$(this).attr("value")},
		url:server[0]._server_port+(server[0].mappings)[15]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				if(data.data.length>0){
					obj.html("");
					obj.append('<span title="'+name+'">'+name+'</span><i class="iconfont icon-youjiantou pull-right"></i>');
				}
				if(cg=="category1"){
					$(".category2").html("")
					$.each(data.data,function(index){
						$(".category2").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
					})
				}
				if(cg=="category2"){
					$(".category3").html("")
					$.each(data.data,function(index){
						$(".category3").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
					})
				}
			}
		}
	})
});
function init_top_category(){
	$.ajax({
		type:"post",
		xhrFields:{withCredentials:true},
		url:server[0]._server_port+(server[0].mappings)[17]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$.each(data.data,function(index){
					if(index==0){
						category_id=this.cid
						$(".selectCategory>span").text(this.name);
					}
				$(".category1").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
			})
			}
		}
	})
}
var tab=0;
$(".tabTitle>span").click(function(){
	tab=$(this).index();
	if(tab==5){
		$('.tabTitleBtn>span:nth-child(1)').text('趋势词')
		$('.tabTitleBtn>span:nth-child(2)').text('新词')
	}else{
		$('.tabTitleBtn>span:nth-child(1)').text('热搜')
		$('.tabTitleBtn>span:nth-child(2)').text('飙升')
	}
	
	$(this).addClass("active").siblings("span").removeClass("active");
	showData();
})

var tab1=0;
$(".tabTitleBtn>span").click(function(){
	tab1=$(this).index();
	$(this).addClass("active").siblings("span").removeClass("active");
	showData();
})

var dataSelect=0;
$(".dataSelect>span").click(function(){
    var index=$(this).index();
    dataSelect=index;
    $(this).addClass("active").siblings("span").removeClass("active");
    showData()
});

$(".dayDate").find("input").change(function(){
	showData()
})
$("#terminal").change(function(){
	showData()
})
var c1=c2=c3=0;
function showData(){c1=c2=c3=0;
	checkData();
	$("tr").on("click", "td", function() {
		if($(this).text()=="作废"){
			remove($(this).parent().find("td:first").text())
		}
	});
}
function remove(date){
	if(!confirm("是否要作废？")){
		return;
	}
	$.ajax({
			type:'post',
			url:server[0]._server_port+"/option/Pangolin_checkMarketData_delete.htm",
			data:{
				startDate:date.split("~")[0],
				endDate:date.split("~")[1],
				dateType:"day",
				tab:tab,
				tabOne:tab1,
				device:$("#terminal").val(),
				categoryId:category_id
			},
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==-2){
					alert(data.msg);
				}
				if(data.status==-1){
					alert(data.msg);
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
				}
				if(data.status==2){}
				if(data.status==0){
					alert(data.msg);
				}
				if(data.status==1){
					showData()
				}
			}
			})
	
}

function addDate(date, days) {

    var date = new Date(date);
    date.setDate(date.getDate() + days);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return date.getFullYear() + '-' + getFormatDate(month) + '-' + getFormatDate(day);
}
function getFormatDate(arg) {
    if (arg == undefined || arg == '') {
        return '';
    }

    var re = arg + '';
    if (re.length < 2) {
        re = '0' + re;
    }

    return re;
}
var dateType="day";
function checkData(){

	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dayDate").find("input")[0].value.trim()
		endDate=$(".dayDate").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	$("#_table tbody").html("")
	for(var i=0;i<=count;i++){
		$("#_table tbody").append('<tr id="_table_'+addDate(startDate, i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:"day",
				tab:tab,
				tabOne:tab1,
				device:$("#terminal").val(),
				categoryId:category_id
			},
			url:server[0]._server_port+(server[0].mappings)[100/2]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
					
				}
				$("#_span2").text(c1)
				if(data.data[0].status==2){
					c2++
					
				}
				$("#_span3").text(c2)
				if(data.data[0].status==3){
					c3++
					
				}
				$("#_span4").text(c3)
				$("#_span1").text(c1+c2+c3)
				if(data.status==1 && dataSelect==0){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#_table_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#_table_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#_table_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#_table_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据(1.该天没抓取 2.该条件下生意参谋无数据！)</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_rank" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#_table_"+this.startDate).remove();
					})
					if(status==2){
						$("#_table_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#_table_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_rank" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#_table_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#_table_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#_table_"+this.startDate).remove();
					})
				}
				
				if(data.status==1 && dataSelect==2){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#_table_"+this.startDate).remove();
					})
					if(status==2){
						$("#_table_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#_table_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_rank" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#_table_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#_table_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据(1.该天没抓取 2.该条件下生意参谋无数据！)</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_rank" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#_table_"+this.startDate).remove();
					})

				}
			}
		})
	}
	

}