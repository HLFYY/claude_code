var backgroundPage = chrome.extension.getBackgroundPage();
var server=backgroundPage.getServer();
$.ajaxSetup({crossDomain: true, xhrFields: {withCredentials: true}});
$(document).ready(function(){
	$("#terminal").parent().hide()
	init_date_div()
	showData();
})

var dateType='day';
$(".selectTime>span").click(function(){
    var index=$(this).index();
    $(this).addClass("on").siblings("span").removeClass("on");
    if($(this).text()=="按日")dateType='day' 
    if($(this).text()=="按周")dateType='week' 
    if($(this).text()=="按月")dateType='month' 
    init_date_div();
    showData();
});

$(".dateBox,.weekBox,.monthBox").change(function(){
	showData()
})

function init_date_div(){
	if(dateType=="day"){
		$(".monthBox").hide();
		$(".weekBox").hide();
		$(".dateBox").show();
	}
	if(dateType=="week"){
		$(".monthBox").hide();
		$(".weekBox").show();
		$(".dateBox").hide();
	}
	if(dateType=="month"){
		$(".monthBox").show();
		$(".weekBox").hide();
		$(".dateBox").hide();
	}
}
var tab=0;
$(".tabTitle>span").click(function(){
	
	var index=$(this).index();
	if(index==0){
		$("#terminal").parent().hide()
	}
	if(index==1){
		$("#terminal").parent().show()
	}
	tab=index;
    $(this).addClass("active").siblings("span").removeClass("active");
    showData()
})

var dataSelect=0;
$(".dataSelect>span").click(function(){
    var index=$(this).index();
    dataSelect=index;
    $(this).addClass("active").siblings("span").removeClass("active");
    showData()
});

$("#terminal").change(function(){
	showData()
})

var c1=c2=c3=0;
function showData(){c1=c2=c3=0;
	if (tab == 0) {
		if (dateType == "day") {
			getCategoryData_day()
		}
		if (dateType == "week") {
			getCategoryData_week()
		}
		if (dateType == "month") {
			getCategoryData_month()
		}
	}
	if (tab == 1) {
		if (dateType == "day") {
			getCategoryProductData_day()
		}
		if (dateType == "week") {
			getCategoryProductData_week()
		}
		if (dateType == "month") {
			getCategoryProductData_month()
		}
	}
	$("tr").on("click", "td", function() {
		if($(this).text()=="作废"){
			remove($(this).parent().find("td:first").text())
		}
	});
}
function remove(date){
	if(!confirm("是否要作废？")){
		return;
	}
	$.ajax({
			type:'post',
			url:server[0]._server_port+"/option/Pangolin_category_delete.htm",
			data:{
				startDate:date.split("~")[0],
				endDate:date.split("~")[1],
				dateType:dateType,
				device:$("#terminal").val(),
				tab:tab
			},
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==-2){
					alert(data.msg);
				}
				if(data.status==-1){
					alert(data.msg);
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
				}
				if(data.status==2){}
				if(data.status==0){
					alert(data.msg);
				}
				if(data.status==1){
					showData()
				}
			}
			})
	
}

function getCategoryProductData_month(){

	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))
	$("#categoryCoreIndex tbody").html("")
	for(var i=0;i<=count;i++){
		var tr_id=getMonth(startDate,i);
		$("#categoryCoreIndex tbody").append('<tr id="category_'+tr_id+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType,
				device:$("#terminal").val()
			},
			url:server[0]._server_port+(server[0].mappings)[44]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
				}
				$("#category_count2").text(c1)
				if(data.data[0].status==2){
					c2++
				}
				$("#category_count3").text(c2)
				if(data.data[0].status==3){
					c3++
				}
				$("#category_count4").text(c3)
				$("#category_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect==0){
					var lack_count="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/cc/macroscopic_monitor" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								lack_count=this.lack_count
							}else{
								lack_count=lack_count+';'+this.lack_count
							}
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#category_"+startDate.split('~')[0]).attr("style","background: rgb(255, 216, 216);");
						$("#category_"+startDate.split('~')[0]).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/cc/macroscopic_monitor" target="_blank">读取数据</a></td> <td>该类目下还缺少'+lack_count+'条数据！请点击剩余页数！</td>')
					}
				}
				
				if(data.status==1 && dataSelect==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#category_"+this.startDate).remove();
					})
				}
				
				if(data.status==1 && dataSelect==2){
					var lack_count="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								lack_count=this.lack_count
							}else{
								lack_count=lack_count+';'+this.lack_count
							}
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#category_"+startDate.split('~')[0]).attr("style","background: rgb(255, 216, 216);");
						$("#category_"+startDate.split('~')[0]).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/cc/macroscopic_monitor" target="_blank">读取数据</a></td> <td>该类目下还缺少'+lack_count+'条数据！请点击剩余页数！</td>')
					}
				}
				
				if(data.status==1 && dataSelect==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/cc/macroscopic_monitor" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})

				}
			}
		})
	}


}

function getCategoryProductData_week(){

	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}
	$("#categoryCoreIndex tbody").html("")
	for(var i=0;i<count;i++){
		$("#categoryCoreIndex tbody").append('<tr id="category_'+addDate(startDate,  7*i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType,
				device:$("#terminal").val(),
			},
			url:server[0]._server_port+(server[0].mappings)[44]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
				}
				$("#category_count2").text(c1)
				if(data.data[0].status==2){
					c2++
				}
				$("#category_count3").text(c2)
				if(data.data[0].status==3){
					c3++
				}
				$("#category_count4").text(c3)
				$("#category_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect==0){
					var lack_count="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/cc/macroscopic_monitor" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								lack_count=this.lack_count
							}else{
								lack_count=lack_count+';'+this.lack_count
							}
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#category_"+startDate.split('~')[0]).attr("style","background: rgb(255, 216, 216);");
						$("#category_"+startDate.split('~')[0]).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/cc/macroscopic_monitor" target="_blank">读取数据</a></td> <td>该类目下还缺少'+lack_count+'条数据！请点击剩余页数！</td>')
					}
				}
				
				if(data.status==1 && dataSelect==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#category_"+this.startDate).remove();
					})
				}
				
				if(data.status==1 && dataSelect==2){
					var lack_count="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								lack_count=this.lack_count
							}else{
								lack_count=lack_count+';'+this.lack_count
							}
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#category_"+startDate.split('~')[0]).attr("style","background: rgb(255, 216, 216);");
						$("#category_"+startDate.split('~')[0]).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/cc/macroscopic_monitor" target="_blank">读取数据</a></td> <td>该类目下还缺少'+lack_count+'条数据！请点击剩余页数！</td>')
					}
				}
				
				if(data.status==1 && dataSelect==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/cc/macroscopic_monitor" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})

				}
			}
		})
	}


}

function getCategoryProductData_day(){

	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	$("#categoryCoreIndex tbody").html("")
	for(var i=0;i<=count;i++){
		$("#categoryCoreIndex tbody").append('<tr id="category_'+addDate(startDate, i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				device:$("#terminal").val()
			},
			url:server[0]._server_port+(server[0].mappings)[44]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
				}
				$("#category_count2").text(c1)
				if(data.data[0].status==2){
					c2++
				}
				$("#category_count3").text(c2)
				if(data.data[0].status==3){
					c3++
				}
				$("#category_count4").text(c3)
				$("#category_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect==0){
					var lack_count="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#category_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#category_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#category_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#category_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/cc/macroscopic_monitor" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								lack_count=this.lack_count
							}else{
								lack_count=lack_count+';'+this.lack_count
							}
						}
						if(boolean)$("#category_"+this.startDate).remove();
					})
					if(status==2){
						$("#category_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#category_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/cc/macroscopic_monitor" target="_blank">读取数据</a></td> <td>该类目下还缺少'+lack_count+'条数据！请点击剩余页数！</td>')
					}
				}
				
				if(data.status==1 && dataSelect==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#category_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#category_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#category_"+this.startDate).remove();
					})
				}
				
				if(data.status==1 && dataSelect==2){
					var lack_count="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								lack_count=this.lack_count
							}else{
								lack_count=lack_count+';'+this.lack_count
							}
						}
						if(boolean)$("#category_"+this.startDate).remove();
					})
					if(status==2){
						$("#category_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#category_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/cc/macroscopic_monitor" target="_blank">读取数据</a></td> <td>该类目下还缺少'+lack_count+'条数据！请点击剩余页数！</td>')
					}
				}
				
				if(data.status==1 && dataSelect==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#category_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#category_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/cc/macroscopic_monitor" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#category_"+this.startDate).remove();
					})
				}
			}
		})
	}

}


function addDate(date, days) {
    var date = new Date(date);
    date.setDate(date.getDate() + days);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return date.getFullYear() + '-' + getFormatDate(month) + '-' + getFormatDate(day);
}

function getFormatDate(arg) {
    if (arg == undefined || arg == '') {
        return '';
    }
    var re = arg + '';
    if (re.length < 2) {
        re = '0' + re;
    }
    return re;
}

function getCategoryData_day(){
	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	$("#categoryCoreIndex tbody").html("")
	for(var i=0;i<=count;i++){
		$("#categoryCoreIndex tbody").append('<tr id="category_'+addDate(startDate, i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				tab:tab,
				device:$("#terminal").val()
			},
			url:server[0]._server_port+(server[0].mappings)[86/2]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
					
				}
				$("#category_count2").text(c1)
				if(data.data[0].status==2){
					c2++
					
				}
				$("#category_count3").text(c2)
				if(data.data[0].status==3){
					c3++
					
				}
				$("#category_count4").text(c3)
				$("#category_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect==0){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#category_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#category_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#category_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#category_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#category_"+this.startDate).remove();
					})
					if(status==2){
						$("#category_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#category_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#category_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#category_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#category_"+this.startDate).remove();
					})
				}
				
				if(data.status==1 && dataSelect==2){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#category_"+this.startDate).remove();
					})
					if(status==2){
						$("#category_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#category_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#category_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#category_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#category_"+this.startDate).remove();
					})

				}
			}
		})
	}
	
}

function getCategoryData_week(){
	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}
	$("#categoryCoreIndex tbody").html("")
	for(var i=0;i<count;i++){
		$("#categoryCoreIndex tbody").append('<tr id="category_'+addDate(startDate, 7*i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType
			},
			url:server[0]._server_port+(server[0].mappings)[86/2]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
					
				}
				$("#category_count2").text(c1)
				if(data.data[0].status==2){
					c2++
					
				}
				$("#category_count3").text(c2)
				if(data.data[0].status==3){
					c3++
					
				}
				$("#category_count4").text(c3)
				$("#category_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect==0){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate.split('~')[0];
							startDate_status_2=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#category_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#category_"+startDate).append('<td>'+startDate_status_2+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})
				}
				
				if(data.status==1 && dataSelect==2){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate.split('~')[0];
							startDate_status_2=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#category_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#category_"+startDate).append('<td>'+startDate_status_2+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				if(data.status==1 && dataSelect==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})
				}
			}
		})
	}
	
}
function getIntervalMonth(startDate,endStart){
    var startMonth = startDate.getMonth();
    var endMonth = endStart.getMonth();
    var intervalMonth = (endStart.getFullYear()*12+endMonth) - (startDate.getFullYear()*12+startMonth);
    return intervalMonth;
}
function getMonth(startDate,i){
	var year=parseInt(startDate.split('-')[0]);
	var month=parseInt(startDate.split('-')[1]);
	if(month+i>12){
		var count=	parseInt((month+i)/12)
		month=(month+i)-12*count;
		if(month==0){
			year=year+count-1;
			month=12;
			return year+"-"+month+"-01"
		}else{
			year=year+count;
			return year+"-"+(month>9?month:"0"+month)+"-01";
		}
		
	}else{
		month=month+i
		return year+"-"+(month>9?month:"0"+month)+"-01";
	}
}
function getCategoryData_month(){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))

	$("#categoryCoreIndex tbody").html("")
	for(var i=0;i<=count;i++){
		var tr_id=getMonth(startDate,i);
		$("#categoryCoreIndex tbody").append('<tr id="category_'+tr_id+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType
			},
			url:server[0]._server_port+(server[0].mappings)[86/2]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
					
				}
				$("#category_count2").text(c1)
				if(data.data[0].status==2){
					c2++
					
				}
				$("#category_count3").text(c2)
				if(data.data[0].status==3){
					c3++
					
				}
				$("#category_count4").text(c3)
				$("#category_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect==0){
					var index_names="";
					var status=0;
					var startDate="";
					var startDate_status_2="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate.split('~')[0];
							startDate_status_2=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#category_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#category_"+startDate).append('<td>'+startDate_status_2+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})
				}
				
				if(data.status==1 && dataSelect==2){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate.split('~')[0];
							startDate_status_2=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#category_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#category_"+startDate).append('<td>'+startDate_status_2+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				if(data.status==1 && dataSelect==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#category_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#category_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#category_"+this.startDate.split('~')[0]).remove();
					})
				}
			}
		})
	}
	
}