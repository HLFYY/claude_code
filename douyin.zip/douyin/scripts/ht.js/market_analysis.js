$(document).ready(function(){init_date_div()
	getKeyWord()
	showData();
})
var backgroundPage = chrome.extension.getBackgroundPage();
var server=backgroundPage.getServer();
$.ajaxSetup({crossDomain: true, xhrFields: {withCredentials: true}});


function init_date_div(){
	if(dateType=="day"){
		$($(".selectTime").find("span")[1]).addClass("on").siblings("span").removeClass("on");
		$(".monthBox").hide();
		$(".weekBox").hide();
		$(".dateBox").show();
	}
	if(dateType=="week"){
		$($(".selectTime").find("span")[2]).addClass("on").siblings("span").removeClass("on");
		$(".monthBox").hide();
		$(".weekBox").show();
		$(".dateBox").hide();
	}
	if(dateType=="month"){
		$($(".selectTime").find("span")[3]).addClass("on").siblings("span").removeClass("on");
		$(".monthBox").show();
		$(".weekBox").hide();
		$(".dateBox").hide();
	}
}
var dateType='day';
$(".selectTime>span").click(function(){
    var index=$(this).index();
    $(this).addClass("on").siblings("span").removeClass("on");
    if($(this).text()=="按日")dateType='day' 
    if($(this).text()=="按周")dateType='week' 
    if($(this).text()=="按月")dateType='month' 
    init_date_div();
    showData();
});







var header_tabId=0;
$(".ul1").on("click", "li", function() {
	header_tabId=$(this).index()
	$(this).siblings().removeClass("active");
	$(this).addClass("active");
	if($(this).text()=="下载"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/downLoad.html')});
	}else if($(this).text()=="市场"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/market_BigPlate.html')});
	}else if($(this).text()=="取数"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/options.html')});
	}
});
$("#page").paging({
    pageNo:1,
    totalPage: 3,
    totalSize: 17,
    callback: function(num) {
      alert(num)
    }
  })
var num=$(".state").length;
for(i=0;i<num;i++){
	if($(".state")[i].innerHTML=="完整数据"){
		$(".state")[i].parentNode.style.background="#cbf0d7";
	}
	if($(".state")[i].innerHTML=="无数据"){
		$(".state")[i].parentNode.style.background="#f5f5f5";
	}
	if($(".state")[i].innerHTML=="缺少部分数据"){
		$(".state")[i].parentNode.style.background="#ffd8d8";
	}
}
$(".addKeyWord").click(function(){
	$("#addKeyWord").show();
})
$(".deleteKeyWord").click(function(){del_keyWord()
	$("#deleteKeyWord").show();
})
$(".modelTitle>.pull-right").click(function(){
	$(".cover").hide();
})

$("#keyword_btn").click(function(){
	$.ajax({
		type:'post',
		data:{keyword:$("#keyword").val()},
		url:server[0]._server_port+(server[0].mappings)[24]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$(".cover").hide();
				backgroundPage.getKeyWord();
				getKeyWord();
			}else
				if(data.status==-1){
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
				}else{
					alert(data.msg)
				}
		}
	})
})

function getKeyWord(){
	$.ajax({
		type:'get',
		async:false,
		url:server[0]._server_port+(server[0].mappings)[25]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$("#keyWord_select").html('')
				$.each(data.data,function(){
					$("#keyWord_select").append('<option value="'+this.keyword+'">'+this.keyword+'</option>')
				})
			}else
				if(data.status==-1){
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
				}else{
					alert(data.msg)
				}
		}
	})
}

function del_keyWord(){

	$.ajax({
		type:'get',
		url:server[0]._server_port+(server[0].mappings)[25]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$("#keyword_del").html('')
				$.each(data.data,function(){
					$("#keyword_del").append('<option value="'+this.keyword+'">'+this.keyword+'</option>')
				})
			}else
				if(data.status==-1){
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
				}else{
					alert(data.msg)
				}
		}
	})

}

$("#keyWord_del_btn").click(function(){
	$.ajax({
		type:'post',
		data:{keyword:$("#keyword_del").val()},
		url:server[0]._server_port+(server[0].mappings)[26]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$(".cover").hide();
				backgroundPage.getKeyWord();
				getKeyWord()
			}else
				if(data.status==-1){
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
				}else{
					alert(data.msg)
				}
		}
	})
})

$("#keyWord_select").change(function(){
	showData();
})
$(".dateBox").change(function(){
	if(tab==2){
		getParent_category(".dateBox")
		showData();
	}else{
		showData();
	}
	
})
$(".weekBox").change(function(){
	if(tab==2){
		getParent_category(".weekBox")
		showData();
	}else{
		showData();
	}
	
})
$(".monthBox").change(function(){
	if(tab==2){
		getParent_category(".monthBox")
		showData();
	}else{
		showData();
	}
	
})
$("#terminal").change(function(){
	showData();
})
$("#parent_cateId").change(function(){
	showData();
})
var tab=0;
$(".tabTitle>span").click(function(){
	tab=$(this).index();
	if(tab==0 ){
		init_date_div()
		$(".selectTime").show();
		$("#parent_category").hide();
		$(".tabTitleBtn").parent().hide(200);
	}
	if(tab==1){
		dateType="day"
		init_date_div()
		$(".selectTime").hide();
		$("#parent_category").hide();
		$(".tabTitleBtn").parent().show(200);
	}
	if(tab==2){
		init_date_div()
		$(".selectTime").show();
		$("#parent_category").show();
		$(".tabTitleBtn").parent().hide(200);
		if(dateType=="day")getParent_category(".dateBox")
		if(dateType=="week")getParent_category(".weekBox")
		if(dateType=="month")getParent_category(".monthBox")
	}
	$(this).addClass("active").siblings("span").removeClass("active");
	showData()
})

var tab2=0;
$(".tabTitleBtn>span").click(function(){
	tab2=$(this).index();
	$(this).addClass("active").siblings("span").removeClass("active");
	showData()
})


var dataSelect=0;
$(".dataSelect>span").click(function(){
    var index=$(this).index();
    dataSelect=index;
    $(this).addClass("active").siblings("span").removeClass("active");
    showData()
});
var c1=c2=c3=0;
function showData(){c1=c2=c3=0;
	if(tab==0){
		if(dateType=="day"){
			market_keyword_day(30)
		}
		if(dateType=="week"){
			market_keyword_week(30)
		}
		if(dateType=="month"){
			market_keyword_month(30)
		}
	}
	if(tab==1){
		market_keyword_day(31)
	}
	if(tab==2){
		if(dateType=="day"){
			market_keyword_day(32)
		}
		if(dateType=="week"){
			market_keyword_week(32)
		}
		if(dateType=="month"){
			market_keyword_month(32)
		}
	}
	$("tr").on("click", "td", function() {
		if($(this).text()=="作废"){
			remove($(this).parent().find("td:first").text())
		}
	});
}
function remove(date){
	if(!confirm("是否要作废？")){
		return;
	}
	$.ajax({
			type:'post',
			url:server[0]._server_port+"/option/Pangolin_keyword_delete.htm",
			data:{
				startDate:date.split("~")[0],
				endDate:date.split("~")[1],
				dateType:dateType,
				keyword:$("#keyWord_select").val(),
				device:$("#terminal").val(),
				parentcateId:$("#parent_cateId").val(),
				tab:tab,
				relatedWordsType:tab2
			},
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==-2){
					alert(data.msg);
				}
				if(data.status==-1){
					alert(data.msg);
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
				}
				if(data.status==2){}
				if(data.status==0){
					alert(data.msg);
				}
				if(data.status==1){
					showData()
				}
			}
			})
	
}


function addDate(date, days) {

    var date = new Date(date);
    date.setDate(date.getDate() + days);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return date.getFullYear() + '-' + getFormatDate(month) + '-' + getFormatDate(day);
}
function getFormatDate(arg) {
    if (arg == undefined || arg == '') {
        return '';
    }

    var re = arg + '';
    if (re.length < 2) {
        re = '0' + re;
    }

    return re;
}
function getIntervalMonth(startDate,endStart){
    var startMonth = startDate.getMonth();
    var endMonth = endStart.getMonth();
    var intervalMonth = (endStart.getFullYear()*12+endMonth) - (startDate.getFullYear()*12+startMonth);
    return intervalMonth;
}

function getMonth(startDate,i){
	var year=parseInt(startDate.split('-')[0]);
	var month=parseInt(startDate.split('-')[1]);
	if(month+i>12){
		var count=	parseInt((month+i)/12)
		month=(month+i)-12*count;
		if(month==0){
			year=year+count-1;
			month=12;
			return year+"-"+month+"-01"
		}else{
			year=year+count;
			return year+"-"+(month>9?month:"0"+month)+"-01";
		}
		
	}else{
		month=month+i
		return year+"-"+(month>9?month:"0"+month)+"-01";
	}
}
function market_keyword_month(val){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))
	$("#market_table tbody").html("")
	for(var i=0;i<=count;i++){
		var tr_id=getMonth(startDate,i);
		$("#market_table tbody").append('<tr id="market_'+tr_id+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType,
				keyword:$("#keyWord_select").val(),
				device:$("#terminal").val(),
				parentcateId:$("#parent_cateId").val(),
				relatedWordsType:tab2
			},
			url:server[0]._server_port+(server[0].mappings)[val]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
				}
				$("#market_count2").text(c1)
				if(data.data[0].status==2){
					c2++
				}
				$("#market_count3").text(c2)
				if(data.data[0].status==3){
					c3++
				}
				$("#market_count4").text(c3)
				$("#market_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect==0){
					var lack_count="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#market_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#market_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#market_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#market_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_analyze" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								lack_count=this.lack_count
							}else{
								lack_count=lack_count+';'+this.lack_count
							}
						}
						if(boolean)$("#market_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#market_"+startDate.split('~')[0]).attr("style","background: rgb(255, 216, 216);");
						$("#market_"+startDate.split('~')[0]).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_analyze" target="_blank">读取数据</a></td> <td>该类目下还缺少'+lack_count+'条数据！请点击剩余页数！</td>')
					}
				}
				
				if(data.status==1 && dataSelect==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#market_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#market_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#market_"+this.startDate).remove();
					})
				}
				
				if(data.status==1 && dataSelect==2){
					var lack_count="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								lack_count=this.lack_count
							}else{
								lack_count=lack_count+';'+this.lack_count
							}
						}
						if(boolean)$("#market_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#market_"+startDate.split('~')[0]).attr("style","background: rgb(255, 216, 216);");
						$("#market_"+startDate.split('~')[0]).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_analyze" target="_blank">读取数据</a></td> <td>该类目下还缺少'+lack_count+'条数据！请点击剩余页数！</td>')
					}
				}
				
				if(data.status==1 && dataSelect==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#market_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#market_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_analyze" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#market_"+this.startDate.split('~')[0]).remove();
					})

				}
			}
		})
	}

}

function market_keyword_week(val){
	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}
	$("#market_table tbody").html("")
	for(var i=0;i<count;i++){
		$("#market_table tbody").append('<tr id="market_'+addDate(startDate,  7*i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType,
				keyword:$("#keyWord_select").val(),
				device:$("#terminal").val(),
				parentcateId:$("#parent_cateId").val(),
				relatedWordsType:tab2
			},
			url:server[0]._server_port+(server[0].mappings)[val]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
				}
				$("#market_count2").text(c1)
				if(data.data[0].status==2){
					c2++
				}
				$("#market_count3").text(c2)
				if(data.data[0].status==3){
					c3++
				}
				$("#market_count4").text(c3)
				$("#market_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect==0){
					var lack_count="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#market_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#market_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#market_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#market_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_analyze" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								lack_count=this.lack_count
							}else{
								lack_count=lack_count+';'+this.lack_count
							}
						}
						if(boolean)$("#market_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#market_"+startDate.split('~')[0]).attr("style","background: rgb(255, 216, 216);");
						$("#market_"+startDate.split('~')[0]).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_analyze" target="_blank">读取数据</a></td> <td>该类目下还缺少'+lack_count+'条数据！请点击剩余页数！</td>')
					}
				}
				
				if(data.status==1 && dataSelect==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#market_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#market_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#market_"+this.startDate).remove();
					})
				}
				
				if(data.status==1 && dataSelect==2){
					var lack_count="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								lack_count=this.lack_count
							}else{
								lack_count=lack_count+';'+this.lack_count
							}
						}
						if(boolean)$("#market_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#market_"+startDate.split('~')[0]).attr("style","background: rgb(255, 216, 216);");
						$("#market_"+startDate.split('~')[0]).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_analyze" target="_blank">读取数据</a></td> <td>该类目下还缺少'+lack_count+'条数据！请点击剩余页数！</td>')
					}
				}
				
				if(data.status==1 && dataSelect==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#market_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#market_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_analyze" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#market_"+this.startDate.split('~')[0]).remove();
					})

				}
			}
		})
	}

}

var dateType="day";
function market_keyword_day(val){
	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	$("#market_table tbody").html("")
	for(var i=0;i<=count;i++){
		$("#market_table tbody").append('<tr id="market_'+addDate(startDate, i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				keyword:$("#keyWord_select").val(),
				device:$("#terminal").val(),
				parentcateId:$("#parent_cateId").val(),
				relatedWordsType:tab2
			},
			url:server[0]._server_port+(server[0].mappings)[val]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
				}
				$("#market_count2").text(c1)
				if(data.data[0].status==2){
					c2++
				}
				$("#market_count3").text(c2)
				if(data.data[0].status==3){
					c3++
				}
				$("#market_count4").text(c3)
				$("#market_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect==0){
					var lack_count="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#market_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#market_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#market_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#market_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_analyze" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								lack_count=this.lack_count
							}else{
								lack_count=lack_count+';'+this.lack_count
							}
						}
						if(boolean)$("#market_"+this.startDate).remove();
					})
					if(status==2){
						$("#market_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#market_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_analyze" target="_blank">读取数据</a></td> <td>该类目下还缺少'+lack_count+'条数据！请点击剩余页数！</td>')
					}
				}
				
				if(data.status==1 && dataSelect==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#market_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#market_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#market_"+this.startDate).remove();
					})
				}
				
				if(data.status==1 && dataSelect==2){
					var lack_count="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								lack_count=this.lack_count
							}else{
								lack_count=lack_count+';'+this.lack_count
							}
						}
						if(boolean)$("#market_"+this.startDate).remove();
					})
					if(status==2){
						$("#market_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#market_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_analyze" target="_blank">读取数据</a></td> <td>该类目下还缺少'+lack_count+'条数据！请点击剩余页数！</td>')
					}
				}
				
				if(data.status==1 && dataSelect==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#market_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#market_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mc/mq/search_analyze" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#market_"+this.startDate).remove();
					})

				}
			}
		})
	}
}

function getParent_category(val){
	$.ajax({
		type:'post',
		async:false,
		data:{
			startDate:$(val).find("input")[0].value.trim(),
			dateType:dateType,
			keyword:$("#keyWord_select").val(),
			device:$("#terminal").val()
			},
		url:server[0]._server_port+(server[0].mappings)[33]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$("#parent_cateId").html('')
				if(data.data.length>0){
					$.each(data.data,function(){
						$("#parent_cateId").append('<option value="'+this.cateId+'">'+this.cateName+'</option>')
					})
				}else{
					$("#parent_cateId").append('<option value="">'+$(".dateBox").find("input")[0].value.trim()+'号未抓类目</option>')
				}
				
			}else if(data.status==-1){
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
			}else{
					alert(data.msg)
			}
		}
	})

}