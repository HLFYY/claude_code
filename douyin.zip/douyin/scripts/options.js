$(document).ready(function(){
	init_top_category();
});

function init_top_category(){
	$.ajax({
		type:"post",
		xhrFields:{withCredentials:true},
		url:server[0]._server_port+(server[0].mappings)[17]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				$.each(data.data,function(index){
					if(index==0)category_id=this.cid
				$(".category1").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
			})
			}
		}
	})
}

function getIntervalMonth(startDate,endStart){
        var startMonth = startDate.getMonth();
        var endMonth = endStart.getMonth();
        var intervalMonth = (endStart.getFullYear()*12+endMonth) - (startDate.getFullYear()*12+startMonth);
        return intervalMonth;
}

function addDate(date, days) {
            var date = new Date(date);
            date.setDate(date.getDate() + days);
            var month = date.getMonth() + 1;
            var day = date.getDate();
            return date.getFullYear() + '-' + getFormatDate(month) + '-' + getFormatDate(day);
}

function getFormatDate(arg) {
    if (arg == undefined || arg == '') {
        return '';
    }

    var re = arg + '';
    if (re.length < 2) {
        re = '0' + re;
    }

    return re;
}

var dp_index=0;
$(".tabTitle>span").click(function(){
    var index=$(this).index();
    dp_index=index;
    $(this).addClass("active").siblings("span").removeClass("active");
    $(".detailData:eq("+index+")").show().siblings(".detailData").hide();
    showData()
});
var tabTitle_1=0;
$("#tabTitle_1>span").click(function(){
    var index=$(this).index();
	tabTitle_1=index;
    $(this).addClass("active").siblings("span").removeClass("active");
    $(".detailData:eq("+index+")").show().siblings(".detailData").hide();
    showData()
});
var header_tabId=0;
$(".ul1").on("click", "li", function() {
	//alert($(this).text())
	
	header_tabId=$(this).index()
	$(this).siblings().removeClass("active");
	$(this).addClass("active");
	$(".liActive:eq("+header_tabId+")").show().siblings(".liActive").hide();
	if($(this).text()=="下载"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/downLoad.html')});
	}else if($(this).text()=="市场"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/market_BigPlate.html')});
	}else if($(this).text()=="取数"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/options.html')});
	}
});

$(".ul2").on("click", "li", function() {
	$(this).siblings().removeClass("active");
	$(this).addClass("active");
	$(".liActive:eq("+$(this).index()+")").show().siblings(".liActive").hide();
	if($(this).text()=="市场"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/shichang_downLoad.html')});
	}else if($(this).text()=="取数"){
		chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/qushu_downLoad.html')});
	}
});


$(".selectCategory").on("mouseover", "li", function() {
	//if($(this).parent().attr('class')=="category1")
	var obj=$(this);
	var name=$(this).text();
	var cg=$(this).parent().attr('class');
	$.ajax({
		type:"post",
		data:{categoryId:$(this).attr("value")},
		url:server[0]._server_port+(server[0].mappings)[15]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==000){
				chrome.tabs.update(undefined, {url: "html/popup.html"});
			}
			if(data.status==1){
				if(data.data.length>0){
					obj.html("");
					obj.append('<span title="'+name+'">'+name+'</span><i class="iconfont icon-youjiantou pull-right"></i>');
				}
				if(cg=="category1"){
					$(".category2").html("")
					$.each(data.data,function(index){
						$(".category2").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
					})
				}
				if(cg=="category2"){
					$(".category3").html("")
					$.each(data.data,function(index){
						$(".category3").append('<li value="'+this.cid+'"><span title="'+this.name+'">'+this.name+'</span></li>')
					})
				}
			}
		}
	})
});
$(".selectCategory>span").click(function(e){
	$(".selectCategory>div").show(500);
	e.stopPropagation();
    $(document,".fa-times").click(function(){
      $(".selectCategory>div").hide(500);
    })
})

var category_id='';
$("#categoryDiv").on("mouseup", "li", function() {
	$(".selectCategory>div").hide(500);
	category_id=$(this).attr("value");
	$(".selectCategory>span").text($(this).text());
	$(this).addClass("active").siblings("li").removeClass("active");
	showData()
});
var terminal_id=0;
$("#terminal").change(function(){
	terminal_id=$("#terminal").val();
	showData()
})
var seller_id=-1;
$("#seller").change(function(){
	seller_id=$("#seller").val();
	showData()
})

var dataSelect_index=0;
$("#dataSelect_1>span").click(function(){
    var index=$(this).index();
    dataSelect_index=index;
    $(this).addClass("active").siblings("span").removeClass("active");
    showData()
});
var dataSelect_index1=0
$("#dataSelect_2>span").click(function(){
    var index=$(this).index();
    dataSelect_index1=index;
    $(this).addClass("active").siblings("span").removeClass("active");
    showData()
});
var dataSelect_index3=0
$("#dataSelect_3>span").click(function(){
    var index=$(this).index();
    dataSelect_index3=index;
    $(this).addClass("active").siblings("span").removeClass("active");
    showData()
});

var dateType='day';
$(".selectTime>span").click(function(){
    var index=$(this).index();
    $(this).addClass("on").siblings("span").removeClass("on");
    if($(this).text()=="按日")dateType='day' 
    if($(this).text()=="按周")dateType='week' 
    if($(this).text()=="按月")dateType='month' 
    init_date_div();
    showData();
});

var num=$(".state").length;
for(i=0;i<num;i++){
	if($(".state")[i].innerHTML=="完整数据"){
		$(".state")[i].parentNode.style.background="#cbf0d7";
	}
	if($(".state")[i].innerHTML=="无数据"){
		$(".state")[i].parentNode.style.background="#f5f5f5";
	}
	if($(".state")[i].innerHTML=="缺少部分数据"){
		$(".state")[i].parentNode.style.background="#ffd8d8";
	}
}
var backgroundPage = chrome.extension.getBackgroundPage();
var server=backgroundPage.getServer();
$(document).ready(function() {init_date_div()
	$.ajaxSetup({crossDomain: true, xhrFields: {withCredentials: true}});

})
document.addEventListener('DOMContentLoaded', function(){
	init_date_div();
	showData();
});

function init_date_div(){
	if(dateType=="day"){
		$(".monthBox").hide();
		$(".weekBox").hide();
		$(".dateBox").show();
	}
	if(dateType=="week"){
		$(".monthBox").hide();
		$(".weekBox").show();
		$(".dateBox").hide();
	}
	if(dateType=="month"){
		$(".monthBox").show();
		$(".weekBox").hide();
		$(".dateBox").hide();
	}
} 




$(".exit").click(function(){
	$.ajax({
		type:'post',
		url:server[0]._server_port+(server[0].mappings)[9]._interface,
		success:function(value){
			var data=JSON.parse(value);
			if(data.status==1){
				chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
			}
		}
	})
})

var c1=c2=c3=0;
function showData(){c1=c2=c3=0;
	if(header_tabId==0){
	
	if(dp_index==0){
		if(dateType=="day"){
			getTabData_day()
		}
		if(dateType=="week"){
			getTabData_week()
		}
		if(dateType=="month"){
			getTabData_month()
		}
	}
	if(dp_index==1){
		if($("#productId").val()==""){
			//alert("产品ID不能为空");
			return false
		}
		if(dateType=="day"){
			getTabData_day_item()
		}
		if(dateType=="week"){
			getTabData_week_item()
		}
		if(dateType=="month"){
			getTabData_month_item()
		}
	}
	
	}
	if(header_tabId==1){
		if(tabTitle_1==0){
			getDate_sc_hydp_day()
		}
	}
	
	$("tr").on("click", "td", function() {
		if($(this).text()=="作废"){
			remove($(this).parent().find("td:first").text())
		}
	});
}
function remove(date){
	if(!confirm("是否要作废？")){
		return;
	}
	$.ajax({
			type:'post',
			url:server[0]._server_port+"/option/Pangolin_FetchNumber_delete.htm",
			data:{
				tab:dp_index,
				startDate:date.split("~")[0],
				endDate:date.split("~")[1],
				dateType:dateType,
				productId:$("#productId").val(),
			},
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.status==-2){
					alert(data.msg);
				}
				if(data.status==-1){
					alert(data.msg);
					chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
				}
				if(data.status==2){
					//alert(data.msg);
				}
				if(data.status==0){
					alert(data.msg);
				}
				if(data.status==1){
					showData()
				}
			}
			})
	
}

$("#productId").change(function(){
	showData()
})

function getTabData_day_item(){
	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}

	$("#itemWhole tbody").html("")
	for(var i=0;i<=count;i++){
		$("#itemWhole tbody").append('<tr id="item_'+addDate(startDate, i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType,
				productId:$("#productId").val(),
			},
			url:server[0]._server_port+(server[0].mappings)[11]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
					
				}
				$("#item_count2").text(c1)
				if(data.data[0].status==2){
					c2++
					
				}
				$("#item_count3").text(c2)
				if(data.data[0].status==3){
					c3++
					
				}
				$("#item_count4").text(c3)
				$("#item_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect_index1==0){
					var index_names="";
					var status=0;
					var startDate="";
					var picUrl="";
					var productName="";
					$.each(data.data,function(index){
						var boolean=true;
						if(this.status==1){boolean=false;
							$("#item_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#item_"+this.startDate).append('<td>'+this.startDate+'</td><td><img src="http:'+this.picUrl+'" alt=""></td><td><div class="productName">'+this.productName+'</div></td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#item_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#item_"+this.startDate).append('<td>'+this.startDate+'</td> <td><img src="http:'+this.picUrl+'" alt=""></td><td><div class="productName">'+this.productName+'</div></td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							picUrl=this.picUrl;
							productName=this.productName;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#item_"+this.startDate).remove();
					})
					if(status==2){
						$("#item_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#item_"+startDate).append('<td>'+startDate+'</td><td><img src="http:'+picUrl+'" alt=""></td><td><div class="productName">'+productName+'</div></td>  <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index1==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#item_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#item_"+this.startDate).append('<td>'+this.startDate+'</td><td><img src="http:'+this.picUrl+'" alt=""></td><td><div class="productName">'+this.productName+'</div></td>  <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#item_"+this.startDate).remove();
					})
				}
				
				if(data.status==1 && dataSelect_index1==2){
					var index_names="";
					var status=0;
					var startDate="";
					var picUrl="";
					var productName="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							picUrl=this.picUrl;
							productName=this.productName;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#item_"+this.startDate).remove();
					})
					if(status==2){
						$("#item_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#item_"+startDate).append('<td>'+startDate+'</td><td><img src="http:'+picUrl+'" alt=""></td><td><div class="productName">'+productName+'</div></td>  <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index1==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#item_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#item_"+this.startDate).append('<td>'+this.startDate+'</td><td><img src="http:'+this.picUrl+'" alt=""></td><td><div class="productName">'+this.productName+'</div></td>  <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#item_"+this.startDate).remove();
					})

				}
			}
		})
	}
}

function getTabData_day(){
	var startDate;
	var endDate;
	if(dateType=="day"){
		startDate=$(".dateBox").find("input")[0].value.trim()
		endDate=$(".dateBox").find("input")[1].value.trim()
	}
	
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	$("#shopWhole tbody").html("")
	for(var i=0;i<=count;i++){
		$("#shopWhole tbody").append('<tr id="shop_'+addDate(startDate, i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:dateType
			},
			url:server[0]._server_port+(server[0].mappings)[10]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
					
				}
				$("#shop_count2").text(c1)
				if(data.data[0].status==2){
					c2++
					
				}
				$("#shop_count3").text(c2)
				if(data.data[0].status==3){
					c3++
					
				}
				$("#shop_count4").text(c3)
				$("#shop_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect_index==0){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#shop_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#shop_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#shop_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#shop_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#shop_"+this.startDate).remove();
					})
					if(status==2){
						$("#shop_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#shop_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#shop_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#shop_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#shop_"+this.startDate).remove();
					})
				}
				
				if(data.status==1 && dataSelect_index==2){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#shop_"+this.startDate).remove();
					})
					if(status==2){
						$("#shop_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#shop_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#shop_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#shop_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#shop_"+this.startDate).remove();
					})

				}
			}
		})
	}
	
}

$(".dateBox").change(function(){
	showData()
})

function getTabData_week(){
	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}
	$("#shopWhole tbody").html("")
	for(var i=0;i<count;i++){
		$("#shopWhole tbody").append('<tr id="shop_'+addDate(startDate, 7*i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType
			},
			url:server[0]._server_port+(server[0].mappings)[10]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
					
				}
				$("#shop_count2").text(c1)
				if(data.data[0].status==2){
					c2++
					
				}
				$("#shop_count3").text(c2)
				if(data.data[0].status==3){
					c3++
					
				}
				$("#shop_count4").text(c3)
				$("#shop_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect_index==0){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#shop_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#shop_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#shop_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#shop_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate.split('~')[0];
							startDate_status_2=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#shop_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#shop_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#shop_"+startDate).append('<td>'+startDate_status_2+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#shop_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#shop_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#shop_"+this.startDate.split('~')[0]).remove();
					})
				}
				
				if(data.status==1 && dataSelect_index==2){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate.split('~')[0];
							startDate_status_2=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#shop_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#shop_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#shop_"+startDate).append('<td>'+startDate_status_2+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				if(data.status==1 && dataSelect_index==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#shop_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#shop_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#shop_"+this.startDate.split('~')[0]).remove();
					})
				}
			}
		})
	}
	
}

function getTabData_week_item(){
	var startDate;
	var endDate;
	if(dateType=="week"){
		startDate=getFirstDayOfWeek (new Date($(".weekBox").find("input")[0].value.trim()))
		endDate=$(".weekBox").find("input")[1].value.trim()
	}
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=(parseInt(days / (1000 * 60 * 60 * 24))+1)/7; //除7得到周数
	}

	$("#itemWhole tbody").html("")
	for(var i=0;i<count;i++){
		$("#itemWhole tbody").append('<tr id="item_'+addDate(startDate, 7*i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate,  7*i),
				endDate:endDate,
				dateType:dateType,
				productId:$("#productId").val(),
			},
			url:server[0]._server_port+(server[0].mappings)[11]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
					
				}
				$("#item_count2").text(c1)
				if(data.data[0].status==2){
					c2++
					
				}
				$("#item_count3").text(c2)
				if(data.data[0].status==3){
					c3++
					
				}
				$("#item_count4").text(c3)
				$("#item_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect_index1==0){
					var index_names="";
					var status=0;
					var startDate="";
					var picUrl="";
					var productName="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#item_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#item_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td><td><img src="http:'+this.picUrl+'" alt=""></td><td><div class="productName">'+this.productName+'</div></td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#item_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#item_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td><td><img src="http:'+this.picUrl+'" alt=""></td><td><div class="productName">'+this.productName+'</div></td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate.split('~')[0];
							picUrl=this.picUrl;
							productName=this.productName;
							startDate_status_2=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#item_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#item_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#item_"+startDate).append('<td>'+startDate_status_2+'</td><td><img src="http:'+picUrl+'" alt=""></td><td><div class="productName">'+productName+'</div></td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index1==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#item_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#item_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td><td><img src="http:'+this.picUrl+'" alt=""></td><td><div class="productName">'+this.productName+'</div></td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#item_"+this.startDate.split('~')[0]).remove();
					})
				}
				
				if(data.status==1 && dataSelect_index1==2){
					var index_names="";
					var status=0;
					var startDate="";
					var picUrl="";
					var productName="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate.split('~')[0];
							picUrl=this.picUrl;
							productName=this.productName;
							startDate_status_2=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#item_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#item_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#item_"+startDate).append('<td>'+startDate_status_2+'</td><td><img src="http:'+picUrl+'" alt=""></td><td><div class="productName">'+productName+'</div></td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				if(data.status==1 && dataSelect_index1==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#item_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#item_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td><td><img src="http:'+this.picUrl+'" alt=""></td><td><div class="productName">'+this.productName+'</div></td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#item_"+this.startDate.split('~')[0]).remove();
					})
				}
			}
		})
	}
}


$(".weekBox").change(function(){
	showData()
})

function getTabData_month_item(){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))
	
	$("#itemWhole tbody").html("")
	for(var i=0;i<=count;i++){
		var tr_id=getMonth(startDate,i);
		$("#itemWhole tbody").append('<tr id="item_'+tr_id+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType,
				productId:$("#productId").val(),
			},
			url:server[0]._server_port+(server[0].mappings)[11]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
					
				}
				$("#item_count2").text(c1)
				if(data.data[0].status==2){
					c2++
					
				}
				$("#item_count3").text(c2)
				if(data.data[0].status==3){
					c3++
					
				}
				$("#item_count4").text(c3)
				$("#item_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect_index1==0){
					var index_names="";
					var status=0;
					var startDate="";
					var picUrl="";
					var productName="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#item_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#item_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td><td><img src="http:'+this.picUrl+'" alt=""></td><td><div class="productName">'+this.productName+'</div></td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#item_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#item_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td><td><img src="http:'+this.picUrl+'" alt=""></td><td><div class="productName">'+this.productName+'</div></td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate.split('~')[0];
							picUrl=this.picUrl;
							productName=this.productName;
							startDate_status_2=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#item_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#item_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#item_"+startDate).append('<td>'+startDate_status_2+'</td><td><img src="http:'+picUrl+'" alt=""></td><td><div class="productName">'+productName+'</div></td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index1==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#item_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#item_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td><td><img src="http:'+this.picUrl+'" alt=""></td><td><div class="productName">'+this.productName+'</div></td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#item_"+this.startDate.split('~')[0]).remove();
					})
				}
				
				if(data.status==1 && dataSelect_index1==2){
					var index_names="";
					var status=0;
					var startDate="";
					var picUrl="";
					var productName="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate.split('~')[0];
							picUrl=this.picUrl;
							productName=this.productName;
							startDate_status_2=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#item_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#item_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#item_"+startDate).append('<td>'+startDate_status_2+'</td><td><img src="http:'+picUrl+'" alt=""></td><td><div class="productName">'+productName+'</div></td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				if(data.status==1 && dataSelect_index1==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#item_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#item_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td><td><img src="http:'+this.picUrl+'" alt=""></td><td><div class="productName">'+this.productName+'</div></td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#item_"+this.startDate.split('~')[0]).remove();
					})
				}
			}
		})
	}
}
/*setInterval(function setCount_item(){
	if(dataSelect_index1==0)$("#item_count1").text($("#itemWhole tbody").find("tr").length)
	if(dataSelect_index1==1)$("#item_count2").text($("#itemWhole tbody").find("tr").length)
	if(dataSelect_index1==2)$("#item_count3").text($("#itemWhole tbody").find("tr").length)
	if(dataSelect_index1==3)$("#item_count4").text($("#itemWhole tbody").find("tr").length)
	if(dataSelect_index==0)$("#shop_count1").text($("#shopWhole tbody").find("tr").length)
	if(dataSelect_index==1)$("#shop_count2").text($("#shopWhole tbody").find("tr").length)
	if(dataSelect_index==2)$("#shop_count3").text($("#shopWhole tbody").find("tr").length)
	if(dataSelect_index==3)$("#shop_count4").text($("#shopWhole tbody").find("tr").length)
	if(dataSelect_index3==0)$("#hydp_count1").text($("#hydp tbody").find("tr").length)
	if(dataSelect_index3==1)$("#hydp_count2").text($("#hydp tbody").find("tr").length)
	if(dataSelect_index3==2)$("#hydp_count3").text($("#hydp tbody").find("tr").length)
	if(dataSelect_index3==3)$("#hydp_count4").text($("#hydp tbody").find("tr").length)
},50);*/

function getMonth(startDate,i){
	var year=parseInt(startDate.split('-')[0]);
	var month=parseInt(startDate.split('-')[1]);
	if(month+i>12){
		var count=	parseInt((month+i)/12)
		month=(month+i)-12*count;
		if(month==0){
			year=year+count-1;
			month=12;
			return year+"-"+month+"-01"
		}else{
			year=year+count;
			return year+"-"+(month>9?month:"0"+month)+"-01";
		}
		
	}else{
		month=month+i
		return year+"-"+(month>9?month:"0"+month)+"-01";
	}
}

function getTabData_month(){
	var startDate;
	var endDate;
	var count=0;
	if(dateType=="month"){
		startDate=$(".monthBox").find("input")[0].value.trim()
		endDate=$(".monthBox").find("input")[1].value.trim()
	}
	count=getIntervalMonth(new Date(startDate),new Date(endDate))

	$("#shopWhole tbody").html("")
	for(var i=0;i<=count;i++){
		//var tr_id=getMonth(startDate,i);
		var tr_id=getMonth(startDate,i);
		$("#shopWhole tbody").append('<tr id="shop_'+tr_id+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:tr_id,
				endDate:endDate,
				dateType:dateType
			},
			url:server[0]._server_port+(server[0].mappings)[10]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
					
				}
				$("#shop_count2").text(c1)
				if(data.data[0].status==2){
					c2++
					
				}
				$("#shop_count3").text(c2)
				if(data.data[0].status==3){
					c3++
					
				}
				$("#shop_count4").text(c3)
				$("#shop_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect_index==0){
					var index_names="";
					var status=0;
					var startDate="";
					var startDate_status_2="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#shop_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#shop_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#shop_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#shop_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate.split('~')[0];
							startDate_status_2=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#shop_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#shop_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#shop_"+startDate).append('<td>'+startDate_status_2+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#shop_"+this.startDate.split('~')[0]).attr("style","background: rgb(203, 240, 215);");
							$("#shop_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#shop_"+this.startDate.split('~')[0]).remove();
					})
				}
				
				if(data.status==1 && dataSelect_index==2){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate.split('~')[0];
							startDate_status_2=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#shop_"+this.startDate.split('~')[0]).remove();
					})
					if(status==2){
						$("#shop_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#shop_"+startDate).append('<td>'+startDate_status_2+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				if(data.status==1 && dataSelect_index==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#shop_"+this.startDate.split('~')[0]).attr("style","background: rgb(245, 245, 245);");
							$("#shop_"+this.startDate.split('~')[0]).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/adm/v2/new" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#shop_"+this.startDate.split('~')[0]).remove();
					})
				}
			}
		})
	}
	
}

$(".monthBox").change(function(){
	showData()
})
$("#date_day_1").change(function(){
	showData()
})

function getDate_sc_hydp_day(){
	var startDate;
	var endDate;
	startDate=$("#date_day_1").find("input")[0].value.trim()
	endDate=$("#date_day_1").find("input")[1].value.trim()
	var count=0;
	if(startDate==endDate){
		count=0;
	}else{
		var date1 = new Date(startDate);
		var date2 = new Date(endDate);
		var days = date2.getTime() - date1.getTime();
		count=parseInt(days / (1000 * 60 * 60 * 24)); 
	}
	$("#hydp tbody").html("")
	for(var i=0;i<=count;i++){
		$("#hydp tbody").append('<tr id="hydp_'+addDate(startDate, i)+'"></tr>');
		$.ajax({
			type:'post',
			data:{
				startDate:addDate(startDate, i),
				endDate:endDate,
				dateType:'day',
				categoryId:category_id,
				sellerId:seller_id,
				terminalId:terminal_id
			},
			url:server[0]._server_port+(server[0].mappings)[16]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==000){
					chrome.tabs.update(undefined, {url: "html/popup.html"});
				}
				if(data.data[0].status==1){
					c1++
					
				}
				$("#hydp_count2").text(c1)
				if(data.data[0].status==2){
					c2++
					
				}
				$("#hydp_count3").text(c2)
				if(data.data[0].status==3){
					c3++
					
				}
				$("#hydp_count4").text(c3)
				$("#hydp_count1").text(c1+c2+c3)
				if(data.status==1 && dataSelect_index3==0){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#hydp_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#hydp_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(this.status==3){boolean=false;
							$("#hydp_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#hydp_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mq/industry/overview/overview.htm" target="_blank">读取数据</a></td> <td></td>')
						}
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#hydp_"+this.startDate).remove();
					})
					if(status==2){
						$("#hydp_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#hydp_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mq/industry/overview/overview.htm" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index3==1){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==1){boolean=false;
							$("#hydp_"+this.startDate).attr("style","background: rgb(203, 240, 215);");
							$("#hydp_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">完整数据</td> <td class="readData">作废</td> <td></td>')
						}
						if(boolean)$("#hydp_"+this.startDate).remove();
					})
				}
				
				if(data.status==1 && dataSelect_index3==2){
					var index_names="";
					var status=0;
					var startDate="";
					$.each(data.data,function(index){var boolean=true;
						if(this.status==2){boolean=false;
							status=this.status;
							startDate=this.startDate;
							if(index==0){
								index_names=this.name
							}else{
								index_names=index_names+';'+this.name
							}
						}
						if(boolean)$("#hydp_"+this.startDate).remove();
					})
					if(status==2){
						$("#hydp_"+startDate).attr("style","background: rgb(255, 216, 216);");
						$("#hydp_"+startDate).append('<td>'+startDate+'</td> <td class="state">缺少部分数据</td> <td class="readData"><a href="https://sycm.taobao.com/mq/industry/overview/overview.htm" target="_blank">读取数据</a></td> <td>'+index_names+'</td>')
					}
				}
				
				if(data.status==1 && dataSelect_index3==3){
					$.each(data.data,function(index){var boolean=true;
						if(this.status==3){boolean=false;
							$("#hydp_"+this.startDate).attr("style","background: rgb(245, 245, 245);");
							$("#hydp_"+this.startDate).append('<td>'+this.startDate+'</td> <td class="state">无数据</td> <td class="readData"><a href="https://sycm.taobao.com/mq/industry/overview/overview.htm" target="_blank">读取数据</a></td> <td></td>')
						}
						if(boolean)$("#hydp_"+this.startDate).remove();
					})

				}
			}
		})
	}
}
