$.ajaxSetup({crossDomain: true, xhrFields: {withCredentials: true}});
var backgroundPage = chrome.extension.getBackgroundPage();
var server=backgroundPage.getServer();
var user="";
$(document).ready(function() {
	checkVersion();
});

function checkVersion(){
	chrome.runtime.sendMessage(
	        {cmd: 'get-Version'},
	        function (response) {
	        	if(response==0){
	        		$(".updatedVersion").siblings().hide();
	        		$("body").html("服务器未开启！");
	        	}
	        	if(response==1){
	        		checkShop();
	        	}
	        	if(response==2){
	        		$(".updatedVersion").siblings().hide();
	        		$(".updatedVersion").show();
	        	}
		      }
	    );
}

function login(){
	$.ajax({
			type:'post',
			xhrFields:{withCredentials:true},
			url:server[0]._server_port+(server[0].mappings)[3]._interface,
			success:function(data){
				if(data.status==-1){
					$(".login").siblings().hide();
					$(".login").show();
				}else{
					//checkShop();
				}
			}
		})
}

var confirm=false;
function checkShop(){
	var server=backgroundPage.getServer();
	$.ajax({
			type:'post',
			data:{sysinfo:backgroundPage.getSystemInfo(),confirm:confirm},
			url:server[0]._server_port+(server[0].mappings)[4]._interface,
			success:function(value){confirm=false;
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==1){
					sessionStorage.shopName=data.data.shopname;
					$(".selsetItem").find("small").html('| &nbsp;'+data.data.shopname);
					$(".selsetItem").siblings().hide();
//					$("#module").html("");
//					_init_userInterface();
//					backgroundPage._i();
//					backgroundPage._ijd();
//					backgroundPage._jdurl();
//					backgroundPage._tburl();
//					_m();
					_init_module();
					$(".selsetItem").show();
				}
				if(data.status==0){
					$(".linksycm").siblings().hide();
	        		$(".linksycm").show();
				}
				if(data.status=="000"){
					$(".login").siblings().hide();
					$(".login").show();
				}
				if(data.status==4){
					if(prompt("首次登陆穿山甲！将绑定此电脑！绑定之后该账号只能使用此电脑操作！同意填写'true'")){
						confirm=true;
						checkShop();
					}else{
						$("#module").html(data.msg);
					}
				}
				if(data.status==5){
					alert(data.msg);
					$(".login").hide();
					$(".selsetItem").show();
					$("#module").html('');
					$("#module").append('<h3 id="sysinfo">'+backgroundPage.getSystemInfo()+'</h3>');
					$("#module").append('<button class="logout">退出</button>');
					$(".logout").click(function(){
						$.ajax({
							type:'post',
							url:server[0]._server_port+(server[0].mappings)[9]._interface,
							success:function(value){
								var data={};
								if(Object.prototype.toString.call(value)=="[object String]"){
									data=JSON.parse(value);
								}
								if(Object.prototype.toString.call(value)=="[object Object]"){
									data=value;
								}
								if(data.code==100){
									$(".login").show();
									$(".selsetItem").hide();
								}
							}
						})
					})
				}
			}
		})
}

function _init_userInterface(){
	$.ajax({
		type:'POST',
		url:server[0]._server_port+'/user/setUserInterface',
		async:false,
		success:function(value){
			console.log(value)
		}
	})
}

function _m(){
	$.ajax({
		type:'POST',
		url:server[0]._server_port+'/option/getModule',
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.status==1){
				if(data.data.length>0){
					$.each(data.data,function(index){
						$("#module").append('<div href="html/'+this.url+'"><img src="../images/1.png" alt="" href="../html/'+this.url+'"><p>'+this.moduleName+'</p></div>');
					})
					_init_module();
				}else{
					$("#module").html("亲！您一个模块权限都没有呢!需要开通请联系客服！");
				}
				
			}
		}
	})
}

$('.updatedVersion button').click(function(){
	backgroundPage.downloadVersion();
});
$('.login button').click(function(){
		var username=$('.login').find(" input[ type='text' ] ").val();
		var password=$('.login').find(" input[ type='password' ] ").val();
		
		$.ajax({
			type:'post',
			data:{username:username,password:password},
			xhrFields:{crossDomain: true,withCredentials:true},
			url:server[0]._server_port+(server[0].mappings)[2]._interface,
			success:function(value){
				var data={};
				if(Object.prototype.toString.call(value)=="[object String]"){
					data=JSON.parse(value);
				}
				if(Object.prototype.toString.call(value)=="[object Object]"){
					data=value;
				}
				if(data.status==200){
					chrome.tabs.update(undefined, {url: "https://sycm.taobao.com/"});
					checkShop()
				}
			}
		})
	})

$("span").click(function(){	
	$(this).parents('.undetected').click(function(){
		jumpOrOpenSYCMLogin();
	})
	
})

$('.linksycm button').click(function(){
	var shopName=$('.linksycm').find(" input[ type='text' ] ").val();
	$.ajax({
		type:'post',
		data:{shopName:shopName},
		url:server[0]._server_port+(server[0].mappings)[5]._interface,
		success:function(value){
			var data=JSON.parse(value);
			if(data.status==1){
				sessionStorage.shopName=data.data.shopname;
				backgroundPage.startDebugger()
				backgroundPage._i();
				$(".selsetItem").find("small").html('| &nbsp;'+shopName);
				$(".selsetItem").siblings().hide();
				$("#module").html("");
				let modules=backgroundPage._m();
				$.each(modules,function(index){
					$("#module").append('<div href="html/'+this.url+'"><img src="../images/1.png" alt="" ><p>'+this.moduleName+'</p></div>');
				})
				_init_module();
        		$(".selsetItem").show();
        		user=data.data;
			}
			if(data.status==0){
				alert("添加失败！")
			}
		}
	})
});

function _init_module(){
	$(".selsetItem>div>div").click(function(){
		var index = $(this).index();
		window.open(chrome.extension.getURL($(this).attr("href")));
	})
}

document.addEventListener('DOMContentLoaded', function(){});

function getCookie(c_name)
{
if (document.cookie.length>0)
  {
  c_start=document.cookie.indexOf(c_name + "=")
  if (c_start!=-1)
    { 
    c_start=c_start + c_name.length+1 
    c_end=document.cookie.indexOf(";",c_start)
    if (c_end==-1) c_end=document.cookie.length
    return unescape(document.cookie.substring(c_start,c_end))
    } 
  }
return ""
}

function setCookie(c_name,value,expiredays)
{
var exdate=new Date()
exdate.setDate(exdate.getDate()+expiredays)
document.cookie=c_name+ "=" +escape(value)+
((expiredays==null) ? "" : ";expires="+exdate.toGMTString())
}