 $(".tabTitle>span").click(function(){
    var index=$(this).index();
    $(this).addClass("active").siblings("span").removeClass("active");
    $(".detailData:eq("+index+")").show().siblings(".detailData").hide();
});

 $(".header ul>li").click(function(){
    var index=$(this).index();
    $(this).addClass("active").siblings("li").removeClass("active");
    $(".liActive:eq("+index+")").show().siblings(".liActive").hide();
});

var num=$(".state").length;
for(i=0;i<num;i++){
	if($(".state")[i].innerHTML=="完整数据"){
		$(".state")[i].parentNode.style.background="#cbf0d7";
	}
	if($(".state")[i].innerHTML=="无数据"){
		$(".state")[i].parentNode.style.background="#f5f5f5";
	}
	if($(".state")[i].innerHTML=="缺少部分数据"){
		$(".state")[i].parentNode.style.background="#ffd8d8";
	}
}

  var documentH=$(document).height();
  var header=$(".header").height();
  var leftH=(documentH-header-40)+"px";
  $(".navLeft").height(leftH);


	function getIntervalMonth(startDate,endStart){
	    var startMonth = startDate.getMonth();
	    var endMonth = endStart.getMonth();
	    var intervalMonth = (endStart.getFullYear()*12+endMonth) - (startDate.getFullYear()*12+startMonth);
	    return intervalMonth;
	}


  function getMonth(startDate,i){
		var year=parseInt(startDate.split('-')[0]);
		var month=parseInt(startDate.split('-')[1]);
		if(month+i>12){
			var count=	parseInt((month+i)/12)
			month=(month+i)-12*count;
			if(month==0){
				year=year+count-1;
				month=12;
				return year+"-"+month+"-01"
			}else{
				year=year+count;
				return year+"-"+(month>9?month:"0"+month)+"-01";
			}
			
		}else{
			month=month+i
			return year+"-"+(month>9?month:"0"+month)+"-01";
		}
	}


$("#checkbox000").click(function() {
  $(".checkALL").find("input[type='checkbox']").prop("checked", this.checked);
});

$("input[type='checkbox']").click(function() {
    var $subs = $(".checkALL").find("input[type='checkbox']");
    $("#checkbox000").prop("checked" , $subs.length == $subs.filter(":checked").length ? true :false);
});

$(".selectCategory").click(function(){
  $(".selectCategory>div").show();
})




window.onload=function(){ 
      $("#nav").append('<li class="active">\
        <span>数据完整查询</span>\
        <ul class="secondLi">\
          <li><a href="../html/options.html">取数</a></li>\
          <li><a href="../html/market_BigPlate.html">市场</a></li>\
          <li><a href="../html/flow.html">流量</a></li>\
    	  <li><a href="../html/category.html">品类</a></li>\
          <li><a href="javascript;">交易</a></li>\
          <li><a href="../html/competitionAnalysis.html">竞争</a></li>\
        </ul>\
      </li>\
      <li>\
        <span>数据下载中心</span>\
        <ul class="secondLi">\
          <li><a href="../html/qushu_downLoad.html">取数</a></li>\
          <li><a href="../html/shichang_downLoad.html">市场</a></li>\
          <li><a href="../html/downLoadFlow.html">流量</a></li>\
          <li><a href="../html/downLoadCategory.html">品类</a></li>\
          <li><a href="javascript:;">交易</a></li>\
          <li><a href="../html/downLoadCompete.html">竞争</a></li>\
          <li><a href="downRealTime.html">实时</a></li>\
        </ul>\
      </li>\
      <li>\
        <span>智能分析中心</span>\
      </li>');
      url=window.location.href;
  	$.each($("#nav").find("a"),function(index){
  		if(this.href.match(url.split("/")[4])){
  			$(this).parent().addClass("active").siblings("li").removeClass("active");
  			$(this).parent().parent().parent().addClass("active").siblings("li").removeClass("active");
  		}
  		
  	})
      $(".nav>li").hover(function(){
        $(this).children(".secondLi").show();
      },function(){
        $(this).children(".secondLi").hide();
      })
    
}









$(".exit").click(function(){
	$.ajax({
		type:'post',
		url:server[0]._server_port+(server[0].mappings)[9]._interface,
		success:function(value){
			var data={};
			if(Object.prototype.toString.call(value)=="[object String]"){
				data=JSON.parse(value);
			}
			if(Object.prototype.toString.call(value)=="[object Object]"){
				data=value;
			}
			if(data.code==100){
				chrome.tabs.update(undefined, {url: chrome.extension.getURL('html/popup.html')});
			}
		}
	})
})
var backgroundPage = chrome.extension.getBackgroundPage();
var server=backgroundPage.getServer();	
function checkLogin(){
	$.ajax({
	type:'post',
	xhrFields:{withCredentials:true},
	url:server[0]._server_port+"/user/getShopName",
	success:function(value){
	var data={};
	if(Object.prototype.toString.call(value)=="[object String]"){
		data=JSON.parse(value);
	}
	if(Object.prototype.toString.call(value)=="[object Object]"){
		data=value;
	}
	if(data.status==1){
		var str="";
		$.each(data.data,function(index){
			if(status=="new"){
				str='<option value="'+this.shopName+'">'+this.shopName+'</option>'+str;
			}else{
				str=str+'<option value="'+this.shopName+'">'+this.shopName+'</option>';
			}
		})
		$("#shopNames").append(str);
		$.each($("#shopNames").find("option"),function(index){
			if(this.innerHTML==sessionStorage.shopName){
				document.getElementById("shopNames")[index].selected=true;
			}
		})
	}
	}
})
}

$(document).ready(function() {
	$.ajaxSetup({crossDomain: true, xhrFields: {withCredentials: true}});
	checkLogin();
})


function addDate(date, days) {

    var date = new Date(date);
    date.setDate(date.getDate() + days);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return date.getFullYear() + '-' + getFormatDate(month) + '-' + getFormatDate(day);
}
function getFormatDate(arg) {
    if (arg == undefined || arg == '') {
        return '';
    }

    var re = arg + '';
    if (re.length < 2) {
        re = '0' + re;
    }

    return re;
}

$("#shopNames").change(function(){
	$.ajax({
		type:'post',
		data:{shopName:this.value},
		xhrFields:{withCredentials:true},
		url:server[0]._server_port+"/user/setShopName",
		success:function(value){
		var data={};
		if(Object.prototype.toString.call(value)=="[object String]"){
			data=JSON.parse(value);
		}
		if(Object.prototype.toString.call(value)=="[object Object]"){
			data=value;
		}
		if(data.status==1){
			sessionStorage.shopName=data.data;
		}
		}
	})
})